<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Student Management - Northland Schools Kano</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <!-- Adding jsPDF and html2canvas libraries for real PDF generation -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    
    <!-- Include sidebar CSS -->
    <link rel="stylesheet" href="sidebar.css">
    
    <script>
      tailwind.config = {
        theme: {
          extend: {
            colors: {
              nskblue: '#1e40af',
              nsklightblue: '#3b82f6',
              nsknavy: '#1e3a8a',
              nskgold: '#f59e0b',
              nsklight: '#f0f9ff',
              nskgreen: '#10b981',
              nskred: '#ef4444',
            },
          },
        },
      };
    </script>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap');

      body {
        font-family: 'Montserrat', sans-serif;
        background: #f8fafc;
      }

      .logo-container {
        background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%);
      }

      .student-card {
        transition: all 0.3s ease;
      }

      .student-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1),
          0 10px 10px -5px rgba(0, 0, 0, 0.04);
      }

      .nav-item {
        position: relative;
      }

      .nav-item::after {
        content: '';
        position: absolute;
        width: 0;
        height: 2px;
        bottom: -5px;
        left: 0;
        background-color: #f59e0b;
        transition: width 0.3s ease;
      }

      .nav-item:hover::after {
        width: 100%;
      }

      .sidebar {
        transition: all 0.3s ease;
        width: 250px;
      }

      .sidebar.collapsed {
        width: 80px;
      }

      .main-content {
        transition: all 0.3s ease;
        margin-left: 250px;
        width: calc(100% - 250px);
      }

      .main-content.expanded {
        margin-left: 80px;
        width: calc(100% - 80px);
      }

      @media (max-width: 768px) {
        .sidebar {
          margin-left: -250px;
        }

        .sidebar.mobile-show {
          margin-left: 0;
        }

        .main-content {
          margin-left: 0;
          width: 100%;
        }
      }

      .notification-dot {
        position: absolute;
        top: -5px;
        right: -5px;
        width: 12px;
        height: 12px;
        background-color: #ef4444;
        border-radius: 50%;
        animation: pulse 2s infinite;
      }

      .student-table {
        border-collapse: separate;
        border-spacing: 0;
      }

      .student-table th {
        background-color: #f8fafc;
      }

      .student-table tr:last-child td {
        border-bottom: 0;
      }

      .student-table tbody tr {
        transition: all 0.3s ease;
      }

      .student-table tbody tr:hover {
        background-color: #f8fafc;
        transform: scale(1.01);
      }

      .grade-badge {
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        animation: fadeInUp 0.5s ease;
      }

      .status-badge {
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
      }

      .modal {
        transition: all 0.3s ease;
        transform: scale(0.9);
        opacity: 0;
        visibility: hidden;
      }

      .modal.active {
        transform: scale(1);
        opacity: 1;
        visibility: visible;
      }

      .tab-content {
        display: none;
      }

      .tab-content.active {
        display: block;
        animation: fadeIn 0.5s ease;
      }

      .tab-button {
        transition: all 0.3s ease;
      }

      .tab-button.active {
        background-color: #1e40af;
        color: white;
      }

      .form-section {
        animation: slideInUp 0.5s ease;
      }

      .progress-bar {
        transition: width 0.5s ease;
      }

      .card-animate {
        animation: slideInUp 0.6s ease;
      }

      .button-hover {
        transition: all 0.3s ease;
      }

      .button-hover:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
      }

      .file-drop-zone {
        border: 2px dashed #d1d5db;
        transition: all 0.3s ease;
      }

      .file-drop-zone.dragover {
        border-color: #1e40af;
        background-color: #f0f9ff;
      }

      .loading-spinner {
        animation: spin 1s linear infinite;
      }

      @keyframes fadeIn {
        from {
          opacity: 0;
        }
        to {
          opacity: 1;
        }
      }

      @keyframes fadeInUp {
        from {
          opacity: 0;
          transform: translateY(20px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      @keyframes slideInUp {
        from {
          opacity: 0;
          transform: translateY(30px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      @keyframes pulse {
        0%,
        100% {
          opacity: 1;
        }
        50% {
          opacity: 0.5;
        }
      }

      @keyframes spin {
        from {
          transform: rotate(0deg);
        }
        to {
          transform: rotate(360deg);
        }
      }

      .id-card {
        background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%);
        border-radius: 15px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
      }

      .medical-alert {
        animation: pulse 2s infinite;
      }

      .document-item {
        transition: all 0.3s ease;
      }

      .document-item:hover {
        background-color: #f8fafc;
        transform: translateX(5px);
      }
    </style>
  </head>
  <body class="flex">
   <!-- Sidebar Navigation -->
<script src="sidebar.js"></script>
    
    <!-- Main Content -->
    <main class="main-content">
      <!-- Header -->
      <header class="bg-white shadow-md p-4">
        <div class="flex justify-between items-center">
          <div class="flex items-center space-x-4">
            <button id="mobileMenuToggle" class="md:hidden text-nsknavy sidebar-toggle">
              <i class="fas fa-bars text-xl"></i>
            </button>
            <h1 class="text-2xl font-bold text-nsknavy">Student Management</h1>
          </div>

          <div class="flex items-center space-x-4">
            <div class="relative">
              <div
                class="flex items-center space-x-2 bg-nsklight rounded-full py-2 px-4"
              >
                <i class="fas fa-search text-gray-500"></i>
                <input
                  type="text"
                  id="searchInput"
                  placeholder="Search students..."
                  class="bg-transparent outline-none w-32 md:w-64"
                />
              </div>
            </div>

            <div class="relative">
              <i class="fas fa-bell text-nsknavy text-xl"></i>
              <div class="notification-dot"></div>
            </div>

            <div class="hidden md:flex items-center space-x-2">
              <div
                class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center text-white font-bold"
              >
                A
              </div>
              <div>
                <p class="text-sm font-semibold text-nsknavy">Admin User</p>
                <p class="text-xs text-gray-600">Administrator</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <!-- Student Management Content -->
      <div class="p-6">
        <!-- Stats Overview -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div
            class="student-card card-animate bg-white rounded-xl shadow-md p-5 flex items-center"
          >
            <div class="bg-nsklightblue p-4 rounded-full mr-4">
              <i class="fas fa-user-graduate text-white text-xl"></i>
            </div>
            <div>
              <p class="text-gray-600">Total Students</p>
              <p class="text-2xl font-bold text-nsknavy" id="totalStudents">
                1,245
              </p>
              <p class="text-xs text-nskgreen">
                <i class="fas fa-arrow-up"></i> 5% from last term
              </p>
            </div>
          </div>

          <div
            class="student-card card-animate bg-white rounded-xl shadow-md p-5 flex items-center"
          >
            <div class="bg-nskgreen p-4 rounded-full mr-4">
              <i class="fas fa-chalkboard text-white text-xl"></i>
            </div>
            <div>
              <p class="text-gray-600">Active Classes</p>
              <p class="text-2xl font-bold text-nsknavy">24</p>
              <p class="text-xs text-gray-600">Across 3 sections</p>
            </div>
          </div>

          <div
            class="student-card card-animate bg-white rounded-xl shadow-md p-5 flex items-center"
          >
            <div class="bg-nskgold p-4 rounded-full mr-4">
              <i class="fas fa-award text-white text-xl"></i>
            </div>
            <div>
              <p class="text-gray-600">Top Performers</p>
              <p class="text-2xl font-bold text-nsknavy">87</p>
              <p class="text-xs text-nskgreen">90%+ average</p>
            </div>
          </div>

          <div
            class="student-card card-animate bg-white rounded-xl shadow-md p-5 flex items-center"
          >
            <div class="bg-nskred p-4 rounded-full mr-4">
              <i class="fas fa-exclamation-circle text-white text-xl"></i>
            </div>
            <div>
              <p class="text-gray-600">Sections</p>
              <p class="text-2xl font-bold text-nsknavy">3</p>
              <p class="text-xs text-nskgreen">Total sections</p>
            </div>
          </div>
        </div>

        <!-- Action Bar -->
        <div class="bg-white rounded-xl shadow-md p-6 mb-8 card-animate">
          <div
            class="flex flex-col md:flex-row md:items-center justify-between gap-4"
          >
            <h2 class="text-xl font-bold text-nsknavy">All Students</h2>

            <div class="flex flex-wrap gap-4">
              <select
                id="gradeFilter"
                class="px-4 py-2 border rounded-lg form-input focus:border-nskblue"
              >
                <option value="">All Grades</option>
                <option value="7">Grade 7</option>
                <option value="8">Grade 8</option>
                <option value="9">Grade 9</option>
                <option value="10">Grade 10</option>
                <option value="11">Grade 11</option>
                <option value="12">Grade 12</option>
              </select>

              <select
                id="classFilter"
                class="px-4 py-2 border rounded-lg form-input focus:border-nskblue"
              >
                <option value="">All Classes</option>
                <option value="a">Section A</option>
                <option value="b">Section B</option>
                <option value="c">Section C</option>
              </select>

              <button
                id="filterBtn"
                class="bg-nskblue text-white px-4 py-2 rounded-lg font-semibold hover:bg-nsknavy transition button-hover flex items-center"
              >
                <i class="fas fa-filter mr-2"></i> Filter
              </button>

              <button
                id="addStudentBtn"
                class="bg-nskgreen text-white px-4 py-2 rounded-lg font-semibold hover:bg-green-600 transition button-hover flex items-center"
              >
                <i class="fas fa-plus mr-2"></i> Add Student
              </button>

              <!-- Added bulk import and export functionality -->
              <button
                id="bulkImportBtn"
                class="bg-nskgold text-white px-4 py-2 rounded-lg font-semibold hover:bg-amber-600 transition button-hover flex items-center"
              >
                <i class="fas fa-file-import mr-2"></i> Bulk Import
              </button>

              <button
                id="exportBtn"
                class="bg-nskgold text-white px-4 py-2 rounded-lg font-semibold hover:bg-amber-600 transition button-hover flex items-center"
              >
                <i class="fas fa-file-export mr-2"></i> Export
              </button>

              <button
                id="generateIdCardsBtn"
                class="bg-purple-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-purple-700 transition button-hover flex items-center"
              >
                <i class="fas fa-id-card mr-2"></i> ID Cards
              </button>
            </div>
          </div>
        </div>

        <!-- Students Table -->
        <div
          class="bg-white rounded-xl shadow-md overflow-hidden mb-8 card-animate"
        >
          <div class="overflow-x-auto">
            <table class="min-w-full student-table">
              <thead>
                <tr>
                  <th class="py-3 px-6 text-left text-nsknavy">
                    <input type="checkbox" id="selectAll" class="mr-2" />
                    Student
                  </th>
                  <th class="py-3 px-6 text-left text-nsknavy">Grade/Class</th>
                  <th class="py-3 px-6 text-left text-nsknavy">
                    Academic Performance
                  </th>
                  <th class="py-3 px-6 text-left text-nsknavy">Attendance</th>
                  <th class="py-3 px-6 text-left text-nsknavy">
                    Medical Status
                  </th>
                  <th class="py-3 px-6 text-left text-nsknavy">Actions</th>
                </tr>
              </thead>
              <tbody id="studentsTableBody" class="divide-y divide-gray-200">
                <!-- Student rows will be populated by JavaScript -->
              </tbody>
            </table>
          </div>

          <!-- Pagination -->
          <div
            class="flex items-center justify-between border-t border-gray-200 px-6 py-4"
          >
            <div>
              <p class="text-sm text-gray-700">
                Showing <span class="font-medium" id="showingFrom">1</span> to
                <span class="font-medium" id="showingTo">5</span> of
                <span class="font-medium" id="totalCount">1,245</span> students
              </p>
            </div>
            <div class="flex space-x-2" id="pagination">
              <!-- Pagination buttons will be generated by JavaScript -->
            </div>
          </div>
        </div>
      </div>

      <!-- Enhanced Add Student Modal -->
      <div
        id="addStudentModal"
        class="modal fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      >
        <div
          class="bg-white rounded-xl shadow-2xl max-w-4xl w-full p-6 max-h-screen overflow-y-auto"
        >
          <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-bold text-nsknavy">
              Student Enrollment Workflow
            </h3>
            <button id="closeModal" class="text-gray-500 hover:text-gray-700">
              <i class="fas fa-times"></i>
            </button>
          </div>

          <!-- Progress Bar -->
          <div class="mb-6">
            <div class="flex justify-between items-center mb-2">
              <span class="text-sm font-medium text-nsknavy"
                >Enrollment Progress</span
              >
              <span class="text-sm font-medium text-nsknavy" id="progressText"
                >Step 1 of 4</span
              >
            </div>
            <div class="w-full bg-gray-200 rounded-full h-2">
              <div
                class="bg-nskblue h-2 rounded-full progress-bar"
                id="progressBar"
                style="width: 25%"
              ></div>
            </div>
          </div>

          <!-- Tab Navigation -->
          <div class="flex space-x-1 mb-6 bg-gray-100 p-1 rounded-lg">
            <button
              class="tab-button flex-1 py-2 px-4 rounded-md text-sm font-medium transition active"
              data-tab="basic"
            >
              <i class="fas fa-user mr-2"></i>Basic Info
            </button>
            <button
              class="tab-button flex-1 py-2 px-4 rounded-md text-sm font-medium transition"
              data-tab="parent"
            >
              <i class="fas fa-users mr-2"></i>Parent Info
            </button>
            <button
              class="tab-button flex-1 py-2 px-4 rounded-md text-sm font-medium transition"
              data-tab="medical"
            >
              <i class="fas fa-heartbeat mr-2"></i>Medical
            </button>
            <button
              class="tab-button flex-1 py-2 px-4 rounded-md text-sm font-medium transition"
              data-tab="documents"
            >
              <i class="fas fa-file-alt mr-2"></i>Documents
            </button>
          </div>

          <form id="studentForm" class="space-y-6">
            <!-- Basic Information Tab -->
            <div id="basicTab" class="tab-content active form-section">
              <h4 class="text-lg font-semibold text-nsknavy mb-4">
                Basic Information
              </h4>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label class="block text-gray-700 mb-2" for="firstName"
                    >First Name *</label
                  >
                  <input
                    type="text"
                    id="firstName"
                    class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                    required
                  />
                </div>

                <div>
                  <label class="block text-gray-700 mb-2" for="lastName"
                    >Last Name *</label
                  >
                  <input
                    type="text"
                    id="lastName"
                    class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                    required
                  />
                </div>

                <div>
                  <label class="block text-gray-700 mb-2" for="middleName"
                    >Middle Name</label
                  >
                  <input
                    type="text"
                    id="middleName"
                    class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                  />
                </div>

                <div>
                  <label class="block text-gray-700 mb-2" for="dob"
                    >Date of Birth *</label
                  >
                  <input
                    type="date"
                    id="dob"
                    class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                    required
                  />
                </div>

                <div>
                  <label class="block text-gray-700 mb-2" for="gender"
                    >Gender *</label
                  >
                  <select
                    id="gender"
                    class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                    required
                  >
                    <option value="">Select Gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                  </select>
                </div>

                <div>
                  <label class="block text-gray-700 mb-2" for="nationality"
                    >Nationality</label
                  >
                  <input
                    type="text"
                    id="nationality"
                    class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                    value="Nigerian"
                  />
                </div>

                <div>
                  <label class="block text-gray-700 mb-2" for="religion"
                    >Religion</label
                  >
                  <select
                    id="religion"
                    class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                  >
                    <option value="">Select Religion</option>
                    <option value="islam">Islam</option>
                    <option value="christianity">Christianity</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label class="block text-gray-700 mb-2" for="bloodGroup"
                    >Blood Group</label
                  >
                  <select
                    id="bloodGroup"
                    class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                  >
                    <option value="">Select Blood Group</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                  </select>
                </div>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label class="block text-gray-700 mb-2" for="grade"
                    >Grade *</label
                  >
                  <select
                    id="grade"
                    class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                    required
                  >
                    <option value="">Select Grade</option>
                    <option value="7">Grade 7</option>
                    <option value="8">Grade 8</option>
                    <option value="9">Grade 9</option>
                    <option value="10">Grade 10</option>
                    <option value="11">Grade 11</option>
                    <option value="12">Grade 12</option>
                  </select>
                </div>

                <div>
                  <label class="block text-gray-700 mb-2" for="section"
                    >Section *</label
                  >
                  <select
                    id="section"
                    class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                    required
                  >
                    <option value="">Select Section</option>
                    <option value="a">Section A</option>
                    <option value="b">Section B</option>
                    <option value="c">Section C</option>
                  </select>
                </div>
              </div>

              <div>
                <label class="block text-gray-700 mb-2" for="address"
                  >Home Address *</label
                >
                <textarea
                  id="address"
                  rows="3"
                  class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                  required
                ></textarea>
              </div>
            </div>

            <!-- Parent Information Tab -->
            <div id="parentTab" class="tab-content form-section">
              <h4 class="text-lg font-semibold text-nsknavy mb-4">
                Parent/Guardian Information
              </h4>

              <!-- Father's Information -->
              <div class="bg-gray-50 p-4 rounded-lg mb-4">
                <h5 class="font-semibold text-gray-700 mb-3">
                  Father's Information
                </h5>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label class="block text-gray-700 mb-2" for="fatherName"
                      >Father's Name *</label
                    >
                    <input
                      type="text"
                      id="fatherName"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                      required
                    />
                  </div>

                  <div>
                    <label class="block text-gray-700 mb-2" for="fatherPhone"
                      >Father's Phone *</label
                    >
                    <input
                      type="tel"
                      id="fatherPhone"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                      required
                    />
                  </div>

                  <div>
                    <label class="block text-gray-700 mb-2" for="fatherEmail"
                      >Father's Email</label
                    >
                    <input
                      type="email"
                      id="fatherEmail"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                    />
                  </div>

                  <div>
                    <label
                      class="block text-gray-700 mb-2"
                      for="fatherOccupation"
                      >Father's Occupation</label
                    >
                    <input
                      type="text"
                      id="fatherOccupation"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                    />
                  </div>
                </div>
              </div>

              <!-- Mother's Information -->
              <div class="bg-gray-50 p-4 rounded-lg mb-4">
                <h5 class="font-semibold text-gray-700 mb-3">
                  Mother's Information
                </h5>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label class="block text-gray-700 mb-2" for="motherName"
                      >Mother's Name *</label
                    >
                    <input
                      type="text"
                      id="motherName"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                      required
                    />
                  </div>

                  <div>
                    <label class="block text-gray-700 mb-2" for="motherPhone"
                      >Mother's Phone</label
                    >
                    <input
                      type="tel"
                      id="motherPhone"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                    />
                  </div>

                  <div>
                    <label class="block text-gray-700 mb-2" for="motherEmail"
                      >Mother's Email</label
                    >
                    <input
                      type="email"
                      id="motherEmail"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                    />
                  </div>

                  <div>
                    <label
                      class="block text-gray-700 mb-2"
                      for="motherOccupation"
                      >Mother's Occupation</label
                    >
                    <input
                      type="text"
                      id="motherOccupation"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                    />
                  </div>
                </div>
              </div>

              <!-- Emergency Contact -->
              <div class="bg-red-50 p-4 rounded-lg">
                <h5 class="font-semibold text-red-700 mb-3">
                  Emergency Contact
                </h5>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label class="block text-gray-700 mb-2" for="emergencyName"
                      >Emergency Contact Name *</label
                    >
                    <input
                      type="text"
                      id="emergencyName"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                      required
                    />
                  </div>

                  <div>
                    <label class="block text-gray-700 mb-2" for="emergencyPhone"
                      >Emergency Contact Phone *</label
                    >
                    <input
                      type="tel"
                      id="emergencyPhone"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                      required
                    />
                  </div>

                  <div>
                    <label
                      class="block text-gray-700 mb-2"
                      for="emergencyRelation"
                      >Relationship *</label
                    >
                    <select
                      id="emergencyRelation"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                      required
                    >
                      <option value="">Select Relationship</option>
                      <option value="father">Father</option>
                      <option value="mother">Mother</option>
                      <option value="guardian">Guardian</option>
                      <option value="uncle">Uncle</option>
                      <option value="aunt">Aunt</option>
                      <option value="grandparent">Grandparent</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            <!-- Medical Information Tab -->
            <div id="medicalTab" class="tab-content form-section">
              <h4 class="text-lg font-semibold text-nsknavy mb-4">
                Medical Records & Health Information
              </h4>

              <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="space-y-4">
                  <div>
                    <label class="block text-gray-700 mb-2" for="allergies"
                      >Known Allergies</label
                    >
                    <textarea
                      id="allergies"
                      rows="3"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                      placeholder="List any known allergies..."
                    ></textarea>
                  </div>

                  <div>
                    <label class="block text-gray-700 mb-2" for="medications"
                      >Current Medications</label
                    >
                    <textarea
                      id="medications"
                      rows="3"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                      placeholder="List current medications..."
                    ></textarea>
                  </div>

                  <div>
                    <label
                      class="block text-gray-700 mb-2"
                      for="medicalConditions"
                      >Medical Conditions</label
                    >
                    <textarea
                      id="medicalConditions"
                      rows="3"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                      placeholder="List any medical conditions..."
                    ></textarea>
                  </div>
                </div>

                <div class="space-y-4">
                  <div>
                    <label class="block text-gray-700 mb-2" for="doctorName"
                      >Family Doctor Name</label
                    >
                    <input
                      type="text"
                      id="doctorName"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                    />
                  </div>

                  <div>
                    <label class="block text-gray-700 mb-2" for="doctorPhone"
                      >Doctor's Phone</label
                    >
                    <input
                      type="tel"
                      id="doctorPhone"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                    />
                  </div>

                  <div>
                    <label
                      class="block text-gray-700 mb-2"
                      for="hospitalPreference"
                      >Preferred Hospital</label
                    >
                    <input
                      type="text"
                      id="hospitalPreference"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                    />
                  </div>

                  <div>
                    <label class="block text-gray-700 mb-2" for="insuranceInfo"
                      >Health Insurance Info</label
                    >
                    <input
                      type="text"
                      id="insuranceInfo"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                      placeholder="Insurance provider and policy number"
                    />
                  </div>
                </div>
              </div>

              <!-- Medical Alert Section -->
              <div class="bg-red-50 border border-red-200 p-4 rounded-lg mt-4">
                <div class="flex items-center mb-2">
                  <i
                    class="fas fa-exclamation-triangle text-red-600 mr-2 medical-alert"
                  ></i>
                  <h5 class="font-semibold text-red-700">Medical Alert</h5>
                </div>
                <div class="flex items-center">
                  <input type="checkbox" id="hasMedicalAlert" class="mr-2" />
                  <label for="hasMedicalAlert" class="text-gray-700"
                    >This student has critical medical conditions requiring
                    immediate attention</label
                  >
                </div>
                <div id="medicalAlertDetails" class="mt-3 hidden">
                  <textarea
                    id="alertDetails"
                    rows="2"
                    class="w-full px-4 py-2 border rounded-lg form-input focus:border-red-500"
                    placeholder="Describe the medical alert condition..."
                  ></textarea>
                </div>
              </div>
            </div>

            <!-- Documents Tab -->
            <div id="documentsTab" class="tab-content form-section">
              <h4 class="text-lg font-semibold text-nsknavy mb-4">
                Document Management
              </h4>

              <!-- File Upload Area -->
              <div
                class="file-drop-zone p-8 rounded-lg text-center mb-6"
                id="fileDropZone"
              >
                <i
                  class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-4"
                ></i>
                <p class="text-gray-600 mb-2">
                  Drag and drop files here or click to browse
                </p>
                <p class="text-sm text-gray-500">
                  Supported formats: PDF, JPG, PNG, DOC, DOCX (Max 5MB each)
                </p>
                <input
                  type="file"
                  id="fileInput"
                  multiple
                  accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                  class="hidden"
                />
                <button
                  type="button"
                  id="browseBtn"
                  class="mt-4 bg-nskblue text-white px-4 py-2 rounded-lg hover:bg-nsknavy transition"
                >
                  Browse Files
                </button>
              </div>

              <!-- Passport Photo Upload Section - ADD THIS -->
              <div class="bg-blue-50 p-4 rounded-lg mb-4 col-span-2">
                <h5 class="font-semibold text-nskblue mb-3">
                  Passport Photograph
                </h5>
                <div
                  class="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6"
                >
                  <div
                    class="w-32 h-40 border-2 border-dashed border-nskblue rounded-lg bg-white flex items-center justify-center"
                    id="photoPreview"
                  >
                    <i class="fas fa-user text-gray-400 text-2xl"></i>
                  </div>
                  <div class="flex-1">
                    <p class="text-sm text-gray-600 mb-2">
                      Upload a recent passport photograph (JPEG/PNG, max 2MB)
                    </p>
                    <div class="flex space-x-3">
                      <input
                        type="file"
                        accept="image/*"
                        class="hidden"
                        id="passportPhotoInput"
                      />
                      <button
                        type="button"
                        onclick="document.getElementById('passportPhotoInput').click()"
                        class="bg-nskblue text-white px-4 py-2 rounded-lg text-sm hover:bg-nsknavy transition flex items-center"
                      >
                        <i class="fas fa-upload mr-2"></i>Upload Photo
                      </button>
                      <button
                        type="button"
                        id="removePhotoBtn"
                        class="border border-red-500 text-red-500 px-4 py-2 rounded-lg text-sm hover:bg-red-50 transition hidden"
                      >
                        <i class="fas fa-trash mr-2"></i>Remove
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Required Documents Checklist -->
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div class="bg-gray-50 p-4 rounded-lg">
                  <h5 class="font-semibold text-gray-700 mb-3">
                    Required Documents
                  </h5>
                  <div class="space-y-2">
                    <label class="flex items-center">
                      <input
                        type="checkbox"
                        class="mr-2 document-checkbox"
                        data-doc="birth-certificate"
                      />
                      <span class="text-sm">Birth Certificate</span>
                    </label>
                    <label class="flex items-center">
                      <input
                        type="checkbox"
                        class="mr-2 document-checkbox"
                        data-doc="passport-photo"
                      />
                      <span class="text-sm">Passport Photograph</span>
                    </label>
                    <!-- ... rest of documents ... -->
                    <label class="flex items-center">
                      <input
                        type="checkbox"
                        class="mr-2 document-checkbox"
                        data-doc="previous-school"
                      />
                      <span class="text-sm">Previous School Certificate</span>
                    </label>
                    <label class="flex items-center">
                      <input
                        type="checkbox"
                        class="mr-2 document-checkbox"
                        data-doc="medical-report"
                      />
                      <span class="text-sm">Medical Report</span>
                    </label>
                  </div>
                </div>

                <div class="bg-gray-50 p-4 rounded-lg">
                  <h5 class="font-semibold text-gray-700 mb-3">
                    Optional Documents
                  </h5>
                  <div class="space-y-2">
                    <label class="flex items-center">
                      <input
                        type="checkbox"
                        class="mr-2 document-checkbox"
                        data-doc="immunization"
                      />
                      <span class="text-sm">Immunization Records</span>
                    </label>
                    <label class="flex items-center">
                      <input
                        type="checkbox"
                        class="mr-2 document-checkbox"
                        data-doc="parent-id"
                      />
                      <span class="text-sm">Parent ID Copy</span>
                    </label>
                    <label class="flex items-center">
                      <input
                        type="checkbox"
                        class="mr-2 document-checkbox"
                        data-doc="recommendation"
                      />
                      <span class="text-sm">Recommendation Letter</span>
                    </label>
                  </div>
                </div>
              </div>

              <!-- Uploaded Files List -->
              <div id="uploadedFilesList" class="space-y-2">
                <!-- Uploaded files will be displayed here -->
              </div>
            </div>

            <!-- Form Navigation -->
            <div class="flex justify-between pt-6 border-t">
              <button
                type="button"
                id="prevBtn"
                class="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition button-hover hidden"
              >
                <i class="fas fa-arrow-left mr-2"></i>Previous
              </button>

              <div class="flex space-x-3">
                <button
                  type="button"
                  id="cancelBtn"
                  class="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition button-hover"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  id="nextBtn"
                  class="px-6 py-2 bg-nskblue text-white rounded-lg font-semibold hover:bg-nsknavy transition button-hover"
                >
                  Next <i class="fas fa-arrow-right ml-2"></i>
                </button>
                <button
                  type="submit"
                  id="submitBtn"
                  class="px-6 py-2 bg-nskgreen text-white rounded-lg font-semibold hover:bg-green-600 transition button-hover hidden"
                >
                  <i class="fas fa-check mr-2"></i>Enroll Student
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>

      <!-- Bulk Import Modal -->
      <div
        id="bulkImportModal"
        class="modal fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      >
        <div class="bg-white rounded-xl shadow-2xl max-w-2xl w-full p-6">
          <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-bold text-nsknavy">Bulk Import Students</h3>
            <button
              id="closeBulkImportModal"
              class="text-gray-500 hover:text-gray-700"
            >
              <i class="fas fa-times"></i>
            </button>
          </div>

          <div class="space-y-6">
            <div class="text-center">
              <i class="fas fa-file-excel text-6xl text-nskgreen mb-4"></i>
              <h4 class="text-lg font-semibold text-nsknavy mb-2">
                Import Students from Excel/CSV
              </h4>
              <p class="text-gray-600">
                Upload a file with student data to add multiple students at once
              </p>
            </div>

            <div
              class="file-drop-zone p-8 rounded-lg text-center"
              id="bulkFileDropZone"
            >
              <i
                class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-4"
              ></i>
              <p class="text-gray-600 mb-2">
                Drag and drop your Excel/CSV file here
              </p>
              <p class="text-sm text-gray-500">
                Supported formats: .xlsx, .xls, .csv (Max 10MB)
              </p>
              <input
                type="file"
                id="bulkFileInput"
                accept=".xlsx,.xls,.csv"
                class="hidden"
              />
              <button
                type="button"
                id="bulkBrowseBtn"
                class="mt-4 bg-nskblue text-white px-4 py-2 rounded-lg hover:bg-nsknavy transition"
              >
                Browse Files
              </button>
            </div>

            <div class="bg-blue-50 p-4 rounded-lg">
              <h5 class="font-semibold text-nskblue mb-2">Template Format</h5>
              <p class="text-sm text-gray-600 mb-3">
                Your file should include these columns:
              </p>
              <div class="text-xs text-gray-600 grid grid-cols-2 gap-2">
                <div>• First Name</div>
                <div>• Last Name</div>
                <div>• Date of Birth</div>
                <div>• Gender</div>
                <div>• Grade</div>
                <div>• Section</div>
                <div>• Father's Name</div>
                <div>• Father's Phone</div>
                <div>• Mother's Name</div>
                <div>• Address</div>
                <div>• Blood Group</div>
              </div>
              <button
                id="downloadTemplateBtn"
                class="mt-3 text-nskblue hover:underline text-sm"
              >
                <i class="fas fa-download mr-1"></i>Download Template
              </button>
            </div>

            <div class="flex justify-end space-x-3">
              <button
                id="cancelBulkImport"
                class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition"
              >
                Cancel
              </button>
              <button
                id="processBulkImport"
                class="px-4 py-2 bg-nskgreen text-white rounded-lg font-semibold hover:bg-green-600 transition"
                disabled
              >
                <i class="fas fa-upload mr-2"></i>Import Students
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Student Details Modal -->
      <div
        id="studentDetailsModal"
        class="modal fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      >
        <div
          class="bg-white rounded-xl shadow-2xl max-w-4xl w-full p-6 max-h-screen overflow-y-auto"
        >
          <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-bold text-nsknavy">Student Details</h3>
            <button
              id="closeStudentDetailsModal"
              class="text-gray-500 hover:text-gray-700"
            >
              <i class="fas fa-times"></i>
            </button>
          </div>

          <div id="studentDetailsContent">
            <!-- Student details will be populated here -->
          </div>
        </div>
      </div>

      <!-- ID Card Generation Modal -->
      <div
        id="idCardModal"
        class="modal fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      >
        <div class="bg-white rounded-xl shadow-2xl max-w-3xl w-full p-6">
          <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-bold text-nsknavy">
              Generate Student ID Cards
            </h3>
            <button
              id="closeIdCardModal"
              class="text-gray-500 hover:text-gray-700"
            >
              <i class="fas fa-times"></i>
            </button>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- ID Card Preview -->
            <div>
              <h4 class="font-semibold text-nsknavy mb-4">ID Card Preview</h4>
              <div class="id-card text-white p-6 w-80 mx-auto">
                <div class="text-center mb-4">
                  <h5 class="font-bold text-lg">NORTHLAND SCHOOLS KANO</h5>
                  <p class="text-sm opacity-90">Student ID Card</p>
                </div>

                <div class="flex items-center space-x-4 mb-4">
                  <div
                    class="w-16 h-20 bg-white rounded border-2 border-white flex items-center justify-center"
                  >
                    <i class="fas fa-user text-gray-400 text-2xl"></i>
                  </div>
                  <div class="flex-1">
                    <p class="font-semibold text-lg" id="previewName">
                      Student Name
                    </p>
                    <p class="text-sm opacity-90" id="previewGrade">
                      Grade 10-A
                    </p>
                    <p class="text-sm opacity-90" id="previewId">
                      NSK-2024-001
                    </p>
                  </div>
                </div>

                <div class="text-xs space-y-1 opacity-90">
                  <p>Valid Until: <span id="previewExpiry">2025-06-30</span></p>
                  <p>
                    Emergency: <span id="previewEmergency">+234-xxx-xxxx</span>
                  </p>
                </div>
              </div>
            </div>

            <!-- Generation Options -->
            <div>
              <h4 class="font-semibold text-nsknavy mb-4">
                Generation Options
              </h4>
              <div class="space-y-4">
                <div>
                  <label class="block text-gray-700 mb-2"
                    >Select Students</label
                  >
                  <select
                    id="idCardStudentSelect"
                    class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                    multiple
                  >
                    <option value="all">All Students</option>
                    <option value="grade-7">Grade 7 Students</option>
                    <option value="grade-8">Grade 8 Students</option>
                    <option value="grade-9">Grade 9 Students</option>
                    <option value="grade-10">Grade 10 Students</option>
                    <option value="grade-11">Grade 11 Students</option>
                    <option value="grade-12">Grade 12 Students</option>
                  </select>
                </div>

                <div>
                  <label class="block text-gray-700 mb-2">Card Template</label>
                  <select
                    id="cardTemplate"
                    class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                  >
                    <option value="standard">Standard Template</option>
                    <option value="premium">Premium Template</option>
                    <option value="minimal">Minimal Template</option>
                  </select>
                </div>

                <div>
                  <label class="block text-gray-700 mb-2">Output Format</label>
                  <select
                    id="outputFormat"
                    class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                  >
                    <option value="pdf">PDF (Printable)</option>
                    <option value="png">PNG Images</option>
                    <option value="both">Both PDF and PNG</option>
                  </select>
                </div>

                <div class="flex items-center">
                  <input type="checkbox" id="includeBarcode" class="mr-2" />
                  <label for="includeBarcode" class="text-gray-700"
                    >Include QR Code</label
                  >
                </div>

                <div class="flex items-center">
                  <input type="checkbox" id="includePhoto" class="mr-2" />
                  <label for="includePhoto" class="text-gray-700"
                    >Include Student Photo</label
                  >
                </div>
              </div>

              <div class="mt-6 space-y-3">
                <button
                  id="generateIdCards"
                  class="w-full bg-nskblue text-white py-3 rounded-lg font-semibold hover:bg-nsknavy transition button-hover"
                >
                  <i class="fas fa-id-card mr-2"></i>Generate ID Cards
                </button>

                <button
                  id="previewIdCards"
                  class="w-full border border-nskblue text-nskblue py-3 rounded-lg font-semibold hover:bg-nsklight transition button-hover"
                >
                  <i class="fas fa-eye mr-2"></i>Preview Cards
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

<!-- Include footer -->
<script src="footer.js"></script>
    </main>

    <script>
      // Sample student data with enhanced information
      let studentsData = [
        {
          id: 'NSK-2023-001',
          firstName: 'Ahmad',
          lastName: 'Abdullahi',
          grade: '10',
          section: 'B',
          rollNo: '15',
          performance: 92,
          attendance: 96,
          medicalAlert: false,
          bloodGroup: 'A+',
          fatherName: 'Abdullahi Ahmad',
          fatherPhone: '+234-803-123-4567',
          motherName: 'Aisha Abdullahi',
          emergencyContact: '+234-803-123-4567',
          documents: ['birth-certificate', 'passport-photo', 'medical-report'],
        },
        {
          id: 'NSK-2023-012',
          firstName: 'Fatima',
          lastName: 'Mohammed',
          grade: '9',
          section: 'A',
          rollNo: '8',
          performance: 84,
          attendance: 92,
          medicalAlert: true,
          bloodGroup: 'O+',
          fatherName: 'Mohammed Ibrahim',
          fatherPhone: '+234-805-987-6543',
          motherName: 'Khadija Mohammed',
          emergencyContact: '+234-805-987-6543',
          documents: ['birth-certificate', 'passport-photo'],
        },
        {
          id: 'NSK-2023-045',
          firstName: 'Yusuf',
          lastName: 'Ibrahim',
          grade: '11',
          section: 'C',
          rollNo: '22',
          performance: 87,
          attendance: 88,
          medicalAlert: false,
          bloodGroup: 'B+',
          fatherName: 'Ibrahim Yusuf',
          fatherPhone: '+234-807-456-7890',
          motherName: 'Hauwa Ibrahim',
          emergencyContact: '+234-807-456-7890',
          documents: ['birth-certificate', 'passport-photo', 'previous-school'],
        },
        {
          id: 'NSK-2023-078',
          firstName: 'Hauwa',
          lastName: 'Abubakar',
          grade: '8',
          section: 'B',
          rollNo: '17',
          performance: 63,
          attendance: 72,
          medicalAlert: true,
          bloodGroup: 'AB+',
          fatherName: 'Abubakar Hassan',
          fatherPhone: '+234-809-234-5678',
          motherName: 'Zainab Abubakar',
          emergencyContact: '+234-809-234-5678',
          documents: ['birth-certificate'],
        },
        {
          id: 'NSK-2023-103',
          firstName: 'Zainab',
          lastName: 'Mohammed',
          grade: '12',
          section: 'A',
          rollNo: '5',
          performance: 96,
          attendance: 98,
          medicalAlert: false,
          bloodGroup: 'O-',
          fatherName: 'Mohammed Ali',
          fatherPhone: '+234-811-345-6789',
          motherName: 'Amina Mohammed',
          emergencyContact: '+234-811-345-6789',
          documents: [
            'birth-certificate',
            'passport-photo',
            'medical-report',
            'immunization',
          ],
        },
      ];

      let currentPage = 1;
      let itemsPerPage = 5;
      let filteredStudents = [...studentsData];
      let currentTab = 'basic';
      let uploadedFiles = [];

      // Initialize the application
      document.addEventListener('DOMContentLoaded', function () {
        // Initialize sidebar with current page
        const currentPage = window.location.pathname.split('/').pop();
        if (window.sidebarManager) {
          window.sidebarManager.init(currentPage);
        }
        
        initializeEventListeners();
        renderStudentsTable();
        updateStats();
      });

      function initializeEventListeners() {
        // Modal functionality
        document
          .getElementById('addStudentBtn')
          .addEventListener('click', () => openModal('addStudentModal'));
        document
          .getElementById('closeModal')
          .addEventListener('click', () => closeModal('addStudentModal'));
        document
          .getElementById('cancelBtn')
          .addEventListener('click', () => closeModal('addStudentModal'));

        // Bulk import modal
        document
          .getElementById('bulkImportBtn')
          .addEventListener('click', () => openModal('bulkImportModal'));
        document
          .getElementById('closeBulkImportModal')
          .addEventListener('click', () => closeModal('bulkImportModal'));
        document
          .getElementById('cancelBulkImport')
          .addEventListener('click', () => closeModal('bulkImportModal'));

        // ID Card modal
        document
          .getElementById('generateIdCardsBtn')
          .addEventListener('click', () => openModal('idCardModal'));
        document
          .getElementById('closeIdCardModal')
          .addEventListener('click', () => closeModal('idCardModal'));

        // Student details modal
        document
          .getElementById('closeStudentDetailsModal')
          .addEventListener('click', () => closeModal('studentDetailsModal'));

        // Tab navigation
        document.querySelectorAll('.tab-button').forEach((button) => {
          button.addEventListener('click', (e) =>
            switchTab(e.target.dataset.tab),
          );
        });

        // Form navigation
        document.getElementById('nextBtn').addEventListener('click', nextStep);
        document.getElementById('prevBtn').addEventListener('click', prevStep);
        document
          .getElementById('studentForm')
          .addEventListener('submit', handleFormSubmit);

        // Search and filter
        document
          .getElementById('searchInput')
          .addEventListener('input', handleSearch);
        document
          .getElementById('filterBtn')
          .addEventListener('click', applyFilters);
        document
          .getElementById('exportBtn')
          .addEventListener('click', exportStudents);

        // File upload
        setupFileUpload();
        setupBulkImport();
        setupPassportPhotoUpload();

        // Medical alert checkbox
        document
          .getElementById('hasMedicalAlert')
          .addEventListener('change', toggleMedicalAlert);

        // Select all checkbox
        document
          .getElementById('selectAll')
          .addEventListener('change', toggleSelectAll);

        // ID Card generation
        document
          .getElementById('generateIdCards')
          .addEventListener('click', generateIdCards);
        document
          .getElementById('previewIdCards')
          .addEventListener('click', previewIdCards);
      }

      function openModal(modalId) {
        const modal = document.getElementById(modalId);
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
      }

      function closeModal(modalId) {
        const modal = document.getElementById(modalId);
        modal.classList.remove('active');
        document.body.style.overflow = 'auto';

        if (modalId === 'addStudentModal') {
          resetForm();
        }
      }

      function switchTab(tabName) {
        // Update tab buttons
        document.querySelectorAll('.tab-button').forEach((btn) => {
          btn.classList.remove('active');
        });
        document
          .querySelector(`[data-tab="${tabName}"]`)
          .classList.add('active');

        // Update tab content
        document.querySelectorAll('.tab-content').forEach((content) => {
          content.classList.remove('active');
        });
        document.getElementById(`${tabName}Tab`).classList.add('active');

        currentTab = tabName;
        updateProgress();
      }

      function nextStep() {
        const tabs = ['basic', 'parent', 'medical', 'documents'];
        const currentIndex = tabs.indexOf(currentTab);

        if (currentIndex < tabs.length - 1) {
          switchTab(tabs[currentIndex + 1]);
        }
      }

      function prevStep() {
        const tabs = ['basic', 'parent', 'medical', 'documents'];
        const currentIndex = tabs.indexOf(currentTab);

        if (currentIndex > 0) {
          switchTab(tabs[currentIndex - 1]);
        }
      }

      function updateProgress() {
        const tabs = ['basic', 'parent', 'medical', 'documents'];
        const currentIndex = tabs.indexOf(currentTab);
        const progress = ((currentIndex + 1) / tabs.length) * 100;

        document.getElementById('progressBar').style.width = `${progress}%`;
        document.getElementById('progressText').textContent = `Step ${
          currentIndex + 1
        } of ${tabs.length}`;

        // Show/hide navigation buttons
        document
          .getElementById('prevBtn')
          .classList.toggle('hidden', currentIndex === 0);
        document
          .getElementById('nextBtn')
          .classList.toggle('hidden', currentIndex === tabs.length - 1);
        document
          .getElementById('submitBtn')
          .classList.toggle('hidden', currentIndex !== tabs.length - 1);
      }

      function resetForm() {
        document.getElementById('studentForm').reset();
        switchTab('basic');
        uploadedFiles = [];
        document.getElementById('uploadedFilesList').innerHTML = '';
        document.getElementById('medicalAlertDetails').classList.add('hidden');
      }

      function handleFormSubmit(e) {
        e.preventDefault();

        // Collect form data
        const formData = new FormData(e.target);
        const studentData = Object.fromEntries(formData.entries());

        // Generate student ID
        const studentId = `NSK-${new Date().getFullYear()}-${String(
          studentsData.length + 1,
        ).padStart(3, '0')}`;

        // Add to students data
        const newStudent = {
          id: studentId,
          firstName: studentData.firstName,
          lastName: studentData.lastName,
          grade: studentData.grade,
          section: studentData.section,
          rollNo: String(Math.floor(Math.random() * 30) + 1),
          performance: Math.floor(Math.random() * 40) + 60,
          attendance: Math.floor(Math.random() * 30) + 70,
          medicalAlert: document.getElementById('hasMedicalAlert').checked,
          bloodGroup: studentData.bloodGroup || 'Unknown',
          fatherName: studentData.fatherName,
          fatherPhone: studentData.fatherPhone,
          motherName: studentData.motherName,
          emergencyContact: studentData.emergencyPhone,
          documents: uploadedFiles.map((file) => file.type),
        };

        studentsData.push(newStudent);
        filteredStudents = [...studentsData];

        // Show success message
        showNotification(
          `Student ${studentData.firstName} ${studentData.lastName} enrolled successfully!`,
          'success',
        );

        // Close modal and refresh table
        closeModal('addStudentModal');
        renderStudentsTable();
        updateStats();
      }

      function renderStudentsTable() {
        const tbody = document.getElementById('studentsTableBody');
        const startIndex = (currentPage - 1) * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const pageStudents = filteredStudents.slice(startIndex, endIndex);

        tbody.innerHTML = pageStudents
          .map(
            (student) => `
                <tr class="hover:bg-gray-50 transition-all duration-300">
                    <td class="py-4 px-6">
                        <div class="flex items-center">
                            <input type="checkbox" class="student-checkbox mr-3" data-id="${
                              student.id
                            }">
                            <div class="w-10 h-10 rounded-full ${getAvatarColor(
                              student.firstName,
                            )} flex items-center justify-center text-white font-bold mr-3">
                                ${student.firstName.charAt(
                                  0,
                                )}${student.lastName.charAt(0)}
                            </div>
                            <div>
                                <p class="font-semibold">${student.firstName} ${
              student.lastName
            }</p>
                                <p class="text-sm text-gray-600">ID: ${
                                  student.id
                                }</p>
                            </div>
                        </div>
                    </td>
                    <td class="py-4 px-6">
                        <p class="font-medium">Grade ${
                          student.grade
                        }-${student.section.toUpperCase()}</p>
                        <p class="text-sm text-gray-600">Roll No: ${
                          student.rollNo
                        }</p>
                    </td>
                    <td class="py-4 px-6">
                        <div class="flex items-center">
                            <span class="grade-badge ${getGradeBadgeClass(
                              student.performance,
                            )}">${getGrade(student.performance)} (${
              student.performance
            }%)</span>
                        </div>
                    </td>
                    <td class="py-4 px-6">
                        <div class="flex items-center">
                            <div class="w-16 bg-gray-200 rounded-full h-2 mr-2">
                                <div class="bg-nskgreen h-2 rounded-full progress-bar" style="width: ${
                                  student.attendance
                                }%"></div>
                            </div>
                            <span class="text-sm">${student.attendance}%</span>
                        </div>
                    </td>
                    <td class="py-4 px-6">
                        <div class="flex items-center">
                            ${
                              student.medicalAlert
                                ? '<i class="fas fa-exclamation-triangle text-red-500 medical-alert mr-2"></i><span class="text-red-600 text-sm">Alert</span>'
                                : '<i class="fas fa-check-circle text-green-500 mr-2"></i><span class="text-green-600 text-sm">Normal</span>'
                            }
                        </div>
                    </td>
                    <td class="py-4 px-6">
                        <div class="flex space-x-2">
                            <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 transition button-hover" onclick="viewStudent('${
                              student.id
                            }')">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 transition button-hover" onclick="editStudent('${
                              student.id
                            }')">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="text-nskred hover:text-red-700 p-2 rounded-full hover:bg-red-50 transition button-hover" onclick="deleteStudent('${
                              student.id
                            }')">
                                <i class="fas fa-trash"></i>
                            </button>
                            <button class="text-purple-600 hover:text-purple-700 p-2 rounded-full hover:bg-purple-50 transition button-hover" onclick="generateSingleIdCard('${
                              student.id
                            }')">
                                <i class="fas fa-id-card"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `,
          )
          .join('');

        updatePagination();
      }

      function getAvatarColor(name) {
        const colors = [
          'bg-nskblue',
          'bg-nskgreen',
          'bg-nskgold',
          'bg-nskred',
          'bg-purple-500',
        ];
        const index = name.charCodeAt(0) % colors.length;
        return colors[index];
      }

      function getGradeBadgeClass(performance) {
        if (performance >= 90) return 'bg-green-100 text-nskgreen';
        if (performance >= 80) return 'bg-blue-100 text-nskblue';
        if (performance >= 70) return 'bg-amber-100 text-amber-700';
        return 'bg-red-100 text-nskred';
      }

      function getGrade(performance) {
        if (performance >= 90) return 'A';
        if (performance >= 80) return 'B';
        if (performance >= 70) return 'C';
        if (performance >= 60) return 'D';
        return 'F';
      }

      function updatePagination() {
        const totalPages = Math.ceil(filteredStudents.length / itemsPerPage);
        const pagination = document.getElementById('pagination');

        let paginationHTML = '';

        // Previous button
        paginationHTML += `
                <button class="px-3 py-1 rounded border text-sm font-medium text-gray-700 hover:bg-gray-50 transition ${
                  currentPage === 1 ? 'opacity-50 cursor-not-allowed' : ''
                }" 
                        onclick="changePage(${currentPage - 1})" ${
          currentPage === 1 ? 'disabled' : ''
        }>
                    Previous
                </button>
            `;

        // Page numbers
        for (let i = 1; i <= Math.min(totalPages, 5); i++) {
          paginationHTML += `
                    <button class="px-3 py-1 rounded border text-sm font-medium transition ${
                      i === currentPage
                        ? 'border-nskblue bg-nskblue text-white'
                        : 'text-gray-700 hover:bg-gray-50'
                    }" 
                            onclick="changePage(${i})">
                        ${i}
                    </button>
                `;
        }

        // Next button
        paginationHTML += `
                <button class="px-3 py-1 rounded border text-sm font-medium text-gray-700 hover:bg-gray-50 transition ${
                  currentPage === totalPages
                    ? 'opacity-50 cursor-not-allowed'
                    : ''
                }" 
                        onclick="changePage(${currentPage + 1})" ${
          currentPage === totalPages ? 'disabled' : ''
        }>
                    Next
                </button>
            `;

        pagination.innerHTML = paginationHTML;

        // Update showing info
        const startIndex = (currentPage - 1) * itemsPerPage + 1;
        const endIndex = Math.min(
          currentPage * itemsPerPage,
          filteredStudents.length,
        );

        document.getElementById('showingFrom').textContent = startIndex;
        document.getElementById('showingTo').textContent = endIndex;
        document.getElementById('totalCount').textContent =
          filteredStudents.length;
      }

      function changePage(page) {
        const totalPages = Math.ceil(filteredStudents.length / itemsPerPage);
        if (page >= 1 && page <= totalPages) {
          currentPage = page;
          renderStudentsTable();
        }
      }

      function handleSearch(e) {
        const searchTerm = e.target.value.toLowerCase();
        filteredStudents = studentsData.filter(
          (student) =>
            student.firstName.toLowerCase().includes(searchTerm) ||
            student.lastName.toLowerCase().includes(searchTerm) ||
            student.id.toLowerCase().includes(searchTerm),
        );
        currentPage = 1;
        renderStudentsTable();
      }

      function applyFilters() {
        const gradeFilter = document.getElementById('gradeFilter').value;
        const classFilter = document.getElementById('classFilter').value;

        filteredStudents = studentsData.filter((student) => {
          const gradeMatch = !gradeFilter || student.grade === gradeFilter;
          const classMatch =
            !classFilter || student.section.toLowerCase() === classFilter;
          return gradeMatch && classMatch;
        });

        currentPage = 1;
        renderStudentsTable();
        showNotification('Filters applied successfully!', 'info');
      }

      function updateStats() {
        document.getElementById('totalStudents').textContent =
          studentsData.length.toLocaleString();
      }

      function viewStudent(studentId) {
        const student = studentsData.find((s) => s.id === studentId);
        if (!student) return;

        const modalContent = document.getElementById('studentDetailsContent');
        modalContent.innerHTML = `
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="space-y-4">
                        <div class="bg-gray-50 p-4 rounded-lg">
                            <h4 class="font-semibold text-nsknavy mb-3">Personal Information</h4>
                            <div class="space-y-2">
                                <p><span class="font-medium">Name:</span> ${
                                  student.firstName
                                } ${student.lastName}</p>
                                <p><span class="font-medium">Student ID:</span> ${
                                  student.id
                                }</p>
                                <p><span class="font-medium">Grade:</span> ${
                                  student.grade
                                }-${student.section.toUpperCase()}</p>
                                <p><span class="font-medium">Roll Number:</span> ${
                                  student.rollNo
                                }</p>
                                <p><span class="font-medium">Blood Group:</span> ${
                                  student.bloodGroup
                                }</p>
                            </div>
                        </div>
                        
                        <div class="bg-gray-50 p-4 rounded-lg">
                            <h4 class="font-semibold text-nsknavy mb-3">Academic Performance</h4>
                            <div class="space-y-2">
                                <p><span class="font-medium">Overall Grade:</span> ${getGrade(
                                  student.performance,
                                )} (${student.performance}%)</p>
                                <p><span class="font-medium">Attendance:</span> ${
                                  student.attendance
                                }%</p>
                                <div class="w-full bg-gray-200 rounded-full h-2">
                                    <div class="bg-nskgreen h-2 rounded-full" style="width: ${
                                      student.attendance
                                    }%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="space-y-4">
                        <div class="bg-gray-50 p-4 rounded-lg">
                            <h4 class="font-semibold text-nsknavy mb-3">Parent Information</h4>
                            <div class="space-y-2">
                                <p><span class="font-medium">Father:</span> ${
                                  student.fatherName
                                }</p>
                                <p><span class="font-medium">Father's Phone:</span> ${
                                  student.fatherPhone
                                }</p>
                                <p><span class="font-medium">Mother:</span> ${
                                  student.motherName
                                }</p>
                                <p><span class="font-medium">Emergency Contact:</span> ${
                                  student.emergencyContact
                                }</p>
                            </div>
                        </div>
                        
                        <div class="bg-gray-50 p-4 rounded-lg">
                            <h4 class="font-semibold text-nsknavy mb-3">Medical Status</h4>
                            <div class="space-y-2">
                                <p><span class="font-medium">Medical Alert:</span> 
                                    ${
                                      student.medicalAlert
                                        ? '<span class="text-red-600">Yes - Requires Attention</span>'
                                        : '<span class="text-green-600">No Issues</span>'
                                    }
                                </p>
                                <p><span class="font-medium">Documents:</span> ${
                                  student.documents.length
                                } uploaded</p>
                            </div>
                        </div>
                    </div>
                </div>
            `;

        openModal('studentDetailsModal');
      }

      function editStudent(studentId) {
        showNotification(
          `Edit functionality for student ${studentId} - Coming soon!`,
          'info',
        );
      }

      function deleteStudent(studentId) {
        const student = studentsData.find((s) => s.id === studentId);
        if (!student) return;

        if (
          confirm(
            `Are you sure you want to delete ${student.firstName} ${student.lastName}?`,
          )
        ) {
          studentsData = studentsData.filter((s) => s.id !== studentId);
          filteredStudents = filteredStudents.filter((s) => s.id !== studentId);
          renderStudentsTable();
          updateStats();
          showNotification('Student deleted successfully!', 'success');
        }
      }

      function exportStudents() {
        const csvContent = generateCSV(filteredStudents);
        downloadCSV(csvContent, 'students_export.csv');
        showNotification('Students exported successfully!', 'success');
      }

      function generateCSV(data) {
        const headers = [
          'ID',
          'First Name',
          'Last Name',
          'Grade',
          'Section',
          'Performance',
          'Attendance',
          'Father Name',
          'Father Phone',
        ];
        const csvRows = [headers.join(',')];

        data.forEach((student) => {
          const row = [
            student.id,
            student.firstName,
            student.lastName,
            student.grade,
            student.section,
            student.performance,
            student.attendance,
            student.fatherName,
            student.fatherPhone,
          ];
          csvRows.push(row.join(','));
        });

        return csvRows.join('\n');
      }

      function downloadCSV(content, filename) {
        const blob = new Blob([content], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        window.URL.revokeObjectURL(url);
      }

      function setupFileUpload() {
        const fileDropZone = document.getElementById('fileDropZone');
        const fileInput = document.getElementById('fileInput');
        const browseBtn = document.getElementById('browseBtn');

        browseBtn.addEventListener('click', () => fileInput.click());

        fileDropZone.addEventListener('dragover', (e) => {
          e.preventDefault();
          fileDropZone.classList.add('dragover');
        });

        fileDropZone.addEventListener('dragleave', () => {
          fileDropZone.classList.remove('dragover');
        });

        fileDropZone.addEventListener('drop', (e) => {
          e.preventDefault();
          fileDropZone.classList.remove('dragover');
          handleFiles(e.dataTransfer.files);
        });

        fileInput.addEventListener('change', (e) => {
          handleFiles(e.target.files);
        });
      }

      // Passport Photo Upload Functionality
      function setupPassportPhotoUpload() {
        const photoInput = document.getElementById('passportPhotoInput');
        const photoPreview = document.getElementById('photoPreview');
        const removePhotoBtn = document.getElementById('removePhotoBtn');

        photoInput.addEventListener('change', function (e) {
          const file = e.target.files[0];
          if (file) {
            if (file.size > 2 * 1024 * 1024) {
              showNotification('Photo size must be less than 2MB', 'error');
              return;
            }

            const reader = new FileReader();
            reader.onload = function (e) {
              photoPreview.innerHTML = `<img src="${e.target.result}" class="w-full h-full object-cover rounded-lg">`;
              removePhotoBtn.classList.remove('hidden');

              // Auto-check the passport photo checkbox
              const passportCheckbox = document.querySelector(
                'input[data-doc="passport-photo"]',
              );
              if (passportCheckbox) {
                passportCheckbox.checked = true;
              }
            };
            reader.readAsDataURL(file);
          }
        });

        removePhotoBtn.addEventListener('click', function () {
          photoInput.value = '';
          photoPreview.innerHTML =
            '<i class="fas fa-user text-gray-400 text-2xl"></i>';
          removePhotoBtn.classList.add('hidden');

          // Uncheck the passport photo checkbox
          const passportCheckbox = document.querySelector(
            'input[data-doc="passport-photo"]',
          );
          if (passportCheckbox) {
            passportCheckbox.checked = false;
          }
        });
      }

      function handleFiles(files) {
        Array.from(files).forEach((file) => {
          if (file.size > 5 * 1024 * 1024) {
            showNotification(
              `File ${file.name} is too large. Maximum size is 5MB.`,
              'error',
            );
            return;
          }

          uploadedFiles.push({
            name: file.name,
            size: file.size,
            type: getDocumentType(file.name),
            file: file,
          });
        });

        displayUploadedFiles();
      }

      function getDocumentType(filename) {
        const ext = filename.split('.').pop().toLowerCase();
        if (filename.toLowerCase().includes('birth'))
          return 'birth-certificate';
        if (
          filename.toLowerCase().includes('photo') ||
          ['jpg', 'jpeg', 'png'].includes(ext)
        )
          return 'passport-photo';
        if (filename.toLowerCase().includes('medical')) return 'medical-report';
        if (filename.toLowerCase().includes('school')) return 'previous-school';
        return 'other';
      }

      function displayUploadedFiles() {
        const container = document.getElementById('uploadedFilesList');
        container.innerHTML = uploadedFiles
          .map(
            (file, index) => `
                <div class="document-item flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div class="flex items-center">
                        <i class="fas fa-file-alt text-nskblue mr-3"></i>
                        <div>
                            <p class="font-medium">${file.name}</p>
                            <p class="text-sm text-gray-600">${(
                              file.size / 1024
                            ).toFixed(1)} KB</p>
                        </div>
                    </div>
                    <button onclick="removeFile(${index})" class="text-red-500 hover:text-red-700">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `,
          )
          .join('');
      }

      function removeFile(index) {
        uploadedFiles.splice(index, 1);
        displayUploadedFiles();
      }

      function setupBulkImport() {
        const bulkFileDropZone = document.getElementById('bulkFileDropZone');
        const bulkFileInput = document.getElementById('bulkFileInput');
        const bulkBrowseBtn = document.getElementById('bulkBrowseBtn');
        const processBulkImport = document.getElementById('processBulkImport');
        const downloadTemplateBtn = document.getElementById(
          'downloadTemplateBtn',
        );

        bulkBrowseBtn.addEventListener('click', () => bulkFileInput.click());

        bulkFileInput.addEventListener('change', (e) => {
          if (e.target.files.length > 0) {
            processBulkImport.disabled = false;
            showNotification('File selected. Ready to import!', 'info');
          }
        });

        processBulkImport.addEventListener('click', () => {
          const file = bulkFileInput.files[0];
          if (!file) return;

          // Real CSV processing
          const reader = new FileReader();
          reader.onload = function (e) {
            try {
              const csv = e.target.result;
              const lines = csv.split('\n');
              const headers = lines[0].split(',').map((h) => h.trim());

              let importedCount = 0;
              for (let i = 1; i < lines.length; i++) {
                if (lines[i].trim() === '') continue;

                const values = lines[i].split(',').map((v) => v.trim());
                if (values.length >= headers.length) {
                  const studentData = {};
                  headers.forEach((header, index) => {
                    studentData[header.toLowerCase().replace(/\s+/g, '')] =
                      values[index];
                  });

                  // Create new student object
                  const newStudent = {
                    id: `NSK-${new Date().getFullYear()}-${String(
                      studentsData.length + importedCount + 1,
                    ).padStart(3, '0')}`,
                    firstName:
                      studentData.firstname ||
                      studentData.name?.split(' ')[0] ||
                      'Unknown',
                    lastName:
                      studentData.lastname ||
                      studentData.name?.split(' ')[1] ||
                      'Student',
                    grade: studentData.grade || '10',
                    section: studentData.section || 'A',
                    rollNo: String(Math.floor(Math.random() * 30) + 1),
                    performance: Math.floor(Math.random() * 40) + 60,
                    attendance: Math.floor(Math.random() * 30) + 70,
                    medicalAlert: false,
                    bloodGroup: studentData.bloodgroup || 'Unknown',
                    fatherName: studentData.fathername || 'Unknown',
                    fatherPhone: studentData.fatherphone || '+234-xxx-xxxx',
                    motherName: studentData.mothername || 'Unknown',
                    emergencyContact:
                      studentData.fatherphone || '+234-xxx-xxxx',
                    documents: [],
                  };

                  studentsData.push(newStudent);
                  importedCount++;
                }
              }

              filteredStudents = [...studentsData];
              renderStudentsTable();
              updateStats();

              showNotification(
                `Successfully imported ${importedCount} students!`,
                'success',
              );
              closeModal('bulkImportModal');
            } catch (error) {
              showNotification(
                'Error processing CSV file. Please check the format.',
                'error',
              );
            }
          };
          reader.readAsText(file);
        });

        downloadTemplateBtn.addEventListener('click', () => {
          const templateContent =
            'First Name,Last Name,Date of Birth,Gender,Grade,Section,Father Name,Father Phone,Mother Name,Address,Blood Group\nAhmad,Abdullahi,2008-05-15,Male,10,A,Abdullahi Ahmad,+234-803-123-4567,Aisha Abdullahi,123 Kano Street,A+\nFatima,Mohammed,2009-03-20,Female,9,B,Mohammed Ibrahim,+234-805-987-6543,Khadija Mohammed,456 Kaduna Road,O+';
          downloadCSV(templateContent, 'student_import_template.csv');
        });
      }

      function toggleMedicalAlert() {
        const checkbox = document.getElementById('hasMedicalAlert');
        const details = document.getElementById('medicalAlertDetails');

        if (checkbox.checked) {
          details.classList.remove('hidden');
        } else {
          details.classList.add('hidden');
        }
      }

      function toggleSelectAll() {
        const selectAll = document.getElementById('selectAll');
        const checkboxes = document.querySelectorAll('.student-checkbox');

        checkboxes.forEach((checkbox) => {
          checkbox.checked = selectAll.checked;
        });
      }

      async function generateRealIdCards(studentIds) {
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF('p', 'mm', 'a4');
        let isFirstCard = true;

        for (const studentId of studentIds) {
          const student = studentsData.find((s) => s.id === studentId);
          if (!student) continue;

          if (!isFirstCard) {
            pdf.addPage();
          }

          // Create ID card HTML
          const cardHtml = createIdCardHtml(student);
          const cardElement = document.createElement('div');
          cardElement.innerHTML = cardHtml;
          cardElement.style.position = 'absolute';
          cardElement.style.left = '-9999px';
          document.body.appendChild(cardElement);

          try {
            // Convert to canvas and add to PDF
            const canvas = await html2canvas(cardElement.firstChild, {
              scale: 2,
              backgroundColor: '#ffffff',
              width: 340,
              height: 215,
            });

            const imgData = canvas.toDataURL('image/png');

            // Add to PDF (85mm x 54mm - standard ID card size)
            pdf.addImage(imgData, 'PNG', 10, 10, 85, 54);

            // Add second card on same page if space allows
            if (studentIds.indexOf(studentId) % 2 === 1) {
              pdf.addImage(imgData, 'PNG', 105, 10, 85, 54);
            }
          } catch (error) {
            console.error('Error generating ID card:', error);
          }

          document.body.removeChild(cardElement);
          isFirstCard = false;
        }

        // Download the PDF
        const fileName = `student_id_cards_${
          new Date().toISOString().split('T')[0]
        }.pdf`;
        pdf.save(fileName);

        showNotification(
          'ID cards generated and downloaded successfully!',
          'success',
        );
        closeModal('idCardModal');
      }

      function createIdCardHtml(student) {
        const currentDate = new Date();
        const expiryDate = new Date(currentDate.getFullYear() + 1, 5, 30); // June 30 next year

        return `
                <div style="width: 340px; height: 215px; background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%); border-radius: 15px; color: white; font-family: 'Montserrat', sans-serif; position: relative; overflow: hidden;">
                    <!-- School Header -->
                    <div style="text-align: center; padding: 15px 20px 10px; border-bottom: 1px solid rgba(255,255,255,0.2);">
                        <h3 style="margin: 0; font-size: 16px; font-weight: bold; letter-spacing: 0.5px;">NORTHLAND SCHOOLS KANO</h3>
                        <p style="margin: 2px 0 0; font-size: 10px; opacity: 0.9;">STUDENT IDENTIFICATION CARD</p>
                    </div>
                    
                    <!-- Student Info Section -->
                    <div style="display: flex; padding: 15px 20px; align-items: center;">
                        <!-- Photo Placeholder -->
                        <div style="width: 60px; height: 75px; background: white; border-radius: 8px; margin-right: 15px; display: flex; align-items: center; justify-content: center; border: 2px solid #f59e0b;">
                            <div style="width: 50px; height: 50px; background: #1e40af; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 18px;">
                                ${student.firstName.charAt(
                                  0,
                                )}${student.lastName.charAt(0)}
                            </div>
                        </div>
                        
                        <!-- Student Details -->
                        <div style="flex: 1;">
                            <h4 style="margin: 0 0 5px; font-size: 18px; font-weight: bold;">${
                              student.firstName
                            } ${student.lastName}</h4>
                            <p style="margin: 2px 0; font-size: 12px; opacity: 0.9;">Grade ${
                              student.grade
                            }-${student.section.toUpperCase()}</p>
                            <p style="margin: 2px 0; font-size: 12px; opacity: 0.9;">ID: ${
                              student.id
                            }</p>
                            <p style="margin: 2px 0; font-size: 11px; opacity: 0.8;">Blood Group: ${
                              student.bloodGroup
                            }</p>
                        </div>
                    </div>
                    
                    <!-- Footer Info -->
                    <div style="position: absolute; bottom: 15px; left: 20px; right: 20px;">
                        <div style="display: flex; justify-content: space-between; font-size: 9px; opacity: 0.8;">
                            <span>Valid Until: ${expiryDate.toLocaleDateString()}</span>
                            <span>Emergency: ${student.emergencyContact}</span>
                        </div>
                        <div style="text-align: center; margin-top: 5px; font-size: 8px; opacity: 0.7;">
                            www.northlandschools.com | +91-9950348952
                        </div>
                    </div>
                    
                    <!-- Decorative Elements -->
                    <div style="position: absolute; top: -20px; right: -20px; width: 80px; height: 80px; background: rgba(245, 158, 11, 0.1); border-radius: 50%;"></div>
                    <div style="position: absolute; bottom: -30px; left: -30px; width: 100px; height: 100px; background: rgba(245, 158, 11, 0.05); border-radius: 50%;"></div>
                </div>
            `;
      }

      function showIdCardPreview(studentId) {
        const student = studentsData.find((s) => s.id === studentId);
        if (!student) return;

        // Update preview in modal
        document.getElementById(
          'previewName',
        ).textContent = `${student.firstName} ${student.lastName}`;
        document.getElementById('previewGrade').textContent = `Grade ${
          student.grade
        }-${student.section.toUpperCase()}`;
        document.getElementById('previewId').textContent = student.id;
        document.getElementById('previewEmergency').textContent =
          student.emergencyContact;

        const currentDate = new Date();
        const expiryDate = new Date(currentDate.getFullYear() + 1, 5, 30);
        document.getElementById('previewExpiry').textContent =
          expiryDate.toLocaleDateString();

        showNotification('Preview updated with selected student data!', 'info');
      }

      function generateIdCards() {
        const selectedStudents = getSelectedStudents();
        if (selectedStudents.length === 0) {
          showNotification(
            'Please select students for ID card generation.',
            'warning',
          );
          return;
        }

        showNotification(
          `Generating ID cards for ${selectedStudents.length} students...`,
          'info',
        );

        generateRealIdCards(selectedStudents);
      }

      function previewIdCards() {
        const selectedStudents = getSelectedStudents();
        if (selectedStudents.length === 0) {
          showNotification('Please select students for preview.', 'warning');
          return;
        }

        showIdCardPreview(selectedStudents[0]);
      }

      function generateSingleIdCard(studentId) {
        const student = studentsData.find((s) => s.id === studentId);
        if (!student) return;

        showNotification(
          `Generating ID card for ${student.firstName} ${student.lastName}...`,
          'info',
        );

        generateRealIdCards([studentId]);
      }

      function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg transition-all duration-300 transform translate-x-full`;

        const colors = {
          success: 'bg-green-500 text-white',
          error: 'bg-red-500 text-white',
          warning: 'bg-yellow-500 text-white',
          info: 'bg-blue-500 text-white',
        };

        notification.className += ` ${colors[type]}`;
        notification.innerHTML = `
                <div class="flex items-center">
                    <i class="fas fa-${
                      type === 'success'
                        ? 'check'
                        : type === 'error'
                        ? 'times'
                        : type === 'warning'
                        ? 'exclamation'
                        : 'info'
                    }-circle mr-2"></i>
                    <span>${message}</span>
                </div>
            `;

        document.body.appendChild(notification);

        // Animate in
        setTimeout(() => {
          notification.classList.remove('translate-x-full');
        }, 100);

        // Remove after 3 seconds
        setTimeout(() => {
          notification.classList.add('translate-x-full');
          setTimeout(() => {
            document.body.removeChild(notification);
          }, 300);
        }, 3000);
      }

      // Close modals when clicking outside
      document.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
          const modalId = e.target.id;
          closeModal(modalId);
        }
      });
    </script>
  </body>
</html>