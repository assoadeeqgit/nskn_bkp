<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Management - Northland Schools Kano</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        nskblue: '#1e40af',
                        nsklightblue: '#3b82f6',
                        nsknavy: '#1e3a8a',
                        nskgold: '#f59e0b',
                        nsklight: '#f0f9ff',
                        nskgreen: '#10b981',
                        nskred: '#ef4444'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap');
        
        body {
            font-family: 'Montserrat', sans-serif;
            background: #f8fafc;
        }
        
        .logo-container {
            background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%);
        }
        
        .teacher-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .teacher-card:hover {
            transform: translateY(-5px);
        }
        
        .nav-item {
            position: relative;
        }
        
        .nav-item::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: -5px;
            left: 0;
            background-color: #f59e0b;
            transition: width 0.3s ease;
        }
        
        .nav-item:hover::after {
            width: 100%;
        }
        
        .sidebar {
            transition: all 0.3s ease;
            width: 250px;
        }
        
        .sidebar.collapsed {
            width: 80px;
        }
        
        .main-content {
            transition: all 0.3s ease;
            margin-left: 250px;
            width: calc(100% - 250px);
        }
        
        .main-content.expanded {
            margin-left: 80px;
            width: calc(100% - 80px);
        }
        
        @media (max-width: 768px) {
            .sidebar {
                margin-left: -250px;
            }
            
            .sidebar.mobile-show {
                margin-left: 0;
            }
            
            .main-content {
                margin-left: 0;
                width: 100%;
            }
        }
        
        .notification-dot {
            position: absolute;
            top: -5px;
            right: -5px;
            width: 12px;
            height: 12px;
            background-color: #ef4444;
            border-radius: 50%;
        }
        
        .teacher-table {
            border-collapse: separate;
            border-spacing: 0;
        }
        
        .teacher-table th {
            background-color: #f8fafc;
        }
        
        .teacher-table tr:last-child td {
            border-bottom: 0;
        }
        
        .subject-badge {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-badge {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .modal {
            transition: opacity 0.3s ease, transform 0.3s ease;
            transform: scale(0.9);
            opacity: 0;
            pointer-events: none;
        }
        
        .modal.active {
            transform: scale(1);
            opacity: 1;
            pointer-events: all;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
            animation: fadeIn 0.5s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    </style>
    
    <!-- Include sidebar CSS -->
    <link rel="stylesheet" href="sidebar.css">
</head>
<body class="flex">
    <!-- Sidebar Include -->
    <div id="sidebar-container"></div>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <header class="bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="md:hidden text-nsknavy sidebar-toggle">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold text-nsknavy">Teacher Management</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <div class="flex items-center space-x-2 bg-nsklight rounded-full py-2 px-4">
                            <i class="fas fa-search text-gray-500"></i>
                            <input type="text" placeholder="Search teachers..." class="bg-transparent outline-none w-32 md:w-64" id="searchInput">
                        </div>
                    </div>
                    
                    <div class="relative">
                        <i class="fas fa-bell text-nsknavy text-xl"></i>
                        <div class="notification-dot"></div>
                    </div>
                    
                    <div class="hidden md:flex items-center space-x-2">
                        <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center text-white font-bold">
                            A
                        </div>
                        <div>
                            <p class="text-sm font-semibold text-nsknavy">Admin User</p>
                            <p class="text-xs text-gray-600">Administrator</p>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Teacher Management Content -->
        <div class="p-6">
            <!-- Stats Overview -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="teacher-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nsklightblue p-4 rounded-full mr-4">
                        <i class="fas fa-chalkboard-teacher text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Total Teachers</p>
                        <p class="text-2xl font-bold text-nsknavy">68</p>
                        <p class="text-xs text-nskgreen"><i class="fas fa-arrow-up"></i> 3 new this month</p>
                    </div>
                </div>
                
                <div class="teacher-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nskgreen p-4 rounded-full mr-4">
                        <i class="fas fa-book text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Subjects Covered</p>
                        <p class="text-2xl font-bold text-nsknavy">24</p>
                        <p class="text-xs text-gray-600">Across all grades</p>
                    </div>
                </div>
                
                <div class="teacher-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nskgold p-4 rounded-full mr-4">
                        <i class="fas fa-award text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Senior Staff</p>
                        <p class="text-2xl font-bold text-nsknavy">15</p>
                        <p class="text-xs text-nskgreen">5+ years experience</p>
                    </div>
                </div>
                
                <div class="teacher-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nskred p-4 rounded-full mr-4">
                        <i class="fas fa-briefcase text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Vacancies</p>
                        <p class="text-2xl font-bold text-nsknavy">5</p>
                        <p class="text-xs text-nskred">Urgent hiring needed</p>
                    </div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="bg-white rounded-xl shadow-md p-6 mb-8">
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <h2 class="text-xl font-bold text-nsknavy">All Teachers</h2>
                    
                    <div class="flex flex-wrap gap-4">
                        <select class="px-4 py-2 border rounded-lg form-input focus:border-nskblue" id="departmentFilter">
                            <option value="">All Departments</option>
                            <option value="science">Science</option>
                            <option value="arts">Arts</option>
                            <option value="commerce">Commerce</option>
                            <option value="language">Languages</option>
                        </select>
                        
                        <select class="px-4 py-2 border rounded-lg form-input focus:border-nskblue" id="statusFilter">
                            <option value="">All Status</option>
                            <option value="active">Active</option>
                            <option value="on-leave">On Leave</option>
                            <option value="probation">Probation</option>
                        </select>
                        
                        <button class="bg-nskblue text-white px-4 py-2 rounded-lg font-semibold hover:bg-nsknavy transition flex items-center" id="filterBtn">
                            <i class="fas fa-filter mr-2"></i> Filter
                        </button>
                        
                        <button id="addTeacherBtn" class="bg-nskgreen text-white px-4 py-2 rounded-lg font-semibold hover:bg-green-600 transition flex items-center">
                            <i class="fas fa-plus mr-2"></i> Add Teacher
                        </button>
                        
                        <button class="bg-nskgold text-white px-4 py-2 rounded-lg font-semibold hover:bg-amber-600 transition flex items-center" id="exportBtn">
                            <i class="fas fa-file-export mr-2"></i> Export
                        </button>
                    </div>
                </div>
            </div>

            <!-- Teachers Table -->
            <div class="bg-white rounded-xl shadow-md overflow-hidden mb-8">
                <div class="overflow-x-auto">
                    <table class="min-w-full teacher-table">
                        <thead>
                            <tr>
                                <th class="py-3 px-6 text-left text-nsknavy">Teacher</th>
                                <th class="py-3 px-6 text-left text-nsknavy">Department & Subjects</th>
                                <th class="py-3 px-6 text-left text-nsknavy">Classes Assigned</th>
                                <th class="py-3 px-6 text-left text-nsknavy">Status</th>
                                <th class="py-3 px-6 text-left text-nsknavy">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200" id="teachersTableBody">
                            <tr>
                                <td class="py-4 px-6">
                                    <div class="flex items-center">
                                        <div class="w-10 h-10 rounded-full bg-nskblue flex items-center justify-center text-white font-bold mr-3">
                                            JA
                                        </div>
                                        <div>
                                            <p class="font-semibold">Mr. Johnson Adeyemi</p>
                                            <p class="text-sm text-gray-600">M.Sc. Mathematics</p>
                                            <p class="text-xs text-gray-500">ID: TEA-2020-015</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="subject-badge bg-blue-100 text-nskblue">Mathematics</span>
                                    <span class="subject-badge bg-blue-100 text-nskblue">Further Maths</span>
                                    <p class="text-sm text-gray-600 mt-1">Head of Science Dept.</p>
                                </td>
                                <td class="py-4 px-6">
                                    <p class="text-sm">Grade 10-A, 10-B, 11-A</p>
                                    <p class="text-xs text-gray-600">15 periods/week</p>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="status-badge bg-green-100 text-nskgreen">Active</span>
                                    <p class="text-xs text-gray-600 mt-1">5 years experience</p>
                                </td>
                                <td class="py-4 px-6">
                                    <div class="flex space-x-2">
                                        <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 view-btn">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 edit-btn">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="text-nskred hover:text-red-700 p-2 rounded-full hover:bg-red-50 delete-btn">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td class="py-4 px-6">
                                    <div class="flex items-center">
                                        <div class="w-10 h-10 rounded-full bg-nskgreen flex items-center justify-center text-white font-bold mr-3">
                                            AM
                                        </div>
                                        <div>
                                            <p class="font-semibold">Dr. Amina Mohammed</p>
                                            <p class="text-sm text-gray-600">Ph.D. Physics</p>
                                            <p class="text-xs text-gray-500">ID: TEA-2018-007</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="subject-badge bg-green-100 text-nskgreen">Physics</span>
                                    <span class="subject-badge bg-green-100 text-nskgreen">Chemistry</span>
                                    <p class="text-sm text-gray-600 mt-1">Science Department</p>
                                </td>
                                <td class="py-4 px-6">
                                    <p class="text-sm">Grade 11-B, 12-A, 12-C</p>
                                    <p class="text-xs text-gray-600">18 periods/week</p>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="status-badge bg-green-100 text-nskgreen">Active</span>
                                    <p class="text-xs text-gray-600 mt-1">7 years experience</p>
                                </td>
                                <td class="py-4 px-6">
                                    <div class="flex space-x-2">
                                        <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 view-btn">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 edit-btn">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="text-nskred hover:text-red-700 p-2 rounded-full hover:bg-red-50 delete-btn">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td class="py-4 px-6">
                                    <div class="flex items-center">
                                        <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center text-white font-bold mr-3">
                                            YS
                                        </div>
                                        <div>
                                            <p class="font-semibold">Mr. Yusuf Sani</p>
                                            <p class="text-sm text-gray-600">M.A. English Literature</p>
                                            <p class="text-xs text-gray-500">ID: TEA-2021-032</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="subject-badge bg-amber-100 text-amber-700">English</span>
                                    <span class="subject-badge bg-amber-100 text-amber-700">Literature</span>
                                    <p class="text-sm text-gray-600 mt-1">Languages Department</p>
                                </td>
                                <td class="py-4 px-6">
                                    <p class="text-sm">Grade 9-A, 9-B, 10-C</p>
                                    <p class="text-xs text-gray-600">16 periods/week</p>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="status-badge bg-green-100 text-nskgreen">Active</span>
                                    <p class="text-xs text-gray-600 mt-1">2 years experience</p>
                                </td>
                                <td class="py-4 px-6">
                                    <div class="flex space-x-2">
                                        <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 view-btn">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 edit-btn">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="text-nskred hover:text-red-700 p-2 rounded-full hover:bg-red-50 delete-btn">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td class="py-4 px-6">
                                    <div class="flex items-center">
                                        <div class="w-10 h-10 rounded-full bg-nskred flex items-center justify-center text-white font-bold mr-3">
                                            FA
                                        </div>
                                        <div>
                                            <p class="font-semibold">Mrs. Fatima Ahmed</p>
                                            <p class="text-sm text-gray-600">B.Sc. Biology</p>
                                            <p class="text-xs text-gray-500">ID: TEA-2022-045</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="subject-badge bg-red-100 text-nskred">Biology</span>
                                    <span class="subject-badge bg-red-100 text-nskred">Health Science</span>
                                    <p class="text-sm text-gray-600 mt-1">Science Department</p>
                                </td>
                                <td class="py-4 px-6">
                                    <p class="text-sm">Grade 8-A, 8-B, 9-C</p>
                                    <p class="text-xs text-gray-600">14 periods/week</p>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="status-badge bg-yellow-100 text-yellow-700">Probation</span>
                                    <p class="text-xs text-gray-600 mt-1">1 year experience</p>
                                </td>
                                <td class="py-4 px-6">
                                    <div class="flex space-x-2">
                                        <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 view-btn">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 edit-btn">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="text-nskred hover:text-red-700 p-2 rounded-full hover:bg-red-50 delete-btn">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td class="py-4 px-6">
                                    <div class="flex items-center">
                                        <div class="w-10 h-10 rounded-full bg-purple-500 flex items-center justify-center text-white font-bold mr-3">
                                            KO
                                        </div>
                                        <div>
                                            <p class="font-semibold">Mr. Kabir Okafor</p>
                                            <p class="text-sm text-gray-600">M.Ed. Educational Management</p>
                                            <p class="text-xs text-gray-500">ID: TEA-2015-003</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="subject-badge bg-purple-100 text-purple-700">History</span>
                                    <span class="subject-badge bg-purple-100 text-purple-700">Civics</span>
                                    <p class="text-sm text-gray-600 mt-1">Head of Arts Dept.</p>
                                </td>
                                <td class="py-4 px-6">
                                    <p class="text-sm">Grade 10-C, 11-A, 12-B</p>
                                    <p class="text-xs text-gray-600">12 periods/week</p>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="status-badge bg-blue-100 text-nskblue">On Leave</span>
                                    <p class="text-xs text-gray-600 mt-1">Returns: 15/12/2023</p>
                                </td>
                                <td class="py-4 px-6">
                                    <div class="flex space-x-2">
                                        <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 view-btn">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 edit-btn">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="text-nskred hover:text-red-700 p-2 rounded-full hover:bg-red-50 delete-btn">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <div class="flex items-center justify-between border-t border-gray-200 px-6 py-4">
                    <div>
                        <p class="text-sm text-gray-700">
                            Showing <span class="font-medium">1</span> to <span class="font-medium">5</span> of <span class="font-medium">68</span> teachers
                        </p>
                    </div>
                    <div class="flex space-x-2">
                        <button class="px-3 py-1 rounded border text-sm font-medium text-gray-700 hover:bg-gray-50" id="prevPageBtn">
                            Previous
                        </button>
                        <button class="px-3 py-1 rounded border border-nskblue bg-nskblue text-white text-sm font-medium page-btn active" data-page="1">
                            1
                        </button>
                        <button class="px-3 py-1 rounded border text-sm font-medium text-gray-700 hover:bg-gray-50 page-btn" data-page="2">
                            2
                        </button>
                        <button class="px-3 py-1 rounded border text-sm font-medium text-gray-700 hover:bg-gray-50 page-btn" data-page="3">
                            3
                        </button>
                        <button class="px-3 py-1 rounded border text-sm font-medium text-gray-700 hover:bg-gray-50" id="nextPageBtn">
                            Next
                        </button>
                    </div>
                </div>
            </div>

            <!-- Department Overview -->
            <div class="bg-white rounded-xl shadow-md p-6">
                <h2 class="text-xl font-bold text-nsknavy mb-6">Department Overview</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div class="bg-blue-50 rounded-lg p-4 border border-blue-100">
                        <div class="flex justify-between items-center mb-2">
                            <h3 class="font-semibold text-nskblue">Science Department</h3>
                            <span class="text-nskblue font-bold">18</span>
                        </div>
                        <p class="text-sm text-gray-600 mb-3">Mathematics, Physics, Chemistry, Biology</p>
                        <div class="w-full bg-blue-200 rounded-full h-2">
                            <div class="bg-nskblue h-2 rounded-full" style="width: 75%"></div>
                        </div>
                        <p class="text-xs text-gray-600 mt-1">75% staffing level</p>
                    </div>
                    
                    <div class="bg-green-50 rounded-lg p-4 border border-green-100">
                        <div class="flex justify-between items-center mb-2">
                            <h3 class="font-semibold text-nskgreen">Arts Department</h3>
                            <span class="text-nskgreen font-bold">12</span>
                        </div>
                        <p class="text-sm text-gray-600 mb-3">History, Geography, Civics, Economics</p>
                        <div class="w-full bg-green-200 rounded-full h-2">
                            <div class="bg-nskgreen h-2 rounded-full" style="width: 60%"></div>
                        </div>
                        <p class="text-xs text-gray-600 mt-1">60% staffing level</p>
                    </div>
                    
                    <div class="bg-amber-50 rounded-lg p-4 border border-amber-100">
                        <div class="flex justify-between items-center mb-2">
                            <h3 class="font-semibold text-amber-700">Languages Department</h3>
                            <span class="text-amber-700 font-bold">15</span>
                        </div>
                        <p class="text-sm text-gray-600 mb-3">English, Arabic, French, Literature</p>
                        <div class="w-full bg-amber-200 rounded-full h-2">
                            <div class="bg-amber-500 h-2 rounded-full" style="width: 85%"></div>
                        </div>
                        <p class="text-xs text-gray-600 mt-1">85% staffing level</p>
                    </div>
                    
                    <div class="bg-purple-50 rounded-lg p-4 border border-purple-100">
                        <div class="flex justify-between items-center mb-2">
                            <h3 class="font-semibold text-purple-700">Commerce Department</h3>
                            <span class="text-purple-700 font-bold">8</span>
                        </div>
                        <p class="text-sm text-gray-600 mb-3">Accounting, Business Studies, Commerce</p>
                        <div class="w-full bg-purple-200 rounded-full h-2">
                            <div class="bg-purple-500 h-2 rounded-full" style="width: 45%"></div>
                        </div>
                        <p class="text-xs text-gray-600 mt-1">45% staffing level</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add Teacher Modal -->
        <div id="addTeacherModal" class="modal fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div class="bg-white rounded-xl shadow-2xl max-w-2xl w-full p-6 max-h-screen overflow-y-auto">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-bold text-nsknavy">Add New Teacher</h3>
                    <button id="closeModal" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <form id="teacherForm" class="space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 mb-2" for="firstName">First Name</label>
                            <input type="text" id="firstName" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 mb-2" for="lastName">Last Name</label>
                            <input type="text" id="lastName" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 mb-2" for="email">Email Address</label>
                            <input type="email" id="email" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 mb-2" for="phone">Phone Number</label>
                            <input type="tel" id="phone" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 mb-2" for="qualification">Highest Qualification</label>
                            <select id="qualification" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                                <option value="">Select Qualification</option>
                                <option value="phd">Ph.D.</option>
                                <option value="masters">Master's Degree</option>
                                <option value="bachelors">Bachelor's Degree</option>
                                <option value="diploma">Diploma</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 mb-2" for="department">Department</label>
                            <select id="department" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                                <option value="">Select Department</option>
                                <option value="science">Science</option>
                                <option value="arts">Arts</option>
                                <option value="language">Languages</option>
                                <option value="commerce">Commerce</option>
                            </select>
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 mb-2">Subjects</label>
                        <div class="grid grid-cols-2 md:grid-cols-3 gap-2">
                            <div class="flex items-center">
                                <input type="checkbox" id="math" class="mr-2 subject-checkbox" value="Mathematics">
                                <label for="math" class="text-sm">Mathematics</label>
                            </div>
                            <div class="flex items-center">
                                <input type="checkbox" id="physics" class="mr-2 subject-checkbox" value="Physics">
                                <label for="physics" class="text-sm">Physics</label>
                            </div>
                            <div class="flex items-center">
                                <input type="checkbox" id="chemistry" class="mr-2 subject-checkbox" value="Chemistry">
                                <label for="chemistry" class="text-sm">Chemistry</label>
                            </div>
                            <div class="flex items-center">
                                <input type="checkbox" id="biology" class="mr-2 subject-checkbox" value="Biology">
                                <label for="biology" class="text-sm">Biology</label>
                            </div>
                            <div class="flex items-center">
                                <input type="checkbox" id="english" class="mr-2 subject-checkbox" value="English">
                                <label for="english" class="text-sm">English</label>
                            </div>
                            <div class="flex items-center">
                                <input type="checkbox" id="history" class="mr-2 subject-checkbox" value="History">
                                <label for="history" class="text-sm">History</label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 mb-2" for="status">Employment Status</label>
                            <select id="status" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                                <option value="active">Active</option>
                                <option value="probation">Probation</option>
                                <option value="on-leave">On Leave</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 mb-2" for="joinDate">Join Date</label>
                            <input type="date" id="joinDate" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-3 pt-4">
                        <button type="button" id="cancelBtn" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition">
                            Cancel
                        </button>
                        <button type="submit" class="px-4 py-2 bg-nskblue text-white rounded-lg font-semibold hover:bg-nsknavy transition">
                            Add Teacher
                        </button>
                    </div>
                </form>
            </div>
        </div>

         <!-- Include footer -->
<script src="footer.js"></script>

    </main>

    <!-- Include sidebar.js -->
    <script src="sidebar.js"></script>
    
    <script>
        // Teacher Manager Class
        class TeacherManager {
            constructor() {
                this.currentPage = 1;
                this.teachersPerPage = 5;
                this.filteredTeachers = [];
                this.init();
            }

            init() {
                this.setupEventListeners();
                this.loadInitialData();
            }

            setupEventListeners() {
                // Search functionality
                document.getElementById('searchInput').addEventListener('input', (e) => {
                    this.searchTeachers(e.target.value);
                });

                // Filter functionality
                document.getElementById('filterBtn').addEventListener('click', () => {
                    this.applyFilters();
                });

                // Export functionality
                document.getElementById('exportBtn').addEventListener('click', () => {
                    this.exportTeachers();
                });

                // Pagination
                document.getElementById('prevPageBtn').addEventListener('click', () => {
                    this.previousPage();
                });

                document.getElementById('nextPageBtn').addEventListener('click', () => {
                    this.nextPage();
                });

                document.querySelectorAll('.page-btn').forEach(btn => {
                    btn.addEventListener('click', (e) => {
                        this.goToPage(parseInt(e.target.dataset.page));
                    });
                });

                // Table action buttons
                document.addEventListener('click', (e) => {
                    if (e.target.closest('.view-btn')) {
                        this.viewTeacher(e.target.closest('tr'));
                    } else if (e.target.closest('.edit-btn')) {
                        this.editTeacher(e.target.closest('tr'));
                    } else if (e.target.closest('.delete-btn')) {
                        this.deleteTeacher(e.target.closest('tr'));
                    }
                });
            }

            searchTeachers(query) {
                const rows = document.querySelectorAll('#teachersTableBody tr');
                
                rows.forEach(row => {
                    const teacherName = row.querySelector('.font-semibold').textContent.toLowerCase();
                    const teacherId = row.querySelector('.text-xs.text-gray-500').textContent.toLowerCase();
                    const department = row.querySelectorAll('td')[1].textContent.toLowerCase();
                    
                    if (teacherName.includes(query.toLowerCase()) || 
                        teacherId.includes(query.toLowerCase()) ||
                        department.includes(query.toLowerCase())) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                });
            }

            applyFilters() {
                const department = document.getElementById('departmentFilter').value;
                const status = document.getElementById('statusFilter').value;
                const rows = document.querySelectorAll('#teachersTableBody tr');
                
                rows.forEach(row => {
                    let showRow = true;
                    
                    // Department filter
                    if (department) {
                        const deptText = row.querySelectorAll('td')[1].textContent.toLowerCase();
                        if (!deptText.includes(department.toLowerCase())) {
                            showRow = false;
                        }
                    }
                    
                    // Status filter
                    if (status) {
                        const statusText = row.querySelector('.status-badge').textContent.toLowerCase();
                        if (statusText !== status.toLowerCase()) {
                            showRow = false;
                        }
                    }
                    
                    row.style.display = showRow ? '' : 'none';
                });
                
                alert(`Applied filters: ${department || 'All Departments'}, ${status || 'All Status'}`);
            }

            exportTeachers() {
                alert('Exporting teacher data...');
                // In a real application, this would generate and download a file
            }

            previousPage() {
                if (this.currentPage > 1) {
                    this.goToPage(this.currentPage - 1);
                }
            }

            nextPage() {
                this.goToPage(this.currentPage + 1);
            }

            goToPage(page) {
                this.currentPage = page;
                
                // Update pagination UI
                document.querySelectorAll('.page-btn').forEach(btn => {
                    btn.classList.remove('active', 'border-nskblue', 'bg-nskblue', 'text-white');
                    btn.classList.add('border', 'text-gray-700', 'hover:bg-gray-50');
                    
                    if (parseInt(btn.dataset.page) === page) {
                        btn.classList.add('active', 'border-nskblue', 'bg-nskblue', 'text-white');
                        btn.classList.remove('border', 'text-gray-700', 'hover:bg-gray-50');
                    }
                });
                
                alert(`Navigated to page ${page}`);
                // In a real application, this would load the appropriate data for the page
            }

            viewTeacher(row) {
                const teacherName = row.querySelector('.font-semibold').textContent;
                const teacherId = row.querySelector('.text-xs.text-gray-500').textContent;
                alert(`Viewing details for: ${teacherName}\nID: ${teacherId}`);
            }

            editTeacher(row) {
                const teacherName = row.querySelector('.font-semibold').textContent;
                alert(`Editing teacher: ${teacherName}`);
                // In a real application, this would open an edit modal with pre-filled data
            }

            deleteTeacher(row) {
                const teacherName = row.querySelector('.font-semibold').textContent;
                
                if (confirm(`Are you sure you want to delete ${teacherName}? This action cannot be undone.`)) {
                    row.style.opacity = '0';
                    row.style.transition = 'opacity 0.5s ease';
                    
                    setTimeout(() => {
                        row.remove();
                        alert(`${teacherName} has been deleted successfully`);
                    }, 500);
                }
            }

            loadInitialData() {
                console.log('Teacher Manager initialized');
            }
        }

        // Initialize teacher manager
        const teacherManager = new TeacherManager();

        // Modal functionality
        const modal = document.getElementById('addTeacherModal');
        const addTeacherBtn = document.getElementById('addTeacherBtn');
        const closeModal = document.getElementById('closeModal');
        const cancelBtn = document.getElementById('cancelBtn');
        const teacherForm = document.getElementById('teacherForm');

        addTeacherBtn.addEventListener('click', function() {
            modal.classList.add('active');
        });

        function closeModalFunc() {
            modal.classList.remove('active');
            teacherForm.reset();
        }

        closeModal.addEventListener('click', closeModalFunc);
        cancelBtn.addEventListener('click', closeModalFunc);

        // Close modal when clicking outside
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModalFunc();
            }
        });

        // Form submission
        teacherForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const firstName = document.getElementById('firstName').value;
            const lastName = document.getElementById('lastName').value;
            const department = document.getElementById('department').value;
            const qualification = document.getElementById('qualification').value;
            
            // Get selected subjects
            const selectedSubjects = Array.from(document.querySelectorAll('.subject-checkbox:checked'))
                .map(checkbox => checkbox.value);
            
            // Simulate adding a teacher
            alert(`Teacher ${firstName} ${lastName} added to ${department} department\nQualification: ${qualification}\nSubjects: ${selectedSubjects.join(', ')}`);
            closeModalFunc();
        });

 </script>
</body>
</html>