<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Academics Management - Northland Schools Kano</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="sidebar.css">
    <script>
      tailwind.config = {
        theme: {
          extend: {
            colors: {
              nskblue: "#1e40af",
              nsklightblue: "#3b82f6",
              nsknavy: "#1e3a8a",
              nskgold: "#f59e0b",
              nsklight: "#f0f9ff",
              nskgreen: "#10b981",
              nskred: "#ef4444",
            },
          },
        },
      };
    </script>
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap");

      body {
        font-family: "Montserrat", sans-serif;
        background: #f8fafc;
      }

      .logo-container {
        background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%);
      }

      .academics-card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
      }

      .academics-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
      }

      .nav-item {
        position: relative;
      }

      .nav-item::after {
        content: "";
        position: absolute;
        width: 0;
        height: 2px;
        bottom: -5px;
        left: 0;
        background-color: #f59e0b;
        transition: width 0.3s ease;
      }

      .nav-item:hover::after {
        width: 100%;
      }

      .sidebar {
        transition: all 0.3s ease;
        width: 250px;
      }

      .sidebar.collapsed {
        width: 80px;
      }

      .main-content {
        transition: all 0.3s ease;
        margin-left: 250px;
        width: calc(100% - 250px);
      }

      .main-content.expanded {
        margin-left: 80px;
        width: calc(100% - 80px);
      }

      @media (max-width: 768px) {
        .sidebar {
          margin-left: -250px;
          z-index: 40;
        }

        .sidebar.mobile-show {
          margin-left: 0;
          box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
        }

        .main-content {
          margin-left: 0;
          width: 100%;
        }

        .action-buttons-mobile {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .stats-grid {
          grid-template-columns: 1fr;
          gap: 1rem;
        }

        .tab-button {
          flex: 1;
          min-width: 120px;
          text-align: center;
          font-size: 0.875rem;
          padding: 0.5rem 0.75rem;
        }
      }

      /* Add this to your CSS */
      .grade-badge-container {
        display: inline-block;
        min-width: 80px;
        text-align: center;
      }

      .table-grade {
        white-space: nowrap;
        min-width: 85px;
      }

      @media (max-width: 768px) {
        .table-grade {
          min-width: 70px;
        }

        .grade-badge-container {
          min-width: 65px;
        }
      }

      .notification-dot {
        position: absolute;
        top: -5px;
        right: -5px;
        width: 12px;
        height: 12px;
        background-color: #ef4444;
        border-radius: 50%;
        animation: pulse 2s infinite;
      }

      .academics-table {
        border-collapse: separate;
        border-spacing: 0;
      }

      .academics-table th {
        background-color: #f8fafc;
      }

      .academics-table tr:last-child td {
        border-bottom: 0;
      }

      .academics-table tbody tr {
        transition: all 0.3s ease;
      }

      .academics-table tbody tr:hover {
        background-color: #f0f9ff;
        transform: scale(1.01);
      }

      .status-badge {
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        transition: all 0.3s ease;
      }

      .status-badge:hover {
        transform: scale(1.1);
      }

      .grade-badge {
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        transition: all 0.3s ease;
      }

      .grade-badge:hover {
        transform: scale(1.1);
      }

      .modal {
        transition: opacity 0.3s ease, transform 0.3s ease;
        transform: scale(0.9);
        opacity: 0;
        display: none;
      }

      .modal.active {
        transform: scale(1);
        opacity: 1;
      }

      .tab-button {
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
      }

      .tab-button::before {
        content: "";
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(
          90deg,
          transparent,
          rgba(255, 255, 255, 0.2),
          transparent
        );
        transition: left 0.5s;
      }

      .tab-button:hover::before {
        left: 100%;
      }

      .tab-button.active {
        background-color: #1e40af;
        color: white;
        box-shadow: 0 4px 15px rgba(30, 64, 175, 0.3);
      }

      .progress-bar {
        height: 8px;
        background-color: #e5e7eb;
        border-radius: 4px;
        overflow: hidden;
        position: relative;
      }

      .progress-fill {
        height: 100%;
        border-radius: 4px;
        transition: width 1s ease-in-out;
        position: relative;
        overflow: hidden;
      }

      .progress-fill::after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        background-image: linear-gradient(
          -45deg,
          rgba(255, 255, 255, 0.2) 25%,
          transparent 25%,
          transparent 50%,
          rgba(255, 255, 255, 0.2) 50%,
          rgba(255, 255, 255, 0.2) 75%,
          transparent 75%,
          transparent
        );
        background-size: 50px 50px;
        animation: move 2s linear infinite;
      }
/* 
      .assignment-card {
        transition: all 0.3s ease;
        border-left: 4px solid transparent;
      }

      .assignment-card:hover {
        border-left-color: #1e40af;
        transform: translateX(5px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
      }

      .grade-input {
        transition: all 0.3s ease;
      }

      .grade-input:focus {
        transform: scale(1.05);
        box-shadow: 0 0 0 3px rgba(30, 64, 175, 0.1);
      }

      .exam-schedule-item {
        transition: all 0.3s ease;
        border-radius: 10px;
      }

      .exam-schedule-item:hover {
        background-color: #f0f9ff;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
      }

      .curriculum-module {
        transition: all 0.3s ease;
        cursor: pointer;
      }

      .curriculum-module:hover {
        background-color: #f8fafc;
        border-color: #1e40af;
      }

      .curriculum-module.completed {
        background-color: #f0fdf4;
        border-color: #10b981;
      }

      .lms-feature {
        transition: all 0.3s ease;
        border: 2px solid transparent;
      }

      .lms-feature:hover {
        border-color: #1e40af;
        transform: scale(1.02);
      }

      .online-class-card {
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
      }

      .online-class-card::before {
        content: "";
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(
          90deg,
          transparent,
          rgba(30, 64, 175, 0.1),
          transparent
        );
        transition: left 0.5s;
      }

      .online-class-card:hover::before {
        left: 100%;
      }

      .online-class-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
      } */

      .floating-action-btn {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: linear-gradient(135deg, #1e40af, #1e3a8a);
        color: white;
        border: none;
        box-shadow: 0 4px 15px rgba(30, 64, 175, 0.3);
        cursor: pointer;
        transition: all 0.3s ease;
        z-index: 1000;
      }

      .floating-action-btn:hover {
        transform: scale(1.1) rotate(90deg);
        box-shadow: 0 6px 20px rgba(30, 64, 175, 0.4);
      }

      @keyframes fadeIn {
        from {
          opacity: 0;
          transform: translateY(20px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      @keyframes slideIn {
        from {
          transform: translateX(-100%);
        }
        to {
          transform: translateX(0);
        }
      }

      @keyframes pulse {
        0%,
        100% {
          opacity: 1;
        }
        50% {
          opacity: 0.5;
        }
      }

      @keyframes move {
        0% {
          background-position: 0 0;
        }
        100% {
          background-position: 50px 50px;
        }
      }

      @keyframes bounce {
        0%,
        20%,
        50%,
        80%,
        100% {
          transform: translateY(0);
        }
        40% {
          transform: translateY(-10px);
        }
        60% {
          transform: translateY(-5px);
        }
      }

      .animate-fadeIn {
        animation: fadeIn 0.5s ease-out;
      }

      .animate-slideIn {
        animation: slideIn 0.5s ease-out;
      }

      .animate-bounce {
        animation: bounce 2s infinite;
      }

      .loading-spinner {
        border: 3px solid #f3f3f3;
        border-top: 3px solid #1e40af;
        border-radius: 50%;
        width: 20px;
        height: 20px;
        animation: spin 1s linear infinite;
      }

      @keyframes spin {
        0% {
          transform: rotate(0deg);
        }
        100% {
          transform: rotate(360deg);
        }
      }

      .notification-toast {
        position: fixed;
        top: 20px;
        right: 20px;
        background: white;
        border-left: 4px solid #10b981;
        border-radius: 8px;
        padding: 16px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        transform: translateX(100%);
        transition: transform 0.3s ease;
        z-index: 1000;
      }

      .notification-toast.show {
        transform: translateX(0);
      }

      .drag-drop-zone {
        border: 2px dashed #d1d5db;
        border-radius: 8px;
        padding: 40px;
        text-align: center;
        transition: all 0.3s ease;
        cursor: pointer;
      }

      .drag-drop-zone:hover,
      .drag-drop-zone.dragover {
        border-color: #1e40af;
        background-color: #f0f9ff;
      }
    </style>
  </head>
  <body class="flex">
    <!-- Sidebar Navigation -->
<script src="sidebar.js"></script>
    <!-- Main Content -->
    <main class="main-content">
      <!-- Header -->
      <header class="bg-white shadow-md p-4">
        <div class="flex items-center justify-between">
          <div class="flex items-center">
            <button class="sidebar-toggle md:hidden mr-4 text-nsknavy">
              <i class="fas fa-bars text-xl"></i>
            </button>
            <div>
              <h1 class="text-2xl font-bold text-nsknavy">
                Academic Management
              </h1>
              <p class="text-gray-600">
                Manage courses, assignments, grades, and academic activities
              </p>
            </div>
          </div>

          <div class="flex items-center space-x-4">
            <div class="relative hidden md:block">
              <input
                type="text"
                placeholder="Search academics..."
                class="pl-10 pr-4 py-2 border rounded-lg focus:border-nskblue transition"
              />
              <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
            </div>

            <div class="relative">
              <button
                class="relative p-2 text-gray-600 hover:text-nskblue transition"
              >
                <i class="fas fa-bell text-xl"></i>
                <div class="notification-dot"></div>
              </button>
            </div>

            <div class="flex items-center">
              <div
                class="w-10 h-10 rounded-full bg-nskblue flex items-center justify-center text-white mr-3"
              >
                <span class="font-bold">AD</span>
              </div>
              <div class="hidden md:block">
                <p class="font-semibold text-nsknavy">Admin User</p>
                <p class="text-sm text-gray-600">Academic Coordinator</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <!-- Academics Management Content -->
      <div class="p-4 md:p-6">
        <!-- Stats Overview -->
        <div
          class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-6 md:mb-8 stats-grid"
        >
          <div
            class="academics-card bg-white rounded-xl shadow-md p-5 flex items-center animate-fadeIn"
          >
            <div class="bg-nskgreen p-4 rounded-full mr-4">
              <i class="fas fa-book text-white text-xl"></i>
            </div>
            <div>
              <p class="text-gray-600">Total Subjects</p>
              <p class="text-2xl font-bold text-nsknavy" id="totalSubjects">
                24
              </p>
              <p class="text-xs text-nskgreen">Across all grades</p>
            </div>
          </div>

          <div
            class="academics-card bg-white rounded-xl shadow-md p-5 flex items-center animate-fadeIn"
            style="animation-delay: 0.1s"
          >
            <div class="bg-nskblue p-4 rounded-full mr-4">
              <i class="fas fa-tasks text-white text-xl"></i>
            </div>
            <div>
              <p class="text-gray-600">Active Assignments</p>
              <p class="text-2xl font-bold text-nsknavy" id="activeAssignments">
                156
              </p>
              <p class="text-xs text-nskblue">12 due this week</p>
            </div>
          </div>

          <div
            class="academics-card bg-white rounded-xl shadow-md p-5 flex items-center animate-fadeIn"
            style="animation-delay: 0.2s"
          >
            <div class="bg-nskgold p-4 rounded-full mr-4">
              <i class="fas fa-chart-line text-white text-xl"></i>
            </div>
            <div>
              <p class="text-gray-600">Average Performance</p>
              <p class="text-2xl font-bold text-nsknavy" id="avgPerformance">
                82%
              </p>
              <p class="text-xs text-nskgold">+3% from last term</p>
            </div>
          </div>

          <div
            class="academics-card bg-white rounded-xl shadow-md p-5 flex items-center animate-fadeIn"
            style="animation-delay: 0.3s"
          >
            <div class="bg-nskred p-4 rounded-full mr-4">
              <i class="fas fa-graduation-cap text-white text-xl"></i>
            </div>
            <div>
              <p class="text-gray-600">Online Classes</p>
              <p class="text-2xl font-bold text-nsknavy" id="onlineClasses">
                8
              </p>
              <p class="text-xs text-nskred">Live sessions today</p>
            </div>
          </div>
        </div>

        <!-- Action Bar -->
        <div
          class="bg-white rounded-xl shadow-md p-4 md:p-6 mb-6 md:mb-8 animate-slideIn"
        >
          <div
            class="flex flex-col md:flex-row md:items-center justify-between gap-4"
          >
            <h2 class="text-xl font-bold text-nsknavy mb-4 md:mb-0">
              Academic Management Hub
            </h2>

            <div class="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
              <div class="flex flex-col sm:flex-row gap-2 mb-3 sm:mb-0">
                <select
                  class="px-3 py-2 border rounded-lg form-input focus:border-nskblue text-sm"
                  id="gradeFilter"
                >
                  <option value="">All Grades</option>
                  <option value="7">Grade 7</option>
                  <option value="8">Grade 8</option>
                  <option value="9">Grade 9</option>
                  <option value="10">Grade 10</option>
                  <option value="11">Grade 11</option>
                  <option value="12">Grade 12</option>
                </select>

                <select
                  class="px-3 py-2 border rounded-lg form-input focus:border-nskblue text-sm"
                  id="departmentFilter"
                >
                  <option value="">All Departments</option>
                  <option value="science">Science</option>
                  <option value="arts">Arts</option>
                  <option value="commerce">Commerce</option>
                </select>
              </div>

              <div class="flex flex-wrap gap-2 action-buttons-mobile">
                <button
                  class="flex-1 sm:flex-none bg-nskblue text-white px-3 py-2 rounded-lg font-semibold hover:bg-nsknavy transition flex items-center justify-center text-sm"
                  id="filterBtn"
                >
                  <i class="fas fa-filter mr-2"></i> Filter
                </button>

                <!-- <button
                  id="addCourseBtn"
                  class="flex-1 sm:flex-none bg-nskgreen text-white px-3 py-2 rounded-lg font-semibold hover:bg-green-600 transition flex items-center justify-center text-sm"
                >
                  <i class="fas fa-plus mr-2"></i> Add Course
                </button> -->

                <button
                  id="bulkImportBtn"
                  class="flex-1 sm:flex-none bg-nskgold text-white px-3 py-2 rounded-lg font-semibold hover:bg-amber-600 transition flex items-center justify-center text-sm"
                >
                  <i class="fas fa-upload mr-2"></i> Bulk Import
                </button>
              </div>
            </div>
          </div>
        </div>

        <!-- Enhanced Academics Tabs -->
        <div class="bg-white rounded-xl shadow-md p-4 md:p-6 mb-6 md:mb-8">
          <div class="flex flex-wrap gap-2 mb-6 overflow-x-auto pb-2">
            <button
              class="tab-button px-3 py-2 rounded-lg border border-nskblue text-nskblue font-semibold active"
              data-tab="courses"
            >
              <i class="fas fa-book mr-2"></i>Subjects
            </button>
            <!-- <button
              class="tab-button px-3 py-2 rounded-lg border border-gray-300 text-gray-700 font-semibold"
              data-tab="assignments"
            >
              <i class="fas fa-tasks mr-2"></i>Assignments
            </button>
            <button
              class="tab-button px-3 py-2 rounded-lg border border-gray-300 text-gray-700 font-semibold"
              data-tab="gradebook"
            >
              <i class="fas fa-clipboard-list mr-2"></i>Gradebook
            </button>
            <button
              class="tab-button px-3 py-2 rounded-lg border border-gray-300 text-gray-700 font-semibold"
              data-tab="exams"
            >
              <i class="fas fa-file-alt mr-2"></i>Exams
            </button>
            <button
              class="tab-button px-3 py-2 rounded-lg border border-gray-300 text-gray-700 font-semibold"
              data-tab="curriculum"
            >
              <i class="fas fa-sitemap mr-2"></i>Curriculum
            </button>
            <button
              class="tab-button px-3 py-2 rounded-lg border border-gray-300 text-gray-700 font-semibold"
              data-tab="lms"
            >
              <i class="fas fa-laptop mr-2"></i>LMS
            </button>
            <button
              class="tab-button px-3 py-2 rounded-lg border border-gray-300 text-gray-700 font-semibold"
              data-tab="online"
            >
              <i class="fas fa-video mr-2"></i>Online
            </button> -->
          </div>

          <!-- Courses & Subjects Tab -->
          <div id="coursesTab" class="tab-content active">
            <div
              class="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-6"
            >
              <h3 class="text-lg font-bold text-nsknavy">
               Subjects Management
              </h3>
              <div class="flex gap-3">
                <button
                  id="addSubjectBtn"
                  class="bg-nskblue text-white px-4 py-2 rounded-lg font-semibold hover:bg-nsknavy transition flex items-center text-sm"
                >
                  <i class="fas fa-plus mr-2"></i> Add Subject
                </button>
                <button
                  id="manageCurriculumBtn"
                  class="bg-nskgreen text-white px-4 py-2 rounded-lg font-semibold hover:bg-green-600 transition flex items-center text-sm"
                >
                  <i class="fas fa-sitemap mr-2"></i> Manage Curriculum
                </button>
              </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
              <div class="lg:col-span-3">
                <div class="bg-white rounded-lg border overflow-hidden">
                  <div class="overflow-x-auto">
                    <table class="academics-table min-w-full">
                      <thead>
                        <tr class="bg-gray-50">
                          <th
                            class="px-4 md:px-6 py-4 text-left text-nsknavy font-semibold"
                          >
                            Subject
                          </th>
                          <th
                            class="px-4 md:px-6 py-4 text-left text-nsknavy font-semibold"
                          >
                            Grade
                          </th>
                          <th
                            class="px-4 md:px-6 py-4 text-left text-nsknavy font-semibold"
                          >
                            Teacher
                          </th>
                          <th
                            class="px-4 md:px-6 py-4 text-left text-nsknavy font-semibold"
                          >
                            Students
                          </th>
                          <th
                            class="px-4 md:px-6 py-4 text-left text-nsknavy font-semibold"
                          >
                            Status
                          </th>
                          <th
                            class="px-4 md:px-6 py-4 text-center text-nsknavy font-semibold"
                          >
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody class="divide-y divide-gray-200">
                        <tr>
                          <td class="px-4 md:px-6 py-4">
                            <div class="flex items-center">
                              <div
                                class="w-10 h-10 rounded-full bg-nskblue flex items-center justify-center text-white mr-3"
                              >
                                <i class="fas fa-calculator"></i>
                              </div>
                              <div>
                                <p class="font-semibold text-nsknavy">
                                  Mathematics
                                </p>
                                <p class="text-sm text-gray-600">
                                  Core Subject
                                </p>
                              </div>
                            </div>
                          </td>
                          <td class="px-4 md:px-6 py-4 table-grade">
                            <div class="grade-badge-container">
                              <span
                                class="bg-nskblue text-white px-3 py-1 rounded-full text-sm font-semibold"
                                >Grade 10</span
                              >
                            </div>
                          </td>
                          <td class="px-4 md:px-6 py-4">
                            <div>
                              <p class="font-medium">Mr. Johnson Adeyemi</p>
                              <p class="text-sm text-gray-600">
                                Mathematics Dept.
                              </p>
                            </div>
                          </td>
                          <td class="px-4 md:px-6 py-4">
                            <div class="flex items-center">
                              <span class="font-semibold text-nsknavy">45</span>
                              <span class="text-sm text-gray-600 ml-1"
                                >enrolled</span
                              >
                            </div>
                          </td>
                          <td class="px-4 md:px-6 py-4">
                            <span
                              class="status-badge bg-green-100 text-green-700"
                              >Active</span
                            >
                          </td>
                          <td class="px-4 md:px-6 py-4 text-center">
                            <div class="flex justify-center space-x-2">
                              <button
                                class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 transition view-subject"
                                title="View Details"
                              >
                                <i class="fas fa-eye"></i>
                              </button>
                              <button
                                class="text-nskgold hover:text-amber-600 p-2 rounded-full hover:bg-amber-50 transition edit-subject"
                                title="Edit Subject"
                              >
                                <i class="fas fa-edit"></i>
                              </button>
                              <button
                                class="text-nskgreen hover:text-green-600 p-2 rounded-full hover:bg-green-50 transition view-students"
                                title="View Students"
                              >
                                <i class="fas fa-users"></i>
                              </button>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td class="px-4 md:px-6 py-4">
                            <div class="flex items-center">
                              <div
                                class="w-10 h-10 rounded-full bg-nskgreen flex items-center justify-center text-white mr-3"
                              >
                                <i class="fas fa-flask"></i>
                              </div>
                              <div>
                                <p class="font-semibold text-nsknavy">
                                  Physics
                                </p>
                                <p class="text-sm text-gray-600">
                                  Science Subject
                                </p>
                              </div>
                            </div>
                          </td>
                          <td class="px-4 md:px-6 py-4 table-grade">
                            <div class="grade-badge-container">
                              <span
                                class="bg-nskgreen text-white px-3 py-1 rounded-full text-sm font-semibold"
                                >Grade 11</span
                              >
                            </div>
                          </td>
                          <td class="px-4 md:px-6 py-4">
                            <div>
                              <p class="font-medium">Dr. Amina Mohammed</p>
                              <p class="text-sm text-gray-600">Science Dept.</p>
                            </div>
                          </td>
                          <td class="px-4 md:px-6 py-4">
                            <div class="flex items-center">
                              <span class="font-semibold text-nsknavy">38</span>
                              <span class="text-sm text-gray-600 ml-1"
                                >enrolled</span
                              >
                            </div>
                          </td>
                          <td class="px-4 md:px-6 py-4">
                            <span
                              class="status-badge bg-green-100 text-green-700"
                              >Active</span
                            >
                          </td>
                          <td class="px-4 md:px-6 py-4 text-center">
                            <div class="flex justify-center space-x-2">
                              <button
                                class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 transition view-subject"
                                title="View Details"
                              >
                                <i class="fas fa-eye"></i>
                              </button>
                              <button
                                class="text-nskgold hover:text-amber-600 p-2 rounded-full hover:bg-amber-50 transition edit-subject"
                                title="Edit Subject"
                              >
                                <i class="fas fa-edit"></i>
                              </button>
                              <button
                                class="text-nskgreen hover:text-green-600 p-2 rounded-full hover:bg-green-50 transition view-students"
                                title="View Students"
                              >
                                <i class="fas fa-users"></i>
                              </button>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td class="px-4 md:px-6 py-4">
                            <div class="flex items-center">
                              <div
                                class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center text-white mr-3"
                              >
                                <i class="fas fa-book-open"></i>
                              </div>
                              <div>
                                <p class="font-semibold text-nsknavy">
                                  English Literature
                                </p>
                                <p class="text-sm text-gray-600">
                                  Language Subject
                                </p>
                              </div>
                            </div>
                          </td>
                          <td class="px-4 md:px-6 py-4 table-grade">
                            <div class="grade-badge-container">
                              <span
                                class="bg-nskgold text-white px-3 py-1 rounded-full text-sm font-semibold"
                                >Grade 12</span
                              >
                            </div>
                          </td>
                          <td class="px-4 md:px-6 py-4">
                            <div>
                              <p class="font-medium">Mrs. Sarah Ibrahim</p>
                              <p class="text-sm text-gray-600">English Dept.</p>
                            </div>
                          </td>
                          <td class="px-4 md:px-6 py-4">
                            <div class="flex items-center">
                              <span class="font-semibold text-nsknavy">52</span>
                              <span class="text-sm text-gray-600 ml-1"
                                >enrolled</span
                              >
                            </div>
                          </td>
                          <td class="px-4 md:px-6 py-4">
                            <span
                              class="status-badge bg-green-100 text-green-700"
                              >Active</span
                            >
                          </td>
                          <td class="px-4 md:px-6 py-4 text-center">
                            <div class="flex justify-center space-x-2">
                              <button
                                class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 transition view-subject"
                                title="View Details"
                              >
                                <i class="fas fa-eye"></i>
                              </button>
                              <button
                                class="text-nskgold hover:text-amber-600 p-2 rounded-full hover:bg-amber-50 transition edit-subject"
                                title="Edit Subject"
                              >
                                <i class="fas fa-edit"></i>
                              </button>
                              <button
                                class="text-nskgreen hover:text-green-600 p-2 rounded-full hover:bg-green-50 transition view-students"
                                title="View Students"
                              >
                                <i class="fas fa-users"></i>
                              </button>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              <div>
                <div class="bg-nsklight rounded-lg p-4 mb-4">
                  <h4 class="font-semibold text-nsknavy mb-4">
                    Subject Statistics
                  </h4>
                  <div class="space-y-3">
                    <div class="flex justify-between">
                      <span class="text-sm text-gray-600">Total Subjects</span>
                      <span class="font-semibold">24</span>
                    </div>
                    <div class="flex justify-between">
                      <span class="text-sm text-gray-600">Active Classes</span>
                      <span class="font-semibold text-nskgreen">22</span>
                    </div>
                    <div class="flex justify-between">
                      <span class="text-sm text-gray-600">Total Students</span>
                      <span class="font-semibold text-nskblue">1,247</span>
                    </div>
                    <div class="flex justify-between">
                      <span class="text-sm text-gray-600"
                        >Teachers Assigned</span
                      >
                      <span class="font-semibold text-nskgold">18</span>
                    </div>
                  </div>
                </div>

                <div class="bg-white rounded-lg border p-4">
                  <h4 class="font-semibold text-nsknavy mb-4">Quick Actions</h4>
                  <div class="space-y-2">
                    <button
                      class="quick-action w-full text-left p-3 rounded-lg hover:bg-gray-50 transition flex items-center"
                      data-action="add-subject"
                    >
                      <i class="fas fa-plus text-nskblue mr-3"></i>
                      <span class="text-sm">Add New Subject</span>
                    </button>
                    <button
                      class="quick-action w-full text-left p-3 rounded-lg hover:bg-gray-50 transition flex items-center"
                      data-action="import-subjects"
                    >
                      <i class="fas fa-upload text-nskgreen mr-3"></i>
                      <span class="text-sm">Import Subjects</span>
                    </button>
                    <button
                      class="quick-action w-full text-left p-3 rounded-lg hover:bg-gray-50 transition flex items-center"
                      data-action="export-data"
                    >
                      <i class="fas fa-download text-nskgold mr-3"></i>
                      <span class="text-sm">Export Data</span>
                    </button>
                    <button
                      class="quick-action w-full text-left p-3 rounded-lg hover:bg-gray-50 transition flex items-center"
                      data-action="view-reports"
                    >
                      <i class="fas fa-chart-bar text-nskred mr-3"></i>
                      <span class="text-sm">View Reports</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Assignments Tab -->
          <div id="assignmentsTab" class="tab-content hidden">
            <div
              class="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-6"
            >
              <h3 class="text-lg font-bold text-nsknavy">
                Assignment Management
              </h3>
              <div class="flex gap-3">
                <button
                  id="createAssignmentBtn"
                  class="bg-nskblue text-white px-4 py-2 rounded-lg font-semibold hover:bg-nsknavy transition flex items-center text-sm"
                >
                  <i class="fas fa-plus mr-2"></i> Create Assignment
                </button>
                <button
                  id="bulkGradeBtn"
                  class="bg-nskgold text-white px-4 py-2 rounded-lg font-semibold hover:bg-amber-600 transition flex items-center text-sm"
                >
                  <i class="fas fa-edit mr-2"></i> Bulk Grade
                </button>
              </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div class="lg:col-span-2">
                <div class="space-y-4">
                  <div class="assignment-card bg-white border rounded-lg p-4">
                    <div class="flex justify-between items-start mb-3">
                      <div>
                        <h4 class="font-semibold text-nsknavy">
                          Quadratic Equations Practice
                        </h4>
                        <p class="text-sm text-gray-600">
                          Mathematics • Grade 10
                        </p>
                      </div>
                      <span class="status-badge bg-yellow-100 text-yellow-700"
                        >Pending</span
                      >
                    </div>
                    <div
                      class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2 text-sm text-gray-600 mb-3"
                    >
                      <span
                        ><i class="fas fa-calendar mr-1"></i> Due: Nov 20,
                        2023</span
                      >
                      <span><i class="fas fa-users mr-1"></i> 45 students</span>
                      <span><i class="fas fa-clock mr-1"></i> 2 hours</span>
                    </div>
                    <div
                      class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3"
                    >
                      <div class="text-sm">
                        <span class="text-nskgreen font-semibold"
                          >32 submitted</span
                        >
                        •
                        <span class="text-nskred font-semibold"
                          >13 pending</span
                        >
                      </div>
                      <div class="flex gap-2">
                        <button
                          class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 view-assignment"
                        >
                          <i class="fas fa-eye"></i>
                        </button>
                        <button
                          class="text-nskgold hover:text-amber-600 p-2 rounded-full hover:bg-amber-50 grade-assignment"
                        >
                          <i class="fas fa-edit"></i>
                        </button>
                        <button
                          class="text-nskgreen hover:text-green-600 p-2 rounded-full hover:bg-green-50 download-submissions"
                        >
                          <i class="fas fa-download"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <div class="bg-nsklight rounded-lg p-4">
                  <h4 class="font-semibold text-nsknavy mb-4">
                    Assignment Statistics
                  </h4>
                  <div class="space-y-3">
                    <div class="flex justify-between">
                      <span class="text-sm text-gray-600"
                        >Total Assignments</span
                      >
                      <span class="font-semibold">156</span>
                    </div>
                    <div class="flex justify-between">
                      <span class="text-sm text-gray-600">Pending Review</span>
                      <span class="font-semibold text-nskred">23</span>
                    </div>
                    <div class="flex justify-between">
                      <span class="text-sm text-gray-600">Average Score</span>
                      <span class="font-semibold text-nskgreen">84.2%</span>
                    </div>
                    <div class="flex justify-between">
                      <span class="text-sm text-gray-600"
                        >On-time Submissions</span
                      >
                      <span class="font-semibold text-nskblue">91%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Gradebook Tab -->
          <div id="gradebookTab" class="tab-content hidden">
            <div
              class="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-6"
            >
              <h3 class="text-lg font-bold text-nsknavy">Digital Gradebook</h3>
              <div class="flex gap-3">
                <select
                  class="px-3 py-2 border rounded-lg form-input focus:border-nskblue text-sm"
                  id="gradebookClass"
                >
                  <option value="">Select Class</option>
                  <option value="math10">Mathematics - Grade 10</option>
                  <option value="phys11">Physics - Grade 11</option>
                  <option value="eng9">English - Grade 9</option>
                </select>
                <button
                  id="exportGradesBtn"
                  class="bg-nskgreen text-white px-4 py-2 rounded-lg font-semibold hover:bg-green-600 transition flex items-center text-sm"
                >
                  <i class="fas fa-file-excel mr-2"></i> Export
                </button>
              </div>
            </div>

            <div class="bg-white rounded-lg border overflow-hidden">
              <div class="overflow-x-auto">
                <table class="min-w-full">
                  <thead class="bg-gray-50">
                    <tr>
                      <th
                        class="px-4 py-3 text-left text-nsknavy font-semibold"
                      >
                        Student
                      </th>
                      <th
                        class="px-4 py-3 text-center text-nsknavy font-semibold"
                      >
                        Assignment 1
                      </th>
                      <th
                        class="px-4 py-3 text-center text-nsknavy font-semibold"
                      >
                        Assignment 2
                      </th>
                      <th
                        class="px-4 py-3 text-center text-nsknavy font-semibold"
                      >
                        Overall
                      </th>
                      <th
                        class="px-4 py-3 text-center text-nsknavy font-semibold"
                      >
                        Grade
                      </th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-gray-200">
                    <tr class="hover:bg-gray-50">
                      <td class="px-4 py-3">
                        <div class="flex items-center">
                          <div
                            class="w-8 h-8 rounded-full bg-nskblue flex items-center justify-center text-white text-sm font-bold mr-3"
                          >
                            AJ
                          </div>
                          <div>
                            <p class="font-medium">Ahmed Jibril</p>
                            <p class="text-sm text-gray-600">ID: STU001</p>
                          </div>
                        </div>
                      </td>
                      <td class="px-4 py-3 text-center">
                        <input
                          type="number"
                          class="grade-input w-16 px-2 py-1 border rounded text-center focus:border-nskblue"
                          value="85"
                          min="0"
                          max="100"
                        />
                      </td>
                      <td class="px-4 py-3 text-center">
                        <input
                          type="number"
                          class="grade-input w-16 px-2 py-1 border rounded text-center focus:border-nskblue"
                          value="92"
                          min="0"
                          max="100"
                        />
                      </td>
                      <td class="px-4 py-3 text-center font-semibold">85.8%</td>
                      <td class="px-4 py-3 text-center">
                        <span class="grade-badge bg-green-100 text-green-700"
                          >A</span
                        >
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="mt-6 flex justify-end">
              <button
                id="saveGradesBtn"
                class="bg-nskblue text-white px-6 py-2 rounded-lg font-semibold hover:bg-nsknavy transition flex items-center"
              >
                <i class="fas fa-save mr-2"></i> Save All Grades
              </button>
            </div>
          </div>

          <!-- Other tabs would follow similar structure -->
          <div id="examsTab" class="tab-content hidden">
            <div
              class="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-6"
            >
              <h3 class="text-lg font-bold text-nsknavy">
                Examination Schedule
              </h3>
              <button
                id="scheduleExamBtn"
                class="bg-nskblue text-white px-4 py-2 rounded-lg font-semibold hover:bg-nsknavy transition flex items-center text-sm"
              >
                <i class="fas fa-plus mr-2"></i> Schedule Exam
              </button>
            </div>
            <p class="text-gray-600">
              Exam scheduling interface would go here...
            </p>
          </div>

          <div id="curriculumTab" class="tab-content hidden">
            <div
              class="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-6"
            >
              <h3 class="text-lg font-bold text-nsknavy">
                Curriculum Management
              </h3>
              <button
                id="addCurriculumBtn"
                class="bg-nskblue text-white px-4 py-2 rounded-lg font-semibold hover:bg-nsknavy transition flex items-center text-sm"
              >
                <i class="fas fa-plus mr-2"></i> Add Module
              </button>
            </div>
            <p class="text-gray-600">
              Curriculum management interface would go here...
            </p>
          </div>

          <div id="lmsTab" class="tab-content hidden">
            <div class="mb-6">
              <h3 class="text-lg font-bold text-nsknavy mb-2">
                Learning Management System
              </h3>
              <p class="text-gray-600">
                Comprehensive digital learning platform with advanced features
              </p>
            </div>
            <p class="text-gray-600">LMS features interface would go here...</p>
          </div>

          <div id="onlineTab" class="tab-content hidden">
            <div
              class="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-6"
            >
              <h3 class="text-lg font-bold text-nsknavy">
                Online Classes & Virtual Learning
              </h3>
              <button
                id="scheduleClassBtn"
                class="bg-nskblue text-white px-4 py-2 rounded-lg font-semibold hover:bg-nsknavy transition flex items-center text-sm"
              >
                <i class="fas fa-video mr-2"></i> Schedule Class
              </button>
            </div>
            <p class="text-gray-600">
              Online classes interface would go here...
            </p>
          </div>
        </div>
      </div>

      <!-- Enhanced modals -->
      <!-- Bulk Import Modal -->
      <div
        id="bulkImportModal"
        class="modal fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      >
        <div class="bg-white rounded-xl shadow-2xl max-w-md w-full p-6">
          <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-bold text-nsknavy">
              Bulk Import Academic Data
            </h3>
            <button class="close-modal text-gray-500 hover:text-gray-700">
              <i class="fas fa-times"></i>
            </button>
          </div>

          <div class="space-y-4">
            <div class="drag-drop-zone" id="dragDropZone">
              <i
                class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-4"
              ></i>
              <p class="text-gray-600 mb-2">Drag and drop your files here</p>
              <p class="text-sm text-gray-500 mb-4">or click to browse</p>
              <input
                type="file"
                id="fileInput"
                class="hidden"
                accept=".csv,.xlsx,.xls"
                multiple
              />
              <button
                class="bg-nskblue text-white px-4 py-2 rounded-lg hover:bg-nsknavy transition"
                onclick="document.getElementById('fileInput').click()"
              >
                Choose Files
              </button>
            </div>

            <div class="text-sm text-gray-600">
              <p class="mb-2">Supported formats:</p>
              <ul class="list-disc list-inside space-y-1">
                <li>CSV files (.csv)</li>
                <li>Excel files (.xlsx, .xls)</li>
              </ul>
            </div>

            <div class="flex justify-end space-x-3 pt-4">
              <button
                class="close-modal px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition"
              >
                Cancel
              </button>
              <button
                id="downloadTemplateBtn"
                class="px-4 py-2 bg-nskgold text-white rounded-lg font-semibold hover:bg-amber-600 transition"
              >
                Download Template
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Add Course Modal -->
      <div
        id="addCourseModal"
        class="modal fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      >
        <div class="bg-white rounded-xl shadow-2xl max-w-lg w-full p-6">
          <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-bold text-nsknavy">Add New Course</h3>
            <button class="close-modal text-gray-500 hover:text-gray-700">
              <i class="fas fa-times"></i>
            </button>
          </div>

          <form id="addCourseForm" class="space-y-4">
            <div>
              <label class="block text-gray-700 mb-2">Course Name</label>
              <input
                type="text"
                class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                placeholder="Enter course name"
                required
              />
            </div>

            <div class="grid grid-cols-2 gap-4">
              <div>
                <label class="block text-gray-700 mb-2">Grade Level</label>
                <select
                  class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                  required
                >
                  <option value="">Select Grade</option>
                  <option value="9">Grade 9</option>
                  <option value="10">Grade 10</option>
                  <option value="11">Grade 11</option>
                </select>
              </div>
              <div>
                <label class="block text-gray-700 mb-2">Department</label>
                <select
                  class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                  required
                >
                  <option value="">Select Department</option>
                  <option value="science">Science</option>
                  <option value="arts">Arts</option>
                  <option value="commerce">Commerce</option>
                </select>
              </div>
            </div>

            <div class="flex justify-end space-x-3 pt-4">
              <button
                type="button"
                class="close-modal px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                class="px-4 py-2 bg-nskblue text-white rounded-lg font-semibold hover:bg-nsknavy transition"
              >
                Add Course
              </button>
            </div>
          </form>
        </div>
      </div>

      <!-- Add Subject Modal -->
      <div
        id="addSubjectModal"
        class="modal fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      >
        <div class="bg-white rounded-xl shadow-2xl max-w-lg w-full p-6">
          <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-bold text-nsknavy">Add New Subject</h3>
            <button class="close-modal text-gray-500 hover:text-gray-700">
              <i class="fas fa-times"></i>
            </button>
          </div>

          <form id="addSubjectForm" class="space-y-4">
            <div>
              <label class="block text-gray-700 mb-2">Subject Name</label>
              <input
                type="text"
                class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                placeholder="Enter subject name"
                required
              />
            </div>

            <div class="grid grid-cols-2 gap-4">
              <div>
                <label class="block text-gray-700 mb-2">Grade Level</label>
                <select
                  class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                  required
                >
                  <option value="">Select Grade</option>
                  <option value="7">Grade 7</option>
                  <option value="8">Grade 8</option>
                  <option value="9">Grade 9</option>
                  <option value="10">Grade 10</option>
                  <option value="11">Grade 11</option>
                  <option value="12">Grade 12</option>
                </select>
              </div>
              <div>
                <label class="block text-gray-700 mb-2">Department</label>
                <select
                  class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                  required
                >
                  <option value="">Select Department</option>
                  <option value="science">Science</option>
                  <option value="arts">Arts</option>
                  <option value="commerce">Commerce</option>
                </select>
              </div>
            </div>

            <div>
              <label class="block text-gray-700 mb-2">Teacher</label>
              <select
                class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                required
              >
                <option value="">Select Teacher</option>
                <option value="johnson">Mr. Johnson Adeyemi</option>
                <option value="amina">Dr. Amina Mohammed</option>
                <option value="sarah">Mrs. Sarah Ibrahim</option>
              </select>
            </div>

            <div>
              <label class="block text-gray-700 mb-2">Description</label>
              <textarea
                class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                placeholder="Enter subject description"
                rows="3"
              ></textarea>
            </div>

            <div class="flex justify-end space-x-3 pt-4">
              <button
                type="button"
                class="close-modal px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                class="px-4 py-2 bg-nskblue text-white rounded-lg font-semibold hover:bg-nsknavy transition"
              >
                Add Subject
              </button>
            </div>
          </form>
        </div>
      </div>

      <!-- Manage Curriculum Modal -->
      <div
        id="manageCurriculumModal"
        class="modal fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      >
        <div class="bg-white rounded-xl shadow-2xl max-w-4xl w-full p-6">
          <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-bold text-nsknavy">Manage Curriculum</h3>
            <button class="close-modal text-gray-500 hover:text-gray-700">
              <i class="fas fa-times"></i>
            </button>
          </div>

          <div class="space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 class="text-lg font-semibold text-nsknavy mb-4">Curriculum Modules</h4>
                <div class="space-y-3">
                  <div class="curriculum-module bg-white border rounded-lg p-4">
                    <div class="flex justify-between items-center mb-2">
                      <h5 class="font-semibold">Algebra Fundamentals</h5>
                      <span class="status-badge bg-green-100 text-green-700">Active</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-2">Grade 10 Mathematics</p>
                    <div class="flex justify-between text-sm">
                      <span>12 Lessons</span>
                      <span>4 Weeks</span>
                    </div>
                  </div>
                  <div class="curriculum-module bg-white border rounded-lg p-4">
                    <div class="flex justify-between items-center mb-2">
                      <h5 class="font-semibold">Physics Mechanics</h5>
                      <span class="status-badge bg-yellow-100 text-yellow-700">Draft</span>
                    </div>
                    <p class="text-sm text-gray-600 mb-2">Grade 11 Science</p>
                    <div class="flex justify-between text-sm">
                      <span>8 Lessons</span>
                      <span>3 Weeks</span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h4 class="text-lg font-semibold text-nsknavy mb-4">Add New Module</h4>
                <form id="addModuleForm" class="space-y-4">
                  <div>
                    <label class="block text-gray-700 mb-2">Module Name</label>
                    <input
                      type="text"
                      class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                      placeholder="Enter module name"
                      required
                    />
                  </div>

                  <div class="grid grid-cols-2 gap-4">
                    <div>
                      <label class="block text-gray-700 mb-2">Subject</label>
                      <select
                        class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                        required
                      >
                        <option value="">Select Subject</option>
                        <option value="math">Mathematics</option>
                        <option value="physics">Physics</option>
                        <option value="english">English</option>
                      </select>
                    </div>
                    <div>
                      <label class="block text-gray-700 mb-2">Grade</label>
                      <select
                        class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                        required
                      >
                        <option value="">Select Grade</option>
                        <option value="10">Grade 10</option>
                        <option value="11">Grade 11</option>
                        <option value="12">Grade 12</option>
                      </select>
                    </div>
                  </div>

                  <div class="grid grid-cols-2 gap-4">
                    <div>
                      <label class="block text-gray-700 mb-2">Duration (Weeks)</label>
                      <input
                        type="number"
                        class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                        min="1"
                        max="12"
                        required
                      />
                    </div>
                    <div>
                      <label class="block text-gray-700 mb-2">Total Lessons</label>
                      <input
                        type="number"
                        class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue"
                        min="1"
                        max="50"
                        required
                      />
                    </div>
                  </div>

                  <div class="flex justify-end space-x-3 pt-4">
                    <button
                      type="button"
                      class="close-modal px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      class="px-4 py-2 bg-nskgreen text-white rounded-lg font-semibold hover:bg-green-600 transition"
                    >
                      Add Module
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Floating Action Button -->
      <button
        class="floating-action-btn"
        id="floatingActionBtn"
        title="Quick Actions"
      >
        <i class="fas fa-plus"></i>
      </button>

      <!-- Notification Toast -->
      <div id="notificationToast" class="notification-toast">
        <div class="flex items-center">
          <i class="fas fa-check-circle text-nskgreen mr-3"></i>
          <div>
            <p class="font-semibold">Success!</p>
            <p class="text-sm text-gray-600" id="toastMessage">
              Operation completed successfully.
            </p>
          </div>
        </div>
      </div>
    </main>
    <!-- Include footer -->
<script src="footer.js"></script>

  <script>
  // Initialize page with proper state
  document.addEventListener("DOMContentLoaded", function () {
    // Set first tab as active by default
    const firstTab = document.querySelector(".tab-button");
    if (firstTab) firstTab.click();

    // Initialize progress bars with animation
    setTimeout(() => {
      document.querySelectorAll(".progress-fill").forEach((bar) => {
        const width = bar.style.width;
        bar.style.width = "0%";
        setTimeout(() => {
          bar.style.width = width;
        }, 100);
      });
    }, 500);

    // Close modals with Escape key
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") {
        closeAllModals();
      }
    });

    // Initialize all functionality
    initializePageFunctionality();
  });

  function initializePageFunctionality() {
    // Enhanced tab switching functionality
    document.querySelectorAll(".tab-button").forEach((button) => {
      button.addEventListener("click", function () {
        const tabName = this.getAttribute("data-tab");

        // Update tab buttons
        document.querySelectorAll(".tab-button").forEach((btn) => {
          btn.classList.remove(
            "active",
            "bg-nskblue",
            "text-white",
            "border-nskblue"
          );
          btn.classList.add("border-gray-300", "text-gray-700");
        });

        // Add active class to clicked tab
        this.classList.add(
          "active",
          "bg-nskblue",
          "text-white",
          "border-nskblue"
        );
        this.classList.remove("border-gray-300", "text-gray-700");

        // Update tab content
        document.querySelectorAll(".tab-content").forEach((content) => {
          content.classList.add("hidden");
          content.classList.remove("active");
        });

        const targetContent = document.getElementById(tabName + "Tab");
        if (targetContent) {
          targetContent.classList.remove("hidden");
          targetContent.classList.add("active");
        }

        showNotification(`Switched to ${tabName} management`);
      });
    });

    // Enhanced modal functionality
    const modals = document.querySelectorAll(".modal");
    const bulkImportBtn = document.getElementById("bulkImportBtn");
    const addCourseBtn = document.getElementById("addCourseBtn");
    const addSubjectBtn = document.getElementById("addSubjectBtn");
    const manageCurriculumBtn = document.getElementById("manageCurriculumBtn");
    const scheduleClassBtn = document.getElementById("scheduleClassBtn");
    const floatingActionBtn = document.getElementById("floatingActionBtn");
    const closeModalButtons = document.querySelectorAll(".close-modal");

    // Open modal functions - FIXED: Added missing event listeners
    if (bulkImportBtn)
      bulkImportBtn.addEventListener("click", () =>
        openModal("bulkImportModal")
      );
    if (addCourseBtn)
      addCourseBtn.addEventListener("click", () =>
        openModal("addCourseModal")
      );
    if (addSubjectBtn)
      addSubjectBtn.addEventListener("click", () =>
        openModal("addSubjectModal")
      );
    if (manageCurriculumBtn)
      manageCurriculumBtn.addEventListener("click", () =>
        openModal("manageCurriculumModal")
      );
    if (scheduleClassBtn)
      scheduleClassBtn.addEventListener("click", () => {
        showNotification("Schedule Class feature would open here");
      });

    // Drag and drop functionality
    const dragDropZone = document.getElementById("dragDropZone");
    const fileInput = document.getElementById("fileInput");

    if (dragDropZone) {
      dragDropZone.addEventListener("dragover", (e) => {
        e.preventDefault();
        dragDropZone.classList.add("dragover");
      });

      dragDropZone.addEventListener("dragleave", () => {
        dragDropZone.classList.remove("dragover");
      });

      dragDropZone.addEventListener("drop", (e) => {
        e.preventDefault();
        dragDropZone.classList.remove("dragover");
        const files = e.dataTransfer.files;
        handleFileUpload(files);
      });

      dragDropZone.addEventListener("click", () => {
        fileInput.click();
      });
    }

    if (fileInput) {
      fileInput.addEventListener("change", (e) => {
        handleFileUpload(e.target.files);
      });
    }

    function handleFileUpload(files) {
      if (files.length > 0) {
        showNotification(`${files.length} file(s) selected for upload`);
        // Simulate upload process
        setTimeout(() => {
          showNotification("Files uploaded successfully!");
        }, 2000);
      }
    }

    // Enhanced grade input functionality
    document.querySelectorAll(".grade-input").forEach((input) => {
      input.addEventListener("change", function () {
        const value = parseInt(this.value);
        const row = this.closest("tr");

        // Calculate overall grade
        const grades = row.querySelectorAll(".grade-input");
        let total = 0;
        let count = 0;

        grades.forEach((grade) => {
          if (grade.value) {
            total += parseInt(grade.value);
            count++;
          }
        });

        if (count > 0) {
          const average = (total / count).toFixed(1);
          const overallCell = row.querySelector("td:nth-last-child(2)");
          const gradeCell = row.querySelector("td:last-child span");

          if (overallCell) overallCell.textContent = average + "%";

          // Update grade letter
          let gradeLetter = "F";
          let gradeClass = "bg-red-100 text-red-700";

          if (average >= 90) {
            gradeLetter = "A+";
            gradeClass = "bg-green-100 text-green-700";
          } else if (average >= 85) {
            gradeLetter = "A";
            gradeClass = "bg-green-100 text-green-700";
          } else if (average >= 80) {
            gradeLetter = "B+";
            gradeClass = "bg-blue-100 text-blue-700";
          } else if (average >= 75) {
            gradeLetter = "B";
            gradeClass = "bg-blue-100 text-blue-700";
          } else if (average >= 70) {
            gradeLetter = "C+";
            gradeClass = "bg-yellow-100 text-yellow-700";
          } else if (average >= 65) {
            gradeLetter = "C";
            gradeClass = "bg-yellow-100 text-yellow-700";
          } else if (average >= 60) {
            gradeLetter = "D";
            gradeClass = "bg-orange-100 text-orange-700";
          }

          if (gradeCell) {
            gradeCell.className = `grade-badge ${gradeClass}`;
            gradeCell.textContent = gradeLetter;
          }
        }

        showNotification("Grade updated successfully");
      });
    });

    // Floating action button functionality
    if (floatingActionBtn) {
      floatingActionBtn.addEventListener("click", () => {
        const activeTab = document
          .querySelector(".tab-button.active")
          .getAttribute("data-tab");

        switch (activeTab) {
          case "courses":
            openModal("addSubjectModal");
            break;
          case "assignments":
            showNotification("Create Assignment feature would open here");
            break;
          case "exams":
            showNotification("Schedule Exam feature would open here");
            break;
          case "online":
            showNotification("Schedule Online Class feature would open here");
            break;
          default:
            showNotification("Quick action not available for this tab");
        }
      });
    }

    // Enhanced notification system
    function showNotification(message, type = "success") {
      const toast = document.getElementById("notificationToast");
      const messageEl = document.getElementById("toastMessage");

      if (toast && messageEl) {
        messageEl.textContent = message;
        toast.classList.add("show");

        setTimeout(() => {
          toast.classList.remove("show");
        }, 3000);
      }
    }

    // Auto-save functionality for grades
    let saveTimeout;
    document.querySelectorAll(".grade-input").forEach((input) => {
      input.addEventListener("input", function () {
        clearTimeout(saveTimeout);
        saveTimeout = setTimeout(() => {
          // Simulate auto-save
          console.log("Auto-saving grades...");
          showNotification("Grades auto-saved");
        }, 2000);
      });
    });

    // Enhanced filter functionality
    document
      .getElementById("filterBtn")
      .addEventListener("click", function () {
        const originalText = this.innerHTML;
        this.innerHTML =
          '<div class="loading-spinner mr-2"></div> Filtering...';
        this.disabled = true;

        setTimeout(() => {
          this.innerHTML = originalText;
          this.disabled = false;
          showNotification("Filters applied successfully!");
        }, 1500);
      });

    // Real-time stats updates
    function updateStats() {
      const stats = {
        totalSubjects: Math.floor(Math.random() * 5) + 22,
        activeAssignments: Math.floor(Math.random() * 10) + 150,
        avgPerformance: Math.floor(Math.random() * 5) + 80,
        onlineClasses: Math.floor(Math.random() * 3) + 6,
      };

      document.getElementById("totalSubjects").textContent =
        stats.totalSubjects;
      document.getElementById("activeAssignments").textContent =
        stats.activeAssignments;
      document.getElementById("avgPerformance").textContent =
        stats.avgPerformance + "%";
      document.getElementById("onlineClasses").textContent =
        stats.onlineClasses;
    }

    // Update stats every 30 seconds
    setInterval(updateStats, 30000);

    // Enhanced form submissions
    document
      .getElementById("addCourseForm")
      .addEventListener("submit", function (e) {
        e.preventDefault();

        // Simulate API call
        showNotification("Adding new course...");

        setTimeout(() => {
          showNotification("Course added successfully!");
          this.reset();
          closeAllModals();
        }, 2000);
      });

    // Add Subject Form Submission
    document
      .getElementById("addSubjectForm")
      .addEventListener("submit", function (e) {
        e.preventDefault();

        // Simulate API call
        showNotification("Adding new subject...");

        setTimeout(() => {
          showNotification("Subject added successfully!");
          this.reset();
          closeAllModals();
        }, 2000);
      });

    // Add Module Form Submission
    document
      .getElementById("addModuleForm")
      .addEventListener("submit", function (e) {
        e.preventDefault();

        // Simulate API call
        showNotification("Adding new curriculum module...");

        setTimeout(() => {
          showNotification("Curriculum module added successfully!");
          this.reset();
          closeAllModals();
        }, 2000);
      });

    // Quick Actions functionality
    document.querySelectorAll(".quick-action").forEach((button) => {
      button.addEventListener("click", function () {
        const action = this.getAttribute("data-action");

        switch (action) {
          case "add-subject":
            openModal("addSubjectModal");
            break;
          case "import-subjects":
            openModal("bulkImportModal");
            break;
          case "export-data":
            exportData();
            break;
          case "view-reports":
            // Switch to reports tab or open reports modal
            document.querySelector('[data-tab="lms"]').click();
            showNotification("Redirecting to reports...");
            break;
        }
      });
    });

    // Table action buttons functionality
    document.querySelectorAll(".view-subject").forEach((button) => {
      button.addEventListener("click", function () {
        const row = this.closest("tr");
        const subjectName = row.querySelector(".font-semibold").textContent;
        showNotification(`Viewing details for ${subjectName}`);
      });
    });

    document.querySelectorAll(".edit-subject").forEach((button) => {
      button.addEventListener("click", function () {
        const row = this.closest("tr");
        const subjectName = row.querySelector(".font-semibold").textContent;
        showNotification(`Editing ${subjectName}`);
        // You can open an edit modal here
      });
    });

    document.querySelectorAll(".view-students").forEach((button) => {
      button.addEventListener("click", function () {
        const row = this.closest("tr");
        const subjectName = row.querySelector(".font-semibold").textContent;
        showNotification(`Viewing students for ${subjectName}`);
      });
    });

    // Single exportData function
    function exportData() {
      showNotification("Preparing data export...");
      // Simulate export process
      setTimeout(() => {
        const link = document.createElement("a");
        link.href =
          "data:text/csv;charset=utf-8,Subject,Grade,Teacher,Students,Status\nMathematics,10,Mr. Johnson,45,Active\nPhysics,11,Dr. Amina,38,Active\nEnglish Literature,12,Mrs. Sarah,52,Active";
        link.download =
          "subjects_export_" +
          new Date().toISOString().split("T")[0] +
          ".csv";
        link.click();
        showNotification("Data exported successfully!");
      }, 1500);
    }

    // Download template functionality
    document
      .getElementById("downloadTemplateBtn")
      .addEventListener("click", function () {
        showNotification("Template downloaded successfully!");
        // Simulate file download
        const link = document.createElement("a");
        link.href =
          "data:text/csv;charset=utf-8,Subject,Grade,Teacher,Department\nMathematics,10,Mr. Johnson,Science\n";
        link.download = "academic_data_template.csv";
        link.click();
      });

    // Modal functionality
    function openModal(modalId) {
      const modal = document.getElementById(modalId);
      if (modal) {
        modal.style.display = "flex";
        setTimeout(() => {
          modal.classList.add("active");
        }, 10);
      }
    }

    function closeAllModals() {
      modals.forEach((modal) => {
        modal.classList.remove("active");
        setTimeout(() => {
          modal.style.display = "none";
        }, 300);
      });
    }

    // Close modal functionality
    closeModalButtons.forEach((button) => {
      button.addEventListener("click", closeAllModals);
    });

    // Close modal on outside click
    modals.forEach((modal) => {
      modal.addEventListener("click", function (e) {
        if (e.target === this) {
          closeAllModals();
        }
      });
    });

    // Sidebar toggle functionality
    document
      .querySelector(".sidebar-toggle")
      ?.addEventListener("click", function () {
        const sidebar = document.querySelector(".sidebar");
        sidebar.classList.toggle("mobile-show");
      });

    // Close sidebar when clicking on a link (mobile)
    document.querySelectorAll(".sidebar a").forEach((link) => {
      link.addEventListener("click", () => {
        if (window.innerWidth < 768) {
          document.querySelector(".sidebar").classList.remove("mobile-show");
        }
      });
    });
  }
</script>
  </body>
</html>