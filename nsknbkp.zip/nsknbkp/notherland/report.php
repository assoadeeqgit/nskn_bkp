<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports & Analytics - Northland Schools Kano</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        nskblue: '#1e40af',
                        nsklightblue: '#3b82f6',
                        nsknavy: '#1e3a8a',
                        nskgold: '#f59e0b',
                        nsklight: '#f0f9ff',
                        nskgreen: '#10b981',
                        nskred: '#ef4444'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap');
        
        body {
            font-family: 'Montserrat', sans-serif;
            background: #f8fafc;
        }
        
        .logo-container {
            background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%);
        }
        
        .report-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .report-card:hover {
            transform: translateY(-5px);
        }
        
        .nav-item {
            position: relative;
        }
        
        .nav-item::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: -5px;
            left: 0;
            background-color: #f59e0b;
            transition: width 0.3s ease;
        }
        
        .nav-item:hover::after {
            width: 100%;
        }
        
        .sidebar {
            transition: all 0.3s ease;
            width: 250px;
        }
        
        .sidebar.collapsed {
            width: 80px;
        }
        
        .main-content {
            transition: all 0.3s ease;
            margin-left: 250px;
            width: calc(100% - 250px);
        }
        
        .main-content.expanded {
            margin-left: 80px;
            width: calc(100% - 80px);
        }
        
        @media (max-width: 768px) {
            .sidebar {
                margin-left: -250px;
            }
            
            .sidebar.mobile-show {
                margin-left: 0;
            }
            
            .main-content {
                margin-left: 0;
                width: 100%;
            }
        }
        
        .notification-dot {
            position: absolute;
            top: -5px;
            right: -5px;
            width: 12px;
            height: 12px;
            background-color: #ef4444;
            border-radius: 50%;
        }
        
        .report-table {
            border-collapse: separate;
            border-spacing: 0;
        }
        
        .report-table th {
            background-color: #f8fafc;
        }
        
        .report-table tr:last-child td {
            border-bottom: 0;
        }
        
        .status-badge {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        /* Fixed Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            opacity: 0;
            transition: opacity 0.3s ease;
            align-items: center;
            justify-content: center;
        }
        
        .modal.active {
            display: flex;
            opacity: 1;
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            padding: 24px;
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            transform: scale(0.7);
            transition: transform 0.3s ease;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        
        .modal.active .modal-content {
            transform: scale(1);
        }
        
        .tab-button {
            transition: all 0.3s ease;
        }
        
        .tab-button.active {
            background-color: #1e40af;
            color: white;
        }
        
        .progress-bar {
            height: 8px;
            background-color: #e5e7eb;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            border-radius: 4px;
        }
        
        .sidebar-text {
            transition: all 0.3s ease;
        }
        
        .sidebar.collapsed .sidebar-text {
            display: none;
        }

        .chart-container {
            position: relative;
            height: 250px;
            width: 100%;
        }
    </style>
</head>
<body class="flex">
    <!-- Sidebar Navigation -->
    <script src="sidebar.js"></script>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <header class="bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="md:hidden text-nsknavy">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold text-nsknavy">Reports & Analytics</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <div class="flex items-center space-x-2 bg-nsklight rounded-full py-2 px-4">
                            <i class="fas fa-search text-gray-500"></i>
                            <input type="text" placeholder="Search reports..." class="bg-transparent outline-none w-32 md:w-64">
                        </div>
                    </div>
                    
                    <div class="relative">
                        <i class="fas fa-bell text-nsknavy text-xl"></i>
                        <div class="notification-dot"></div>
                    </div>
                    
                    <div class="hidden md:flex items-center space-x-2">
                        <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center text-white font-bold">
                            A
                        </div>
                        <div>
                            <p class="text-sm font-semibold text-nsknavy">Admin User</p>
                            <p class="text-xs text-gray-600">Administrator</p>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Reports Content -->
        <div class="p-6">
            <!-- Stats Overview -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="report-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nskgreen p-4 rounded-full mr-4">
                        <i class="fas fa-chart-line text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Reports Generated</p>
                        <p class="text-2xl font-bold text-nsknavy">48</p>
                        <p class="text-xs text-nskgreen">This month</p>
                    </div>
                </div>
                
                <div class="report-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nskblue p-4 rounded-full mr-4">
                        <i class="fas fa-file-export text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Exports</p>
                        <p class="text-2xl font-bold text-nsknavy">26</p>
                        <p class="text-xs text-nskblue">PDF & Excel</p>
                    </div>
                </div>
                
                <div class="report-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nskgold p-4 rounded-full mr-4">
                        <i class="fas fa-users text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Most Viewed</p>
                        <p class="text-2xl font-bold text-nsknavy">Attendance</p>
                        <p class="text-xs text-nskgold">156 views</p>
                    </div>
                </div>
                
                <div class="report-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nskred p-4 rounded-full mr-4">
                        <i class="fas fa-clock text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Scheduled</p>
                        <p class="text-2xl font-bold text-nsknavy">5</p>
                        <p class="text-xs text-nskred">Auto-generated</p>
                    </div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="bg-white rounded-xl shadow-md p-6 mb-8">
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <h2 class="text-xl font-bold text-nsknavy">Report Center</h2>
                    
                    <div class="flex flex-wrap gap-4">
                        <select class="px-4 py-2 border rounded-lg form-input focus:border-nskblue">
                            <option value="">All Report Types</option>
                            <option value="attendance">Attendance Reports</option>
                            <option value="academic">Academic Reports</option>
                            <option value="financial">Financial Reports</option>
                            <option value="behavioral">Behavioral Reports</option>
                        </select>
                        
                        <select class="px-4 py-2 border rounded-lg form-input focus:border-nskblue">
                            <option value="">All Time Periods</option>
                            <option value="daily">Daily</option>
                            <option value="weekly">Weekly</option>
                            <option value="monthly">Monthly</option>
                            <option value="term">Term-wise</option>
                        </select>
                        
                        <button id="filterBtn" class="bg-nskblue text-white px-4 py-2 rounded-lg font-semibold hover:bg-nsknavy transition flex items-center">
                            <i class="fas fa-filter mr-2"></i> Filter
                        </button>
                        
                        <!-- <button id="generateReportBtn" class="bg-nskgreen text-white px-4 py-2 rounded-lg font-semibold hover:bg-green-600 transition flex items-center">
                            <i class="fas fa-plus mr-2"></i> Generate Report
                        </button>
                        
                        <button id="scheduleReportBtn" class="bg-nskgold text-white px-4 py-2 rounded-lg font-semibold hover:bg-amber-600 transition flex items-center">
                            <i class="fas fa-clock mr-2"></i> Schedule
                        </button> -->
                    </div>
                </div>
            </div>

            <!-- Reports Tabs -->
            <div class="bg-white rounded-xl shadow-md p-6 mb-8">
                <div class="flex flex-wrap gap-2 mb-6">
                    <button class="tab-button px-4 py-2 rounded-lg border border-nskblue text-nskblue font-semibold active" data-tab="all">
                        All Reports
                    </button>
                    <button class="tab-button px-4 py-2 rounded-lg border border-gray-300 text-gray-700 font-semibold" data-tab="academic">
                        Academic
                    </button>
                    <!-- <button class="tab-button px-4 py-2 rounded-lg border border-gray-300 text-gray-700 font-semibold" data-tab="attendance">
                        Attendance
                    </button>
                    <button class="tab-button px-4 py-2 rounded-lg border border-gray-300 text-gray-700 font-semibold" data-tab="financial">
                        Financial
                    </button> -->
                </div>
                
                <!-- All Reports Tab -->
                <div id="allTab" class="tab-content active">
                    <div class="overflow-x-auto">
                        <table class="min-w-full report-table">
                            <thead>
                                <tr>
                                    <th class="py-3 px-6 text-left text-nsknavy">Report Name</th>
                                    <th class="py-3 px-6 text-left text-nsknavy">Type</th>
                                    <th class="py-3 px-6 text-left text-nsknavy">Generated On</th>
                                    <th class="py-3 px-6 text-left text-nsknavy">Period</th>
                                    <th class="py-3 px-6 text-left text-nsknavy">Views</th>
                                    <th class="py-3 px-6 text-left text-nsknavy">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                <tr>
                                    <td class="py-4 px-6">
                                        <div class="flex items-center">
                                            <div class="w-10 h-10 rounded-full bg-nskblue flex items-center justify-center text-white font-bold mr-3">
                                                <i class="fas fa-user-check"></i>
                                            </div>
                                            <div>
                                                <p class="font-semibold">Monthly Attendance Report</p>
                                                <p class="text-sm text-gray-600">November 2023</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="py-4 px-6">
                                        <span class="status-badge bg-blue-100 text-nskblue">Attendance</span>
                                    </td>
                                    <td class="py-4 px-6">
                                        <p class="text-sm">01 Dec 2023</p>
                                        <p class="text-xs text-gray-600">10:30 AM</p>
                                    </td>
                                    <td class="py-4 px-6">
                                        <p class="text-sm">Nov 1-30, 2023</p>
                                    </td>
                                    <td class="py-4 px-6">
                                        <p class="text-sm">156</p>
                                    </td>
                                    <td class="py-4 px-6">
                                        <div class="flex space-x-2">
                                            <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 view-report">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="text-nskgreen hover:text-green-700 p-2 rounded-full hover:bg-green-50 download-report" data-filename="monthly_attendance_nov2023.pdf">
                                                <i class="fas fa-download"></i>
                                            </button>
                                            <button class="text-nskred hover:text-red-700 p-2 rounded-full hover:bg-red-50 delete-report">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                
                                <tr>
                                    <td class="py-4 px-6">
                                        <div class="flex items-center">
                                            <div class="w-10 h-10 rounded-full bg-nskgreen flex items-center justify-center text-white font-bold mr-3">
                                                <i class="fas fa-book"></i>
                                            </div>
                                            <div>
                                                <p class="font-semibold">Term 1 Academic Performance</p>
                                                <p class="text-sm text-gray-600">All Grades</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="py-4 px-6">
                                        <span class="status-badge bg-green-100 text-nskgreen">Academic</span>
                                    </td>
                                    <td class="py-4 px-6">
                                        <p class="text-sm">15 Nov 2023</p>
                                        <p class="text-xs text-gray-600">02:15 PM</p>
                                    </td>
                                    <td class="py-4 px-6">
                                        <p class="text-sm">Term 1, 2023</p>
                                    </td>
                                    <td class="py-4 px-6">
                                        <p class="text-sm">98</p>
                                    </td>
                                    <td class="py-4 px-6">
                                        <div class="flex space-x-2">
                                            <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 view-report">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="text-nskgreen hover:text-green-700 p-2 rounded-full hover:bg-green-50 download-report" data-filename="term1_academic_performance.xlsx">
                                                <i class="fas fa-download"></i>
                                            </button>
                                            <button class="text-nskred hover:text-red-700 p-2 rounded-full hover:bg-red-50 delete-report">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                
                                <tr>
                                    <td class="py-4 px-6">
                                        <div class="flex items-center">
                                            <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center text-white font-bold mr-3">
                                                <i class="fas fa-money-bill-wave"></i>
                                            </div>
                                            <div>
                                                <p class="font-semibold">Quarterly Financial Summary</p>
                                                <p class="text-sm text-gray-600">Q3 2023</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="py-4 px-6">
                                        <span class="status-badge bg-amber-100 text-amber-700">Financial</span>
                                    </td>
                                    <td class="py-4 px-6">
                                        <p class="text-sm">05 Oct 2023</p>
                                        <p class="text-xs text-gray-600">09:45 AM</p>
                                    </td>
                                    <td class="py-4 px-6">
                                        <p class="text-sm">Jul-Sep, 2023</p>
                                    </td>
                                    <td class="py-4 px-6">
                                        <p class="text-sm">64</p>
                                    </td>
                                    <td class="py-4 px-6">
                                        <div class="flex space-x-2">
                                            <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50 view-report">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="text-nskgreen hover:text-green-700 p-2 rounded-full hover:bg-green-50 download-report" data-filename="q3_financial_summary.pdf">
                                                <i class="fas fa-download"></i>
                                            </button>
                                            <button class="text-nskred hover:text-red-700 p-2 rounded-full hover:bg-red-50 delete-report">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Academic Reports Tab (Hidden by default) -->
                <div id="academicTab" class="tab-content hidden">
                    <div class="text-center py-8">
                        <i class="fas fa-book text-4xl text-nskgreen mb-4"></i>
                        <h3 class="text-xl font-semibold text-nsknavy mb-2">Academic Reports</h3>
                        <p class="text-gray-600">No academic reports available. Generate a new report to get started.</p>
                    </div>
                </div>
                
                <!-- Attendance Reports Tab (Hidden by default) -->
                <div id="attendanceTab" class="tab-content hidden">
                    <div class="text-center py-8">
                        <i class="fas fa-user-check text-4xl text-nskblue mb-4"></i>
                        <h3 class="text-xl font-semibold text-nsknavy mb-2">Attendance Reports</h3>
                        <p class="text-gray-600">No attendance reports available. Generate a new report to get started.</p>
                    </div>
                </div>
                
                <!-- Financial Reports Tab (Hidden by default) -->
                <div id="financialTab" class="tab-content hidden">
                    <div class="text-center py-8">
                        <i class="fas fa-money-bill-wave text-4xl text-nskgold mb-4"></i>
                        <h3 class="text-xl font-semibold text-nsknavy mb-2">Financial Reports</h3>
                        <p class="text-gray-600">No financial reports available. Generate a new report to get started.</p>
                    </div>
                </div>
            </div>

            <!-- Analytics Dashboard -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                <div class="report-card bg-white rounded-xl shadow-md p-6">
                    <h2 class="text-xl font-bold text-nsknavy mb-4">Report Generation Trends</h2>
                    <div class="chart-container">
                        <canvas id="reportTrendsChart"></canvas>
                    </div>
                </div>
                
                <div class="report-card bg-white rounded-xl shadow-md p-6">
                    <h2 class="text-xl font-bold text-nsknavy mb-4">Report Types Distribution</h2>
                    <div class="chart-container">
                        <canvas id="reportTypesChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Popular Reports -->
            <div class="bg-white rounded-xl shadow-md p-6">
                <h2 class="text-xl font-bold text-nsknavy mb-6">Most Popular Reports</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
                        <div class="flex items-center justify-between mb-3">
                            <span class="bg-blue-100 text-nskblue text-xs px-2 py-1 rounded">ATTENDANCE</span>
                            <span class="text-xs text-gray-500">156 views</span>
                        </div>
                        <h3 class="font-semibold mb-2">Monthly Attendance Report</h3>
                        <p class="text-sm text-gray-600 mb-4">November 2023 attendance summary for all classes</p>
                        <div class="flex justify-between items-center">
                            <span class="text-xs text-gray-500">Generated: 01 Dec 2023</span>
                            <button class="text-nskblue hover:text-nsknavy text-sm popular-download" data-filename="monthly_attendance_nov2023.pdf">
                                <i class="fas fa-download mr-1"></i> Download
                            </button>
                        </div>
                    </div>
                    
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
                        <div class="flex items-center justify-between mb-3">
                            <span class="bg-green-100 text-nskgreen text-xs px-2 py-1 rounded">ACADEMIC</span>
                            <span class="text-xs text-gray-500">98 views</span>
                        </div>
                        <h3 class="font-semibold mb-2">Term 1 Academic Performance</h3>
                        <p class="text-sm text-gray-600 mb-4">Comprehensive academic results for Term 1 2023</p>
                        <div class="flex justify-between items-center">
                            <span class="text-xs text-gray-500">Generated: 15 Nov 2023</span>
                            <button class="text-nskblue hover:text-nsknavy text-sm popular-download" data-filename="term1_academic_performance.xlsx">
                                <i class="fas fa-download mr-1"></i> Download
                            </button>
                        </div>
                    </div>
                    
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
                        <div class="flex items-center justify-between mb-3">
                            <span class="bg-amber-100 text-amber-700 text-xs px-2 py-1 rounded">FINANCIAL</span>
                            <span class="text-xs text-gray-500">64 views</span>
                        </div>
                        <h3 class="font-semibold mb-2">Quarterly Financial Summary</h3>
                        <p class="text-sm text-gray-600 mb-4">Q3 2023 revenue, expenses and financial health</p>
                        <div class="flex justify-between items-center">
                            <span class="text-xs text-gray-500">Generated: 05 Oct 2023</span>
                            <button class="text-nskblue hover:text-nsknavy text-sm popular-download" data-filename="q3_financial_summary.pdf">
                                <i class="fas fa-download mr-1"></i> Download
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Generate Report Modal -->
        <div id="generateReportModal" class="modal">
            <div class="modal-content">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-bold text-nsknavy">Generate New Report</h3>
                    <button class="close-modal text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <form id="reportForm" class="space-y-4">
                    <div>
                        <label class="block text-gray-700 mb-2" for="reportType">Report Type</label>
                        <select id="reportType" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                            <option value="">Select Report Type</option>
                            <option value="attendance">Attendance Report</option>
                            <option value="academic">Academic Performance</option>
                            <option value="financial">Financial Report</option>
                            <option value="behavioral">Behavioral Report</option>
                            <option value="demographic">Demographic Analysis</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 mb-2" for="reportPeriod">Time Period</label>
                        <select id="reportPeriod" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                            <option value="">Select Time Period</option>
                            <option value="daily">Daily</option>
                            <option value="weekly">Weekly</option>
                            <option value="monthly">Monthly</option>
                            <option value="quarterly">Quarterly</option>
                            <option value="term">Term-wise</option>
                            <option value="annual">Annual</option>
                        </select>
                    </div>
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 mb-2" for="startDate">Start Date</label>
                            <input type="date" id="startDate" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue">
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 mb-2" for="endDate">End Date</label>
                            <input type="date" id="endDate" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue">
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 mb-2" for="reportFormat">Output Format</label>
                        <select id="reportFormat" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                            <option value="">Select Format</option>
                            <option value="pdf">PDF</option>
                            <option value="excel">Excel</option>
                            <option value="csv">CSV</option>
                            <option value="html">Web Page</option>
                        </select>
                    </div>
                    
                    <div class="flex justify-end space-x-3 pt-4">
                        <button type="button" class="close-modal px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition">
                            Cancel
                        </button>
                        <button type="submit" class="px-4 py-2 bg-nskblue text-white rounded-lg font-semibold hover:bg-nsknavy transition">
                            Generate Report
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Schedule Report Modal -->
        <div id="scheduleReportModal" class="modal">
            <div class="modal-content">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-bold text-nsknavy">Schedule Report</h3>
                    <button class="close-modal text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <form id="scheduleForm" class="space-y-4">
                    <div>
                        <label class="block text-gray-700 mb-2" for="scheduledReportType">Report Type</label>
                        <select id="scheduledReportType" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                            <option value="">Select Report Type</option>
                            <option value="attendance">Attendance Report</option>
                            <option value="academic">Academic Performance</option>
                            <option value="financial">Financial Report</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 mb-2" for="scheduleFrequency">Frequency</label>
                        <select id="scheduleFrequency" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                            <option value="">Select Frequency</option>
                            <option value="daily">Daily</option>
                            <option value="weekly">Weekly</option>
                            <option value="monthly">Monthly</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 mb-2" for="recipientEmail">Recipient Email</label>
                        <input type="email" id="recipientEmail" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" placeholder="Enter email address" required>
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 mb-2" for="scheduleFormat">Output Format</label>
                        <select id="scheduleFormat" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                            <option value="">Select Format</option>
                            <option value="pdf">PDF</option>
                            <option value="excel">Excel</option>
                            <option value="csv">CSV</option>
                        </select>
                    </div>
                    
                    <div class="flex items-center">
                        <input type="checkbox" id="activeSchedule" class="mr-2" checked>
                        <label for="activeSchedule" class="text-gray-700">Active Schedule</label>
                    </div>
                    
                    <div class="flex justify-end space-x-3 pt-4">
                        <button type="button" class="close-modal px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition">
                            Cancel
                        </button>
                        <button type="submit" class="px-4 py-2 bg-nskblue text-white rounded-lg font-semibold hover:bg-nsknavy transition">
                            Schedule Report
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Include footer -->
        <script src="footer.js"></script>
    </main>

    <script>
        // Initialize page functionality when DOM is loaded
        document.addEventListener('DOMContentLoaded', function() {
            initializeReportsPage();
        });

        function initializeReportsPage() {
            console.log('Initializing Reports page...');
            
            // Initialize all components
            initializeTabs();
            initializeModals();
            initializeTableActions();
            initializeButtons();
            initializeCharts();
            initializeSearch();
            initializeNotifications();
        }

        function initializeTabs() {
            // Tab functionality
            document.querySelectorAll('.tab-button').forEach(button => {
                button.addEventListener('click', function() {
                    // Update tab buttons
                    document.querySelectorAll('.tab-button').forEach(btn => {
                        btn.classList.remove('active', 'bg-nskblue', 'text-white');
                        btn.classList.add('border-gray-300', 'text-gray-700');
                    });
                    
                    this.classList.add('active', 'bg-nskblue', 'text-white');
                    this.classList.remove('border-gray-300', 'text-gray-700');
                    
                    // Show selected tab content
                    const tabName = this.getAttribute('data-tab');
                    document.querySelectorAll('.tab-content').forEach(tab => {
                        tab.classList.remove('active');
                        tab.classList.add('hidden');
                    });
                    
                    const targetTab = document.getElementById(`${tabName}Tab`);
                    if (targetTab) {
                        targetTab.classList.add('active');
                        targetTab.classList.remove('hidden');
                    }
                });
            });
        }

        function initializeModals() {
            const modals = {
                generateReportModal: document.getElementById('generateReportModal'),
                scheduleReportModal: document.getElementById('scheduleReportModal')
            };

            const generateReportBtn = document.getElementById('generateReportBtn');
            const scheduleReportBtn = document.getElementById('scheduleReportBtn');
            const closeModalButtons = document.querySelectorAll('.close-modal');

            // Modal open function
            function openModal(modalId) {
                const modal = modals[modalId];
                if (modal) {
                    closeAllModals();
                    modal.style.display = 'flex';
                    setTimeout(() => {
                        modal.classList.add('active');
                    }, 10);
                }
            }

            function closeAllModals() {
                Object.values(modals).forEach(modal => {
                    if (modal) {
                        modal.classList.remove('active');
                        setTimeout(() => {
                            modal.style.display = 'none';
                        }, 300);
                    }
                });
            }

            // Event listeners for modal buttons
            if (generateReportBtn) {
                generateReportBtn.addEventListener('click', () => openModal('generateReportModal'));
            }
            
            if (scheduleReportBtn) {
                scheduleReportBtn.addEventListener('click', () => openModal('scheduleReportModal'));
            }

            // Close modal functions
            closeModalButtons.forEach(button => {
                button.addEventListener('click', closeAllModals);
            });

            // Close modal when clicking outside
            Object.values(modals).forEach(modal => {
                if (modal) {
                    modal.addEventListener('click', function(e) {
                        if (e.target === this) {
                            closeAllModals();
                        }
                    });
                }
            });

            // Close modals with Escape key
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    closeAllModals();
                }
            });

            // Form submissions
            const reportForm = document.getElementById('reportForm');
            if (reportForm) {
                reportForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    handleFormSubmission(this, 'Generating report...', 'Report generated successfully!');
                });
            }

            const scheduleForm = document.getElementById('scheduleForm');
            if (scheduleForm) {
                scheduleForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    handleFormSubmission(this, 'Scheduling report...', 'Report scheduled successfully!');
                });
            }
        }

        function handleFormSubmission(form, loadingText, successMessage) {
            const submitBtn = form.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            
            submitBtn.innerHTML = `<i class="fas fa-spinner fa-spin mr-2"></i> ${loadingText}`;
            submitBtn.disabled = true;
            
            setTimeout(() => {
                showNotification(successMessage, 'success');
                form.reset();
                submitBtn.innerHTML = originalText;
                submitBtn.disabled = false;
                closeAllModals();
            }, 1500);
        }

        function initializeTableActions() {
            // View report buttons
            document.querySelectorAll('.view-report').forEach(button => {
                button.addEventListener('click', function() {
                    const reportName = this.closest('tr').querySelector('.font-semibold').textContent;
                    showNotification(`Viewing report: ${reportName}`, 'info');
                });
            });

            // Download report buttons
            document.querySelectorAll('.download-report').forEach(button => {
                button.addEventListener('click', function() {
                    const reportName = this.closest('tr').querySelector('.font-semibold').textContent;
                    const filename = this.getAttribute('data-filename') || 'report.pdf';
                    downloadFile(reportName, filename, this);
                });
            });

            // Delete report buttons
            document.querySelectorAll('.delete-report').forEach(button => {
                button.addEventListener('click', function() {
                    const reportName = this.closest('tr').querySelector('.font-semibold').textContent;
                    if (confirm(`Are you sure you want to delete "${reportName}"?`)) {
                        const row = this.closest('tr');
                        row.style.opacity = '0';
                        setTimeout(() => {
                            row.remove();
                            showNotification(`"${reportName}" deleted successfully!`, 'success');
                        }, 500);
                    }
                });
            });
        }

        function initializeButtons() {
            // Filter button
            const filterBtn = document.getElementById('filterBtn');
            if (filterBtn) {
                filterBtn.addEventListener('click', function() {
                    const originalHTML = this.innerHTML;
                    this.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Filtering...';
                    this.disabled = true;
                    
                    setTimeout(() => {
                        this.innerHTML = originalHTML;
                        this.disabled = false;
                        showNotification('Filters applied successfully!', 'success');
                    }, 1000);
                });
            }

            // Popular report download buttons
            document.querySelectorAll('.popular-download').forEach(button => {
                button.addEventListener('click', function() {
                    const reportName = this.closest('.border-gray-200').querySelector('h3').textContent;
                    const filename = this.getAttribute('data-filename') || 'report.pdf';
                    downloadFile(reportName, filename, this);
                });
            });
        }

        function downloadFile(reportName, filename, button) {
            const originalHTML = button.innerHTML;
            
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            button.disabled = true;
            
            setTimeout(() => {
                // Create and trigger download
                const blob = new Blob([`Sample report content for ${reportName}`], { type: 'application/octet-stream' });
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = filename;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
                
                showNotification(`Downloading: ${reportName}`, 'success');
                button.innerHTML = originalHTML;
                button.disabled = false;
            }, 1000);
        }

        function initializeCharts() {
            // Report Trends Chart
            const reportTrendsCtx = document.getElementById('reportTrendsChart');
            if (reportTrendsCtx) {
                new Chart(reportTrendsCtx, {
                    type: 'line',
                    data: {
                        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov'],
                        datasets: [{
                            label: 'Reports Generated',
                            data: [12, 19, 15, 17, 14, 16, 18, 20, 22, 19, 24],
                            backgroundColor: 'rgba(59, 130, 246, 0.2)',
                            borderColor: 'rgb(59, 130, 246)',
                            borderWidth: 2,
                            tension: 0.3,
                            fill: true
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Number of Reports'
                                }
                            }
                        }
                    }
                });
            }

            // Report Types Chart
            const reportTypesCtx = document.getElementById('reportTypesChart');
            if (reportTypesCtx) {
                new Chart(reportTypesCtx, {
                    type: 'doughnut',
                    data: {
                        labels: ['Attendance', 'Academic', 'Financial', 'Other'],
                        datasets: [{
                            data: [45, 30, 15, 10],
                            backgroundColor: [
                                'rgba(59, 130, 246, 0.8)',
                                'rgba(16, 185, 129, 0.8)',
                                'rgba(245, 158, 11, 0.8)',
                                'rgba(156, 163, 175, 0.8)'
                            ],
                            borderColor: [
                                'rgb(59, 130, 246)',
                                'rgb(16, 185, 129)',
                                'rgb(245, 158, 11)',
                                'rgb(156, 163, 175)'
                            ],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom',
                            }
                        }
                    }
                });
            }
        }

        function initializeSearch() {
            const searchInput = document.querySelector('input[placeholder*="Search reports"]');
            if (searchInput) {
                searchInput.addEventListener('input', function(e) {
                    const searchTerm = e.target.value.toLowerCase();
                    if (searchTerm.length > 2) {
                        showNotification(`Searching for: ${searchTerm}`, 'info');
                    }
                });
            }
        }

        function initializeNotifications() {
            const notificationBell = document.querySelector('.fa-bell');
            if (notificationBell) {
                const notificationParent = notificationBell.closest('.relative');
                if (notificationParent) {
                    notificationParent.addEventListener('click', function() {
                        showNotification('You have 3 new notifications', 'info');
                    });
                }
            }

            // Simulate live notifications
            setInterval(() => {
                const notifications = document.querySelectorAll('.notification-dot');
                notifications.forEach(dot => {
                    dot.style.display = Math.random() > 0.3 ? 'block' : 'none';
                });
            }, 5000);
        }

        function showNotification(message, type = 'info') {
            // Remove existing notification
            const existingNotification = document.querySelector('.custom-notification');
            if (existingNotification) {
                existingNotification.remove();
            }
            
            const notification = document.createElement('div');
            notification.className = `custom-notification fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 transform transition-transform duration-300 ${
                type === 'success' ? 'bg-green-500 text-white' :
                type === 'error' ? 'bg-red-500 text-white' :
                type === 'warning' ? 'bg-yellow-500 text-white' :
                'bg-blue-500 text-white'
            }`;
            
            notification.innerHTML = `
                <div class="flex items-center">
                    <i class="fas ${
                        type === 'success' ? 'fa-check-circle' :
                        type === 'error' ? 'fa-exclamation-circle' :
                        type === 'warning' ? 'fa-exclamation-triangle' :
                        'fa-info-circle'
                    } mr-2"></i>
                    <span>${message}</span>
                </div>
            `;
            
            document.body.appendChild(notification);
            
            // Animate in
            setTimeout(() => {
                notification.style.transform = 'translateX(0)';
            }, 10);
            
            // Auto remove after 3 seconds
            setTimeout(() => {
                notification.style.transform = 'translateX(100%)';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            }, 3000);
        }

        // Add CSS for notifications
        const style = document.createElement('style');
        style.textContent = `
            .custom-notification {
                transform: translateX(100%);
            }
            .tab-content {
                display: none;
            }
            .tab-content.active {
                display: block;
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>