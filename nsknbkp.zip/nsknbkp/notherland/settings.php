<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Settings | Northland Schools Kano</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            nskblue: "#1e40af",
            nsklightblue: "#3b82f6",
            nsknavy: "#1e3a8a",
            nskgold: "#f59e0b",
            nsklight: "#f0f9ff",
            nskgreen: "#10b981",
            nskred: "#ef4444",
          },
        },
      },
    };
  </script>
  <style>
    @import url("https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap");

    body {
      font-family: "Montserrat", sans-serif;
      background: #f8fafc;
    }

    .logo-container {
      background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%);
    }

    .nav-item {
      position: relative;
    }

    .nav-item::after {
      content: "";
      position: absolute;
      width: 0;
      height: 2px;
      bottom: -5px;
      left: 0;
      background-color: #f59e0b;
      transition: width 0.3s ease;
    }

    .nav-item:hover::after {
      width: 100%;
    }

    .sidebar {
      transition: all 0.3s ease;
      width: 250px;
    }

    .sidebar.collapsed {
      width: 80px;
    }

    .main-content {
      transition: all 0.3s ease;
      margin-left: 250px;
      width: calc(100% - 250px);
    }

    .main-content.expanded {
      margin-left: 80px;
      width: calc(100% - 80px);
    }

    @media (max-width: 768px) {
      .sidebar {
        margin-left: -250px;
        z-index: 40;
      }

      .sidebar.mobile-show {
        margin-left: 0;
        box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
      }

      .main-content {
        margin-left: 0;
        width: 100%;
      }
    }

    .notification-dot {
      position: absolute;
      top: -5px;
      right: -5px;
      width: 12px;
      height: 12px;
      background-color: #ef4444;
      border-radius: 50%;
      animation: pulse 2s infinite;
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }

    .settings-card {
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .settings-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    }
  </style>
</head>

<body class="flex">
  <!-- Sidebar Navigation -->
   <script src="sidebar.js"></script>
 
  <!-- Main Content -->
  <main class="main-content">
    <!-- Header -->
    <header class="bg-white shadow-md p-4">
      <div class="flex items-center justify-between">
        <div class="flex items-center">
          <button class="sidebar-toggle md:hidden mr-4 text-nsknavy">
            <i class="fas fa-bars text-xl"></i>
          </button>
          <div>
            <h1 class="text-2xl font-bold text-nsknavy">System Settings</h1>
            <p class="text-gray-600">Manage your account and system preferences</p>
          </div>
        </div>
        
        <div class="flex items-center space-x-4">
          <div class="relative hidden md:block">
            <input type="text" placeholder="Search settings..." class="pl-10 pr-4 py-2 border rounded-lg focus:border-nskblue transition">
            <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
          </div>
          
          <div class="relative">
            <button class="relative p-2 text-gray-600 hover:text-nskblue transition">
              <i class="fas fa-bell text-xl"></i>
              <div class="notification-dot"></div>
            </button>
          </div>
          
          <div class="flex items-center">
            <div class="w-10 h-10 rounded-full bg-nskblue flex items-center justify-center text-white mr-3">
              <span class="font-bold">AD</span>
            </div>
            <div class="hidden md:block">
              <p class="font-semibold text-nsknavy">Admin User</p>
              <p class="text-sm text-gray-600">System Administrator</p>
            </div>
          </div>
        </div>
      </div>
    </header>

    <!-- Settings Content -->
    <div class="p-4 md:p-6">
      <!-- Profile Settings -->
      <section class="settings-card bg-white rounded-xl shadow-md p-6 mb-6">
        <div class="flex items-center mb-6">
          <div class="w-12 h-12 rounded-full bg-nskblue flex items-center justify-center text-white mr-4">
            <i class="fas fa-user text-xl"></i>
          </div>
          <div>
            <h2 class="text-xl font-bold text-nsknavy">Profile Settings</h2>
            <p class="text-gray-600">Update your personal information</p>
          </div>
        </div>
        
        <form class="space-y-4">
          <div class="grid md:grid-cols-2 gap-4">
            <div>
              <label class="block mb-2 font-medium text-nsknavy">Full Name</label>
              <input type="text" class="w-full border rounded-lg p-3 focus:border-nskblue transition" placeholder="John Doe">
            </div>
            <div>
              <label class="block mb-2 font-medium text-nsknavy">Email Address</label>
              <input type="email" class="w-full border rounded-lg p-3 focus:border-nskblue transition" placeholder="john@example.com">
            </div>
            <div>
              <label class="block mb-2 font-medium text-nsknavy">Phone Number</label>
              <input type="text" class="w-full border rounded-lg p-3 focus:border-nskblue transition" placeholder="+234 801 234 5678">
            </div>
            <div>
              <label class="block mb-2 font-medium text-nsknavy">Profile Picture</label>
              <div class="flex items-center">
                <div class="w-16 h-16 rounded-full bg-nsklightblue flex items-center justify-center text-white mr-4">
                  <i class="fas fa-user text-xl"></i>
                </div>
                <input type="file" class="w-full border rounded-lg p-2 focus:border-nskblue transition">
              </div>
            </div>
          </div>
          <button class="bg-nskblue text-white px-6 py-3 rounded-lg font-semibold hover:bg-nsknavy transition">
            <i class="fas fa-save mr-2"></i>Save Changes
          </button>
        </form>
      </section>

      <!-- Account Settings -->
      <section class="settings-card bg-white rounded-xl shadow-md p-6 mb-6">
        <div class="flex items-center mb-6">
          <div class="w-12 h-12 rounded-full bg-nskgreen flex items-center justify-center text-white mr-4">
            <i class="fas fa-lock text-xl"></i>
          </div>
          <div>
            <h2 class="text-xl font-bold text-nsknavy">Account Security</h2>
            <p class="text-gray-600">Change your password and security settings</p>
          </div>
        </div>
        
        <form class="space-y-4">
          <div class="grid md:grid-cols-3 gap-4">
            <div>
              <label class="block mb-2 font-medium text-nsknavy">Current Password</label>
              <input type="password" class="w-full border rounded-lg p-3 focus:border-nskblue transition">
            </div>
            <div>
              <label class="block mb-2 font-medium text-nsknavy">New Password</label>
              <input type="password" class="w-full border rounded-lg p-3 focus:border-nskblue transition">
            </div>
            <div>
              <label class="block mb-2 font-medium text-nsknavy">Confirm Password</label>
              <input type="password" class="w-full border rounded-lg p-3 focus:border-nskblue transition">
            </div>
          </div>
          <button class="bg-nskgreen text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-600 transition">
            <i class="fas fa-key mr-2"></i>Update Password
          </button>
        </form>
      </section>

      <!-- System Preferences -->
      <section class="settings-card bg-white rounded-xl shadow-md p-6 mb-6">
        <div class="flex items-center mb-6">
          <div class="w-12 h-12 rounded-full bg-nskgold flex items-center justify-center text-white mr-4">
            <i class="fas fa-cogs text-xl"></i>
          </div>
          <div>
            <h2 class="text-xl font-bold text-nsknavy">System Preferences</h2>
            <p class="text-gray-600">Customize your system experience</p>
          </div>
        </div>
        
        <div class="space-y-6">
          <div class="flex flex-col md:flex-row items-center justify-between gap-4 p-4 bg-nsklight rounded-lg">
            <div class="flex items-center">
              <i class="fas fa-palette text-nskblue text-xl mr-4"></i>
              <div>
                <label class="block font-medium text-nsknavy">Theme</label>
                <p class="text-sm text-gray-600">Toggle between Light and Dark mode</p>
              </div>
            </div>
            <button id="darkModeToggle" class="bg-nskblue text-white px-4 py-2 rounded-lg font-semibold hover:bg-nsknavy transition">
              <i class="fas fa-moon mr-2"></i>Toggle Theme
            </button>
          </div>
          
          <div class="p-4 bg-nsklight rounded-lg">
            <label class="block mb-2 font-medium text-nsknavy">Language</label>
            <select class="w-full border rounded-lg p-3 focus:border-nskblue transition">
              <option>English</option>
              <option>French</option>
              <option>Arabic</option>
              <option>Hausa</option>
            </select>
          </div>
          
          <div class="p-4 bg-nsklight rounded-lg">
            <label class="block mb-2 font-medium text-nsknavy">Date Format</label>
            <select class="w-full border rounded-lg p-3 focus:border-nskblue transition">
              <option>DD/MM/YYYY</option>
              <option>MM/DD/YYYY</option>
              <option>YYYY-MM-DD</option>
            </select>
          </div>
        </div>
      </section>

      <!-- Notifications -->
      <section class="settings-card bg-white rounded-xl shadow-md p-6">
        <div class="flex items-center mb-6">
          <div class="w-12 h-12 rounded-full bg-nskred flex items-center justify-center text-white mr-4">
            <i class="fas fa-bell text-xl"></i>
          </div>
          <div>
            <h2 class="text-xl font-bold text-nsknavy">Notification Settings</h2>
            <p class="text-gray-600">Manage how you receive notifications</p>
          </div>
        </div>
        
        <div class="space-y-4">
          <div class="flex items-center justify-between p-4 bg-nsklight rounded-lg">
            <div class="flex items-center">
              <i class="fas fa-envelope text-nskblue text-xl mr-4"></i>
              <div>
                <label class="block font-medium text-nsknavy">Email Notifications</label>
                <p class="text-sm text-gray-600">Receive updates via email</p>
              </div>
            </div>
            <label class="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" class="sr-only peer" checked>
              <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-nskblue"></div>
            </label>
          </div>
          
          <div class="flex items-center justify-between p-4 bg-nsklight rounded-lg">
            <div class="flex items-center">
              <i class="fas fa-sms text-nskgreen text-xl mr-4"></i>
              <div>
                <label class="block font-medium text-nsknavy">SMS Alerts</label>
                <p class="text-sm text-gray-600">Receive important alerts via SMS</p>
              </div>
            </div>
            <label class="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" class="sr-only peer">
              <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-nskgreen"></div>
            </label>
          </div>
          
          <div class="flex items-center justify-between p-4 bg-nsklight rounded-lg">
            <div class="flex items-center">
              <i class="fas fa-chart-bar text-nskgold text-xl mr-4"></i>
              <div>
                <label class="block font-medium text-nsknavy">Weekly Reports</label>
                <p class="text-sm text-gray-600">Receive weekly performance reports</p>
              </div>
            </div>
            <label class="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" class="sr-only peer" checked>
              <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-nskgold"></div>
            </label>
          </div>
        </div>
      </section>
    </div>
  </main>


   <!-- Scripts -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const currentPage = 'settings.html';
        sidebarManager.init(currentPage);
        
        // Settings page specific JavaScript
        // Dark mode toggle functionality
        const toggleTheme = document.getElementById('darkModeToggle');
        
        function toggleDarkMode() {
            document.body.classList.toggle('dark');
            localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
            
            // Update button text
            if (document.body.classList.contains('dark')) {
                toggleTheme.innerHTML = '<i class="fas fa-sun mr-2"></i>Light Mode';
            } else {
                toggleTheme.innerHTML = '<i class="fas fa-moon mr-2"></i>Dark Mode';
            }
        }

        if (toggleTheme) {
            toggleTheme.addEventListener('click', toggleDarkMode);
        }

        // Load theme from localStorage
        if (localStorage.getItem('theme') === 'dark') {
            document.body.classList.add('dark');
            if (toggleTheme) {
                toggleTheme.innerHTML = '<i class="fas fa-sun mr-2"></i>Light Mode';
            }
        }

        // Form submission handlers
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                // Show success notification
                alert('Settings saved successfully!');
            });
        });
    });
</script>
</body>
<!-- Include footer -->
<script src="footer.js"></script>
</html>

  <script>
    // Sidebar toggle functionality
    document.querySelector('.sidebar-toggle')?.addEventListener('click', function() {
      const sidebar = document.querySelector('.sidebar');
      sidebar.classList.toggle('mobile-show');
    });

    // Close sidebar when clicking on a link (mobile)
    document.querySelectorAll('.sidebar a').forEach((link) => {
      link.addEventListener('click', () => {
        if (window.innerWidth < 768) {
          document.querySelector('.sidebar').classList.remove('mobile-show');
        }
      });
    });

    // Dark mode toggle functionality
    const toggleTheme = document.getElementById('darkModeToggle');
    
    function toggleDarkMode() {
      document.body.classList.toggle('dark');
      localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
      
      // Update button text
      if (document.body.classList.contains('dark')) {
        toggleTheme.innerHTML = '<i class="fas fa-sun mr-2"></i>Light Mode';
      } else {
        toggleTheme.innerHTML = '<i class="fas fa-moon mr-2"></i>Dark Mode';
      }
    }

    toggleTheme.addEventListener('click', toggleDarkMode);

    // Load theme from localStorage
    if (localStorage.getItem('theme') === 'dark') {
      document.body.classList.add('dark');
      toggleTheme.innerHTML = '<i class="fas fa-sun mr-2"></i>Light Mode';
    }

    // Form submission handlers
    document.querySelectorAll('form').forEach(form => {
      form.addEventListener('submit', function(e) {
        e.preventDefault();
        // Show success notification
        alert('Settings saved successfully!');
      });
    });
  </script>
</body>
</html>