<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Northland Schools Kano</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        nskblue: '#1e40af',
                        nsklightblue: '#3b82f6',
                        nsknavy: '#1e3a8a',
                        nskgold: '#f59e0b',
                        nsklight: '#f0f9ff',
                        nskgreen: '#10b981',
                        nskred: '#ef4444'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap');
        
        body {
            font-family: 'Montserrat', sans-serif;
            background: #f8fafc;
        }
        
        .logo-container {
            background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%);
        }
        
        .user-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .user-card:hover {
            transform: translateY(-5px);
        }
        
        .nav-item {
            position: relative;
        }
        
        .nav-item::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: -5px;
            left: 0;
            background-color: #f59e0b;
            transition: width 0.3s ease;
        }
        
        .nav-item:hover::after {
            width: 100%;
        }
        
        .sidebar {
            transition: all 0.3s ease;
            width: 250px;
        }
        
        .sidebar.collapsed {
            width: 80px;
        }
        
        .main-content {
            transition: all 0.3s ease;
            margin-left: 250px;
            width: calc(100% - 250px);
        }
        
        .main-content.expanded {
            margin-left: 80px;
            width: calc(100% - 80px);
        }
        
        @media (max-width: 768px) {
            .sidebar {
                margin-left: -250px;
            }
            
            .sidebar.mobile-show {
                margin-left: 0;
            }
            
            .main-content {
                margin-left: 0;
                width: 100%;
            }
        }
        
        .notification-dot {
            position: absolute;
            top: -5px;
            right: -5px;
            width: 12px;
            height: 12px;
            background-color: #ef4444;
            border-radius: 50%;
        }
        
        .user-table {
            border-collapse: separate;
            border-spacing: 0;
        }
        
        .user-table th {
            background-color: #f8fafc;
        }
        
        .user-table tr:last-child td {
            border-bottom: 0;
        }
        
        .role-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-badge {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .modal {
            transition: opacity 0.3s ease, transform 0.3s ease;
            transform: scale(0.9);
            opacity: 0;
        }
        
        .modal.active {
            transform: scale(1);
            opacity: 1;
        }
    </style>
</head>
<body class="flex">
    <!-- Sidebar Navigation -->
<script src="sidebar.js"></script>
    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <header class="bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="md:hidden text-nsknavy">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold text-nsknavy">User Management</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <div class="flex items-center space-x-2 bg-nsklight rounded-full py-2 px-4">
                            <i class="fas fa-search text-gray-500"></i>
                            <input type="text" placeholder="Search users..." class="bg-transparent outline-none w-32 md:w-64">
                        </div>
                    </div>
                    
                    <div class="relative">
                        <i class="fas fa-bell text-nsknavy text-xl"></i>
                        <div class="notification-dot"></div>
                    </div>
                    
                    <div class="hidden md:flex items-center space-x-2">
                        <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center text-white font-bold">
                            A
                        </div>
                        <div>
                            <p class="text-sm font-semibold text-nsknavy">Admin User</p>
                            <p class="text-xs text-gray-600">Administrator</p>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- User Management Content -->
        <div class="p-6">
            <!-- Stats Overview -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="user-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nsklightblue p-4 rounded-full mr-4">
                        <i class="fas fa-users text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Total Users</p>
                        <p class="text-2xl font-bold text-nsknavy">1,425</p>
                        <p class="text-xs text-nskgreen"><i class="fas fa-arrow-up"></i> 12% from last month</p>
                    </div>
                </div>
                
                <div class="user-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nskgreen p-4 rounded-full mr-4">
                        <i class="fas fa-chalkboard-teacher text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Teachers</p>
                        <p class="text-2xl font-bold text-nsknavy">68</p>
                        <p class="text-xs text-gray-600">5 vacancies</p>
                    </div>
                </div>
                
                <div class="user-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nskgold p-4 rounded-full mr-4">
                        <i class="fas fa-user-graduate text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Students</p>
                        <p class="text-2xl font-bold text-nsknavy">1,245</p>
                        <p class="text-xs text-nskgreen"><i class="fas fa-arrow-up"></i> 5% from last month</p>
                    </div>
                </div>
                
                <div class="user-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nsklightblue p-4 rounded-full mr-4">
                        <i class="fas fa-user-friends text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Parents</p>
                        <p class="text-2xl font-bold text-nsknavy">112</p>
                        <p class="text-xs text-nskred">12 pending approval</p>
                    </div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="bg-white rounded-xl shadow-md p-6 mb-8">
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <h2 class="text-xl font-bold text-nsknavy">All Users</h2>
                    
                    <div class="flex flex-wrap gap-4">
                        <select class="px-4 py-2 border rounded-lg form-input focus:border-nskblue">
                            <option value="">All Roles</option>
                            <option value="admin">Administrators</option>
                            <option value="teacher">Teachers</option>
                            <option value="student">Students</option>
                            <option value="parent">Parents</option>
                        </select>
                        
                        <select class="px-4 py-2 border rounded-lg form-input focus:border-nskblue">
                            <option value="">All Status</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="pending">Pending</option>
                        </select>
                        
                        <button class="bg-nskblue text-white px-4 py-2 rounded-lg font-semibold hover:bg-nsknavy transition flex items-center">
                            <i class="fas fa-filter mr-2"></i> Filter
                        </button>
                        
                        <button id="addUserBtn" class="bg-nskgreen text-white px-4 py-2 rounded-lg font-semibold hover:bg-green-600 transition flex items-center">
                            <i class="fas fa-plus mr-2"></i> Add User
                        </button>
                    </div>
                </div>
            </div>

            <!-- Users Table -->
            <div class="bg-white rounded-xl shadow-md overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="min-w-full user-table">
                        <thead>
                            <tr>
                                <th class="py-3 px-6 text-left text-nsknavy">User</th>
                                <th class="py-3 px-6 text-left text-nsknavy">Role</th>
                                <th class="py-3 px-6 text-left text-nsknavy">Status</th>
                                <th class="py-3 px-6 text-left text-nsknavy">Last Login</th>
                                <th class="py-3 px-6 text-left text-nsknavy">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <tr>
                                <td class="py-4 px-6">
                                    <div class="flex items-center">
                                        <div class="w-10 h-10 rounded-full bg-nskblue flex items-center justify-center text-white font-bold mr-3">
                                            A
                                        </div>
                                        <div>
                                            <p class="font-semibold">Admin User</p>
                                            <p class="text-sm text-gray-600">admin@northlandschools.com</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="role-badge bg-blue-100 text-nskblue">Administrator</span>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="status-badge bg-green-100 text-nskgreen">Active</span>
                                </td>
                                <td class="py-4 px-6">
                                    <p class="text-sm">Today, 09:42 AM</p>
                                </td>
                                <td class="py-4 px-6">
                                    <div class="flex space-x-2">
                                        <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="text-nskred hover:text-red-700 p-2 rounded-full hover:bg-red-50">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                        <button class="text-nskgreen hover:text-green-700 p-2 rounded-full hover:bg-green-50">
                                            <i class="fas fa-key"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td class="py-4 px-6">
                                    <div class="flex items-center">
                                        <div class="w-10 h-10 rounded-full bg-nskgreen flex items-center justify-center text-white font-bold mr-3">
                                            T
                                        </div>
                                        <div>
                                            <p class="font-semibold">Teacher Johnson</p>
                                            <p class="text-sm text-gray-600">johnson@northlandschools.com</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="role-badge bg-green-100 text-nskgreen">Teacher</span>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="status-badge bg-green-100 text-nskgreen">Active</span>
                                </td>
                                <td class="py-4 px-6">
                                    <p class="text-sm">Yesterday, 03:15 PM</p>
                                </td>
                                <td class="py-4 px-6">
                                    <div class="flex space-x-2">
                                        <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="text-nskred hover:text-red-700 p-2 rounded-full hover:bg-red-50">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                        <button class="text-nskgreen hover:text-green-700 p-2 rounded-full hover:bg-green-50">
                                            <i class="fas fa-key"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td class="py-4 px-6">
                                    <div class="flex items-center">
                                        <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center text-white font-bold mr-3">
                                            S
                                        </div>
                                        <div>
                                            <p class="font-semibold">Student Ahmad</p>
                                            <p class="text-sm text-gray-600">ahmad@northlandschools.com</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="role-badge bg-amber-100 text-amber-700">Student</span>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="status-badge bg-green-100 text-nskgreen">Active</span>
                                </td>
                                <td class="py-4 px-6">
                                    <p class="text-sm">2 days ago</p>
                                </td>
                                <td class="py-4 px-6">
                                    <div class="flex space-x-2">
                                        <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="text-nskred hover:text-red-700 p-2 rounded-full hover:bg-red-50">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                        <button class="text-nskgreen hover:text-green-700 p-2 rounded-full hover:bg-green-50">
                                            <i class="fas fa-key"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td class="py-4 px-6">
                                    <div class="flex items-center">
                                        <div class="w-10 h-10 rounded-full bg-nsklightblue flex items-center justify-center text-white font-bold mr-3">
                                            P
                                        </div>
                                        <div>
                                            <p class="font-semibold">Parent Yusuf</p>
                                            <p class="text-sm text-gray-600">yusuf@email.com</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="role-badge bg-blue-100 text-nskblue">Parent</span>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="status-badge bg-gray-100 text-gray-700">Inactive</span>
                                </td>
                                <td class="py-4 px-6">
                                    <p class="text-sm">1 week ago</p>
                                </td>
                                <td class="py-4 px-6">
                                    <div class="flex space-x-2">
                                        <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="text-nskred hover:text-red-700 p-2 rounded-full hover:bg-red-50">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                        <button class="text-nskgreen hover:text-green-700 p-2 rounded-full hover:bg-green-50">
                                            <i class="fas fa-key"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                                <td class="py-4 px-6">
                                    <div class="flex items-center">
                                        <div class="w-10 h-10 rounded-full bg-purple-500 flex items-center justify-center text-white font-bold mr-3">
                                            R
                                        </div>
                                        <div>
                                            <p class="font-semibold">Receptionist Amina</p>
                                            <p class="text-sm text-gray-600">amina@northlandschools.com</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="role-badge bg-purple-100 text-purple-700">Staff</span>
                                </td>
                                <td class="py-4 px-6">
                                    <span class="status-badge bg-green-100 text-nskgreen">Active</span>
                                </td>
                                <td class="py-4 px-6">
                                    <p class="text-sm">Today, 08:30 AM</p>
                                </td>
                                <td class="py-4 px-6">
                                    <div class="flex space-x-2">
                                        <button class="text-nskblue hover:text-nsknavy p-2 rounded-full hover:bg-blue-50">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="text-nskred hover:text-red-700 p-2 rounded-full hover:bg-red-50">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                        <button class="text-nskgreen hover:text-green-700 p-2 rounded-full hover:bg-green-50">
                                            <i class="fas fa-key"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <div class="flex items-center justify-between border-t border-gray-200 px-6 py-4">
                    <div>
                        <p class="text-sm text-gray-700">
                            Showing <span class="font-medium">1</span> to <span class="font-medium">5</span> of <span class="font-medium">124</span> results
                        </p>
                    </div>
                    <div class="flex space-x-2">
                        <button class="px-3 py-1 rounded border text-sm font-medium text-gray-700 hover:bg-gray-50">
                            Previous
                        </button>
                        <button class="px-3 py-1 rounded border border-nskblue bg-nskblue text-white text-sm font-medium">
                            1
                        </button>
                        <button class="px-3 py-1 rounded border text-sm font-medium text-gray-700 hover:bg-gray-50">
                            2
                        </button>
                        <button class="px-3 py-1 rounded border text-sm font-medium text-gray-700 hover:bg-gray-50">
                            3
                        </button>
                        <button class="px-3 py-1 rounded border text-sm font-medium text-gray-700 hover:bg-gray-50">
                            Next
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add User Modal -->
        <div id="addUserModal" class="modal fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div class="bg-white rounded-xl shadow-2xl max-w-md w-full p-6">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-bold text-nsknavy">Add New User</h3>
                    <button id="closeModal" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <form id="userForm" class="space-y-4">
                    <div>
                        <label class="block text-gray-700 mb-2" for="name">Full Name</label>
                        <input type="text" id="name" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 mb-2" for="email">Email Address</label>
                        <input type="email" id="email" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 mb-2" for="role">User Role</label>
                        <select id="role" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                            <option value="">Select Role</option>
                            <option value="admin">Administrator</option>
                            <option value="teacher">Teacher</option>
                            <option value="student">Student</option>
                            <option value="parent">Parent</option>
                            <option value="staff">Staff</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-gray-700 mb-2" for="status">Status</label>
                        <select id="status" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="pending">Pending</option>
                        </select>
                    </div>
                    
                    <div class="flex justify-end space-x-3 pt-4">
                        <button type="button" id="cancelBtn" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition">
                            Cancel
                        </button>
                        <button type="submit" class="px-4 py-2 bg-nskblue text-white rounded-lg font-semibold hover:bg-nsknavy transition">
                            Add User
                        </button>
                    </div>
                </form>
            </div>
        </div>

 <!-- Include footer -->
<script src="footer.js"></script>
    </main>

    <script>
        // Sidebar toggle functionality
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('collapsed');
            document.querySelector('.main-content').classList.toggle('expanded');
            document.querySelectorAll('.sidebar-text').forEach(el => {
                el.classList.toggle('hidden');
            });
        });

        // Mobile menu toggle
        document.getElementById('mobileMenuToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('mobile-show');
        });

        // Modal functionality
        const modal = document.getElementById('addUserModal');
        const addUserBtn = document.getElementById('addUserBtn');
        const closeModal = document.getElementById('closeModal');
        const cancelBtn = document.getElementById('cancelBtn');
        const userForm = document.getElementById('userForm');

        addUserBtn.addEventListener('click', function() {
            modal.classList.add('active');
        });

        function closeModalFunc() {
            modal.classList.remove('active');
        }

        closeModal.addEventListener('click', closeModalFunc);
        cancelBtn.addEventListener('click', closeModalFunc);

        // Close modal when clicking outside
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModalFunc();
            }
        });

        // Form submission
        userForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const role = document.getElementById('role').value;
            const status = document.getElementById('status').value;
            
            // Simulate adding a user
            alert(`User ${name} (${email}) added as ${role} with ${status} status`);
            closeModalFunc();
            userForm.reset();
        });

        // Table row actions
        document.querySelectorAll('.user-table button').forEach(button => {
            button.addEventListener('click', function() {
                const row = this.closest('tr');
                const userName = row.querySelector('.font-semibold').textContent;
                
                if (this.innerHTML.includes('fa-trash')) {
                    if (confirm(`Are you sure you want to delete ${userName}?`)) {
                        row.style.opacity = '0';
                        setTimeout(() => {
                            row.remove();
                        }, 500);
                    }
                } else if (this.innerHTML.includes('fa-edit')) {
                    alert(`Edit user: ${userName}`);
                } else if (this.innerHTML.includes('fa-key')) {
                    alert(`Reset password for: ${userName}`);
                }
            });
        });
    </script>
</body>
</html>