<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Timetable Management - Northland Schools Kano</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        nskblue: '#1e40af',
                        nsklightblue: '#3b82f6',
                        nsknavy: '#1e3a8a',
                        nskgold: '#f59e0b',
                        nsklight: '#f0f9ff',
                        nskgreen: '#10b981',
                        nskred: '#ef4444'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap');
        
        body {
            font-family: 'Montserrat', sans-serif;
            background: #f8fafc;
        }
        
        .logo-container {
            background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%);
        }
        
        .timetable-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .timetable-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        
        .nav-item {
            position: relative;
        }
        
        .nav-item::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: -5px;
            left: 0;
            background-color: #f59e0b;
            transition: width 0.3s ease;
        }
        
        .nav-item:hover::after {
            width: 100%;
        }
        
        .sidebar {
            transition: all 0.3s ease;
            width: 250px;
        }
        
        .sidebar.collapsed {
            width: 80px;
        }
        
        .main-content {
            transition: all 0.3s ease;
            margin-left: 250px;
            width: calc(100% - 250px);
        }
        
        .main-content.expanded {
            margin-left: 80px;
            width: calc(100% - 80px);
        }
        
        @media (max-width: 768px) {
            .sidebar {
                margin-left: -250px;
            }
            
            .sidebar.mobile-show {
                margin-left: 0;
            }
            
            .main-content {
                margin-left: 0;
                width: 100%;
            }
        }
        
        .notification-dot {
            position: absolute;
            top: -5px;
            right: -5px;
            width: 12px;
            height: 12px;
            background-color: #ef4444;
            border-radius: 50%;
        }
        
        .timetable-cell {
            transition: all 0.2s ease;
            cursor: pointer;
        }
        
        .timetable-cell:hover {
            transform: scale(1.02);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .subject-music { background-color: #f0abfc; border-left: 4px solid #c026d3; }
        .subject-break { background-color: #fef3c7; border-left: 4px solid #f59e0b; }
        .subject-sensory { background-color: #d1fae5; border-left: 4px solid #10b981; }
        .subject-story { background-color: #e0e7ff; border-left: 4px solid #4f46e5; }
        .subject-math { background-color: #bfdbfe; border-left: 4px solid #3b82f6; }
        .subject-science { background-color: #bbf7d0; border-left: 4px solid #10b981; }
        .subject-english { background-color: #fde68a; border-left: 4px solid #f59e0b; }
        .subject-history { background-color: #e9d5ff; border-left: 4px solid #8b5cf6; }
        .subject-art { background-color: #fecaca; border-left: 4px solid #ef4444; }
        .subject-pe { background-color: #c7d2fe; border-left: 4px solid #6366f1; }
        .subject-religious { background-color: #ddd6fe; border-left: 4px solid #7c3aed; }
        .subject-computer { background-color: #a7f3d0; border-left: 4px solid #059669; }
        
        .modal {
            transition: opacity 0.3s ease, transform 0.3s ease;
            transform: scale(0.9);
            opacity: 0;
            pointer-events: none;
        }
        
        .modal.active {
            transform: scale(1);
            opacity: 1;
            pointer-events: all;
        }
        
        .tab-button {
            transition: all 0.3s ease;
        }
        
        .tab-button.active {
            background-color: #1e40af;
            color: white;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .fade-in {
            animation: fadeIn 0.5s ease;
        }
        
        .hidden {
            display: none;
        }
        
        .template-card {
            transition: all 0.3s ease;
        }
        
        .template-card:hover {
            border-color: #1e40af;
            transform: translateY(-2px);
        }
        
        .floating-action-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 100;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        
        .quick-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .filter-section {
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            border-radius: 12px;
        }
        
        .export-btn {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
        }
        
        .export-btn:hover {
            background: linear-gradient(135deg, #059669 0%, #047857 100%);
        }
    </style>
</head>
<body class="flex">
    <!-- Sidebar Navigation -->
<script src="sidebar.js"></script>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <header class="bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="md:hidden text-nsknavy">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold text-nsknavy">Timetable Management</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <div class="flex items-center space-x-2 bg-nsklight rounded-full py-2 px-4">
                            <i class="fas fa-search text-gray-500"></i>
                            <input type="text" placeholder="Search timetable..." class="bg-transparent outline-none w-32 md:w-64">
                        </div>
                    </div>
                    
                    <div class="relative">
                        <i class="fas fa-bell text-nsknavy text-xl"></i>
                        <div class="notification-dot"></div>
                    </div>
                    
                    <div class="hidden md:flex items-center space-x-2">
                        <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center text-white font-bold">
                            A
                        </div>
                        <div>
                            <p class="text-sm font-semibold text-nsknavy">Admin User</p>
                            <p class="text-xs text-gray-600">Administrator</p>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Timetable Management Content -->
        <div class="p-6">
            <!-- Stats Overview -->
            <div class="quick-stats mb-8">
                <div class="timetable-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nsklightblue p-4 rounded-full mr-4">
                        <i class="fas fa-calendar-day text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Active Schedules</p>
                        <p class="text-2xl font-bold text-nsknavy">24</p>
                        <p class="text-xs text-nskgreen">Current term</p>
                    </div>
                </div>
                
                <div class="timetable-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nskgreen p-4 rounded-full mr-4">
                        <i class="fas fa-clock text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Periods per Day</p>
                        <p class="text-2xl font-bold text-nsknavy">8</p>
                        <p class="text-xs text-gray-600">45 minutes each</p>
                    </div>
                </div>
                
                <div class="timetable-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nskgold p-4 rounded-full mr-4">
                        <i class="fas fa-chalkboard text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Classrooms</p>
                        <p class="text-2xl font-bold text-nsknavy">32</p>
                        <p class="text-xs text-nskgreen">All occupied</p>
                    </div>
                </div>
                
                <!-- <div class="timetable-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nskred p-4 rounded-full mr-4">
                        <i class="fas fa-exclamation-circle text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Conflicts</p>
                        <p class="text-2xl font-bold text-nsknavy">3</p>
                        <p class="text-xs text-nskred">Needs resolution</p>
                    </div>
                </div> -->
            </div>

            <!-- Class Level Selection -->
            <div class="filter-section p-6 mb-8">
                <div class="mb-6">
                    <div class="flex flex-wrap gap-2 mb-4">
                        <button class="level-btn px-4 py-2 rounded-lg border border-nskblue text-nskblue" data-level="early-childhood">
                            Early Childhood
                        </button>
                        <button class="level-btn active px-4 py-2 rounded-lg bg-nskblue text-white" data-level="primary">
                            Primary School
                        </button>
                        <button class="level-btn px-4 py-2 rounded-lg border border-nskblue text-nskblue" data-level="secondary">
                            Secondary School
                        </button>
                    </div>
                    
                    <!-- Early Childhood Classes -->
                    <div id="earlyChildhoodClasses" class="class-selection hidden">
                        <select class="class-selector px-4 py-2 border rounded-lg w-full md:w-64">
                            <option value="">Select Early Childhood Class</option>
                            <option value="garden">Garden (Age 2-3)</option>
                            <option value="pre-nursery">Pre-Nursery (Age 3-4)</option>
                            <option value="nursery">Nursery (Age 4-5)</option>
                            <option value="kg1">KG 1</option>
                            <option value="kg2">KG 2</option>
                        </select>
                    </div>
                    
                    <!-- Primary Classes -->
                    <div id="primaryClasses" class="class-selection">
                        <select class="class-selector px-4 py-2 border rounded-lg w-full md:w-64">
                            <option value="">Select Primary Class</option>
                            <option value="p1">Primary 1</option>
                            <option value="p2">Primary 2</option>
                            <option value="p3">Primary 3</option>
                            <option value="p4">Primary 4</option>
                            <option value="p5">Primary 5</option>
                            <option value="p6">Primary 6</option>
                        </select>
                    </div>
                    
                    <!-- Secondary Classes -->
                    <div id="secondaryClasses" class="class-selection hidden">
                        <select class="class-selector px-4 py-2 border rounded-lg w-full md:w-64">
                            <option value="">Select Secondary Class</option>
                            <option value="jss1">JSS 1</option>
                            <option value="jss2">JSS 2</option>
                            <option value="jss3">JSS 3</option>
                            <option value="ss1">SS 1</option>
                            <option value="ss2">SS 2</option>
                            <option value="ss3">SS 3</option>
                        </select>
                    </div>
                </div>

                <!-- View Options -->
                <div class="view-options flex flex-wrap gap-2 mb-4">
                    <button class="view-btn active px-4 py-2 rounded-lg bg-nskblue text-white" data-view="weekly">
                        Weekly View
                    </button>
                    <button class="view-btn px-4 py-2 rounded-lg border border-nskblue text-nskblue" data-view="daily">
                        Daily View
                    </button>
                    <!-- <button class="view-btn px-4 py-2 rounded-lg border border-nskblue text-nskblue" data-view="teacher">
                        Teacher View
                    </button> -->
                </div>

                <!-- Export Options -->
                <div class="export-options flex flex-wrap gap-2 mb-4">
                    <button class="export-btn px-4 py-2 rounded-lg text-white">
                        <i class="fas fa-download mr-2"></i>Export PDF
                    </button>
                    <button class="px-4 py-2 rounded-lg border border-nskblue text-nskblue">
                        <i class="fas fa-print mr-2"></i>Print
                    </button>
                    <button class="px-4 py-2 rounded-lg border border-nskgold text-nskgold">
                        <i class="fas fa-file-excel mr-2"></i>Export Excel
                    </button>
                </div>
            </div>

            <!-- Conflict Alert -->
            <div id="conflictAlert" class="hidden bg-nskred bg-opacity-10 border border-nskred rounded-lg p-4 mb-8">
                <div class="flex items-center">
                    <i class="fas fa-exclamation-triangle text-nskred mr-3"></i>
                    <div>
                        <p class="font-semibold text-nskred">Schedule Conflicts Detected</p>
                        <p class="text-sm" id="conflictDetails">Teacher conflict: Mr. Johnson scheduled in two classes at the same time.</p>
                    </div>
                    <button class="ml-auto bg-nskred text-white px-3 py-1 rounded text-sm">
                        Resolve Conflicts
                    </button>
                </div>
            </div>

            <!-- Bulk Operations -->
            <div class="bulk-operations bg-white rounded-xl shadow-md p-6 mb-8">
                <h3 class="text-lg font-semibold text-nsknavy mb-4">Bulk Operations</h3>
                <div class="flex flex-wrap gap-4">
                    <button class="bulk-btn px-4 py-2 rounded-lg border border-nskblue text-nskblue">
                        <i class="fas fa-copy mr-2"></i>Copy to Other Classes
                    </button>
                    <button class="bulk-btn px-4 py-2 rounded-lg border border-nskgreen text-nskgreen">
                        <i class="fas fa-sync-alt mr-2"></i>Apply Template
                    </button>
                    <button class="bulk-btn px-4 py-2 rounded-lg border border-nskred text-nskred">
                        <i class="fas fa-trash-alt mr-2"></i>Clear Schedule
                    </button>
                </div>
            </div>

            <!-- Template Management -->
            <div class="template-management bg-white rounded-xl shadow-md p-6 mb-8">
                <h3 class="text-lg font-semibold text-nsknavy mb-4">Timetable Templates</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div class="template-card border rounded-lg p-4 cursor-pointer hover:border-nskblue">
                        <h4 class="font-semibold">Primary School Template</h4>
                        <p class="text-sm text-gray-600">8 periods, 45 mins each</p>
                    </div>
                    <div class="template-card border rounded-lg p-4 cursor-pointer hover:border-nskblue">
                        <h4 class="font-semibold">Secondary School Template</h4>
                        <p class="text-sm text-gray-600">8 periods, 45 mins each</p>
                    </div>
                    <div class="template-card border rounded-lg p-4 cursor-pointer hover:border-nskblue">
                        <h4 class="font-semibold">Custom Template</h4>
                        <p class="text-sm text-gray-600">Create your own</p>
                    </div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="bg-white rounded-xl shadow-md p-6 mb-8">
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <h2 class="text-xl font-bold text-nsknavy">Class Timetables</h2>
                    
                    <div class="flex flex-wrap gap-4">
                        <button id="generateTimetableBtn" class="bg-nskgreen text-white px-4 py-2 rounded-lg font-semibold hover:bg-green-600 transition flex items-center">
                            <i class="fas fa-magic mr-2"></i> Auto-Generate
                        </button>
                        
                        <button id="addScheduleBtn" class="bg-nskgold text-white px-4 py-2 rounded-lg font-semibold hover:bg-amber-600 transition flex items-center">
                            <i class="fas fa-plus mr-2"></i> Add Schedule
                        </button>
                    </div>
                </div>
            </div>

            <!-- Timetable Display Area -->
            <div id="timetableDisplay" class="bg-white rounded-xl shadow-md p-6 mb-8">
                <div class="text-center py-8 text-gray-500">
                    <i class="fas fa-calendar-alt text-4xl mb-4"></i>
                    <p>Select a class to view the timetable</p>
                </div>
            </div>

            <!-- Upcoming Exams -->
            <div class="bg-white rounded-xl shadow-md p-6">
                <h2 class="text-xl font-bold text-nsknavy mb-6">Upcoming Examinations</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div class="border-l-4 border-nskblue pl-4 py-2">
                        <p class="font-semibold">Mid-Term Examinations</p>
                        <p class="text-sm text-gray-600">15th - 19th November 2023</p>
                        <p class="text-xs text-nskblue">2 weeks remaining</p>
                    </div>
                    
                    <div class="border-l-4 border-nskgreen pl-4 py-2">
                        <p class="font-semibold">Mathematics Quiz</p>
                        <p class="text-sm text-gray-600">22nd November 2023</p>
                        <p class="text-xs text-nskgreen">Grade 10 Only</p>
                    </div>
                    
                    <div class="border-l-4 border-nskgold pl-4 py-2">
                        <p class="font-semibold">Science Practical</p>
                        <p class="text-sm text-gray-600">25th November 2023</p>
                        <p class="text-xs text-nskgold">Physics & Chemistry</p>
                    </div>
                </div>
                
                <div class="mt-6">
                    <button class="bg-nsklightblue text-white px-4 py-2 rounded-lg font-semibold hover:bg-nskblue transition flex items-center">
                        <i class="fas fa-plus mr-2"></i> Schedule New Exam
                    </button>
                </div>
            </div>
        </div>

        <!-- Add Schedule Modal -->
        <div id="addScheduleModal" class="modal fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div class="bg-white rounded-xl shadow-2xl max-w-2xl w-full p-6">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-bold text-nsknavy">Add New Schedule</h3>
                    <button id="closeModal" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <form id="scheduleForm" class="space-y-4">
                    <!-- Class Level Selection -->
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 mb-2" for="level">School Level</label>
                            <select id="level" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                                <option value="">Select Level</option>
                                <option value="primary">Primary School</option>
                                <option value="secondary">Secondary School</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 mb-2" for="class">Class</label>
                            <select id="class" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                                <option value="">Select Class</option>
                                <!-- Options will be populated dynamically based on level -->
                            </select>
                        </div>
                    </div>
                    
                    <!-- Subject and Teacher -->
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 mb-2" for="subject">Subject</label>
                            <select id="subject" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                                <option value="">Select Subject</option>
                                <!-- Options will be populated dynamically -->
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 mb-2" for="teacher">Teacher</label>
                            <select id="teacher" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                                <option value="">Select Teacher</option>
                                <!-- Options will be populated dynamically -->
                            </select>
                        </div>
                    </div>
                    
                    <!-- Schedule Details -->
                    <div class="grid grid-cols-3 gap-4">
                        <div>
                            <label class="block text-gray-700 mb-2" for="day">Day</label>
                            <select id="day" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                                <option value="">Select Day</option>
                                <option value="monday">Monday</option>
                                <option value="tuesday">Tuesday</option>
                                <option value="wednesday">Wednesday</option>
                                <option value="thursday">Thursday</option>
                                <option value="friday">Friday</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 mb-2" for="startTime">Start Time</label>
                            <input type="time" id="startTime" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 mb-2" for="endTime">End Time</label>
                            <input type="time" id="endTime" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                        </div>
                    </div>
                    
                    <!-- Additional Options -->
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 mb-2" for="classroom">Classroom</label>
                            <select id="classroom" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue" required>
                                <option value="">Select Classroom</option>
                                <!-- Options will be populated dynamically -->
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 mb-2" for="recurring">Recurring</label>
                            <select id="recurring" class="w-full px-4 py-2 border rounded-lg form-input focus:border-nskblue">
                                <option value="weekly">Weekly</option>
                                <option value="biweekly">Bi-weekly</option>
                                <option value="monthly">Monthly</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-3 pt-4">
                        <button type="button" id="cancelBtn" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition">
                            Cancel
                        </button>
                        <button type="submit" class="px-4 py-2 bg-nskblue text-white rounded-lg font-semibold hover:bg-nsknavy transition">
                            Add Schedule
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Floating Action Button -->
        <button class="floating-action-btn w-14 h-14 bg-nskblue text-white rounded-full flex items-center justify-center shadow-lg hover:bg-nsknavy transition">
            <i class="fas fa-plus text-xl"></i>
        </button>

<!-- Include footer -->
<script src="footer.js"></script>
    </main>

    <script>
        // Enhanced Timetable Manager
        class TimetableManager {
            constructor() {
                this.currentLevel = 'primary';
                this.currentClass = '';
                this.currentView = 'weekly';
                this.init();
            }

            init() {
                this.setupEventListeners();
                this.loadInitialData();
                this.populateModalOptions();
            }

            setupEventListeners() {
                // Level switching
                document.querySelectorAll('.level-btn').forEach(btn => {
                    btn.addEventListener('click', (e) => {
                        this.switchLevel(e.target.dataset.level);
                    });
                });

                // Class selection
                document.querySelectorAll('.class-selector').forEach(select => {
                    select.addEventListener('change', (e) => {
                        this.currentClass = e.target.value;
                        this.loadTimetable(e.target.value);
                    });
                });

                // View switching
                document.querySelectorAll('.view-btn').forEach(btn => {
                    btn.addEventListener('click', (e) => {
                        this.switchView(e.target.dataset.view);
                    });
                });

                // Modal level change
                document.getElementById('level').addEventListener('change', (e) => {
                    this.updateModalClasses(e.target.value);
                    this.updateModalSubjects(e.target.value);
                });
            }

            switchLevel(level) {
                this.currentLevel = level;
                
                // Update UI
                document.querySelectorAll('.level-btn').forEach(btn => {
                    btn.classList.remove('active', 'bg-nskblue', 'text-white');
                    btn.classList.add('border', 'border-nskblue', 'text-nskblue');
                });
                
                event.target.classList.add('active', 'bg-nskblue', 'text-white');
                event.target.classList.remove('border', 'border-nskblue', 'text-nskblue');

                // Show/hide class selections
                document.getElementById('earlyChildhoodClasses').classList.toggle('hidden', level !== 'early-childhood');
                document.getElementById('primaryClasses').classList.toggle('hidden', level !== 'primary');
                document.getElementById('secondaryClasses').classList.toggle('hidden', level !== 'secondary');

                // Reset class selection
                this.currentClass = '';
                this.showTimetablePlaceholder();
            }

            switchView(view) {
                this.currentView = view;
                
                // Update UI
                document.querySelectorAll('.view-btn').forEach(btn => {
                    btn.classList.remove('active', 'bg-nskblue', 'text-white');
                    btn.classList.add('border', 'border-nskblue', 'text-nskblue');
                });
                
                event.target.classList.add('active', 'bg-nskblue', 'text-white');
                event.target.classList.remove('border', 'border-nskblue', 'text-nskblue');

                // Reload timetable with new view
                if (this.currentClass) {
                    this.loadTimetable(this.currentClass);
                }
            }

            showTimetablePlaceholder() {
                document.getElementById('timetableDisplay').innerHTML = `
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-calendar-alt text-4xl mb-4"></i>
                        <p>Select a class to view the timetable</p>
                    </div>
                `;
            }

            showLoadingState() {
                document.getElementById('timetableDisplay').innerHTML = `
                    <div class="text-center py-8">
                        <div class="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-nskblue"></div>
                        <p class="mt-4 text-gray-600">Loading timetable...</p>
                    </div>
                `;
            }

            loadTimetable(className) {
                this.currentClass = className;
                
                // Show loading
                this.showLoadingState();
                
                // Simulate API call
                setTimeout(() => {
                    let timetableData;
                    
                    switch(this.currentLevel) {
                        case 'early-childhood':
                            timetableData = this.getEarlyChildhoodTimetable();
                            break;
                        case 'primary':
                            timetableData = this.getPrimaryTimetable();
                            break;
                        case 'secondary':
                            timetableData = this.getSecondaryTimetable();
                            break;
                    }
                    
                    this.displayTimetable(className, timetableData);
                    
                    // Randomly show conflict alert for demo
                    if (Math.random() > 0.5) {
                        document.getElementById('conflictAlert').classList.remove('hidden');
                    }
                }, 1000);
            }

            displayTimetable(className, timetableData) {
                const displayArea = document.getElementById('timetableDisplay');
                
                // Generate timetable based on current view
                if (this.currentView === 'weekly') {
                    displayArea.innerHTML = this.generateWeeklyTimetable(className, timetableData);
                } else if (this.currentView === 'daily') {
                    displayArea.innerHTML = this.generateDailyTimetable(className, timetableData);
                } else {
                    displayArea.innerHTML = this.generateTeacherTimetable(className, timetableData);
                }
                
                // Add click events to timetable cells
                this.addTimetableCellEvents();
            }

            generateWeeklyTimetable(className, data) {
                const isEarlyChildhood = this.currentLevel === 'early-childhood';
                const activityKey = isEarlyChildhood ? 'activity' : 'subject';
                
                return `
                    <h3 class="text-lg font-semibold text-nsknavy mb-4">Weekly Timetable for ${className.toUpperCase()}</h3>
                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse">
                            <thead>
                                <tr>
                                    <th class="bg-nsklightblue text-white p-3">Time/Day</th>
                                    <th class="bg-nsklightblue text-white p-3">Monday</th>
                                    <th class="bg-nsklightblue text-white p-3">Tuesday</th>
                                    <th class="bg-nsklightblue text-white p-3">Wednesday</th>
                                    <th class="bg-nsklightblue text-white p-3">Thursday</th>
                                    <th class="bg-nsklightblue text-white p-3">Friday</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${data.map(row => `
                                    <tr>
                                        <td class="bg-nsklight p-3 font-semibold text-center">${row.time}</td>
                                        ${row.days.map(day => `
                                            <td class="p-2">
                                                ${day ? `
                                                    <div class="timetable-cell ${day.class} p-3 rounded-lg">
                                                        <p class="font-semibold">${day[activityKey]}</p>
                                                        <p class="text-sm">${day.teacher}</p>
                                                        <p class="text-xs">${day.room}</p>
                                                    </div>
                                                ` : `
                                                    <div class="bg-gray-100 p-3 rounded-lg text-center text-gray-500">
                                                        <p class="font-semibold">FREE</p>
                                                    </div>
                                                `}
                                            </td>
                                        `).join('')}
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            }

            generateDailyTimetable(className, data) {
                const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
                const dayIndex = days.indexOf(document.getElementById('day')?.value || 'Monday');
                const selectedDay = dayIndex >= 0 ? dayIndex : 0;
                
                const isEarlyChildhood = this.currentLevel === 'early-childhood';
                const activityKey = isEarlyChildhood ? 'activity' : 'subject';
                
                return `
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-semibold text-nsknavy">Daily Timetable for ${className.toUpperCase()} - ${days[selectedDay]}</h3>
                        <div class="flex items-center space-x-2">
                            <select id="dailyDaySelector" class="px-3 py-1 border rounded-lg">
                                ${days.map((day, index) => `
                                    <option value="${day.toLowerCase()}" ${index === selectedDay ? 'selected' : ''}>${day}</option>
                                `).join('')}
                            </select>
                        </div>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full border-collapse">
                            <thead>
                                <tr>
                                    <th class="bg-nsklightblue text-white p-3">Time</th>
                                    <th class="bg-nsklightblue text-white p-3">${activityKey.charAt(0).toUpperCase() + activityKey.slice(1)}</th>
                                    <th class="bg-nsklightblue text-white p-3">Teacher</th>
                                    <th class="bg-nsklightblue text-white p-3">Room</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${data.map(row => {
                                    const day = row.days[selectedDay];
                                    return `
                                        <tr>
                                            <td class="bg-nsklight p-3 font-semibold text-center">${row.time}</td>
                                            <td class="p-3">
                                                ${day ? `
                                                    <div class="timetable-cell ${day.class} p-3 rounded-lg">
                                                        <p class="font-semibold">${day[activityKey]}</p>
                                                    </div>
                                                ` : `
                                                    <div class="bg-gray-100 p-3 rounded-lg text-center text-gray-500">
                                                        <p class="font-semibold">FREE</p>
                                                    </div>
                                                `}
                                            </td>
                                            <td class="p-3 text-center">${day ? day.teacher : '-'}</td>
                                            <td class="p-3 text-center">${day ? day.room : '-'}</td>
                                        </tr>
                                    `;
                                }).join('')}
                            </tbody>
                        </table>
                    </div>
                `;
            }

            generateTeacherTimetable(className, data) {
                // Simplified teacher view - in a real app, this would show teacher schedules
                return `
                    <h3 class="text-lg font-semibold text-nsknavy mb-4">Teacher Schedule View for ${className.toUpperCase()}</h3>
                    <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                        <div class="flex items-center">
                            <i class="fas fa-info-circle text-yellow-500 mr-3"></i>
                            <p>Teacher view shows all classes assigned to teachers. This feature is under development.</p>
                        </div>
                    </div>
                    <div class="mt-4">
                        <p class="text-gray-600">In the full version, this view would display:</p>
                        <ul class="list-disc list-inside mt-2 text-gray-600">
                            <li>Teacher schedules across all classes</li>
                            <li>Teacher availability and free periods</li>
                            <li>Teacher workload distribution</li>
                        </ul>
                    </div>
                `;
            }

            getEarlyChildhoodTimetable() {
                return [
                    {
                        time: '8:00 - 8:30',
                        days: [
                            { activity: 'Arrival & Free Play', teacher: 'Teacher Sarah', room: 'Play Area', class: 'subject-art' },
                            { activity: 'Morning Circle', teacher: 'Teacher Sarah', room: 'Carpet Area', class: 'subject-english' },
                            { activity: 'Arrival & Free Play', teacher: 'Teacher Sarah', room: 'Play Area', class: 'subject-art' },
                            { activity: 'Morning Circle', teacher: 'Teacher Sarah', room: 'Carpet Area', class: 'subject-english' },
                            { activity: 'Arrival & Free Play', teacher: 'Teacher Sarah', room: 'Play Area', class: 'subject-art' }
                        ]
                    },
                    {
                        time: '8:30 - 9:00',
                        days: [
                            { activity: 'Arts & Crafts', teacher: 'Teacher Sarah', room: 'Art Corner', class: 'subject-art' },
                            { activity: 'Story Time', teacher: 'Teacher Sarah', room: 'Reading Corner', class: 'subject-story' },
                            { activity: 'Music & Movement', teacher: 'Teacher Sarah', room: 'Activity Area', class: 'subject-music' },
                            { activity: 'Puzzle Time', teacher: 'Teacher Sarah', room: 'Learning Center', class: 'subject-math' },
                            { activity: 'Outdoor Play', teacher: 'Teacher Sarah', room: 'Playground', class: 'subject-pe' }
                        ]
                    },
                    {
                        time: '9:00 - 9:30',
                        days: [
                            { activity: 'Snack Time', teacher: 'Teacher Sarah', room: 'Dining Area', class: 'subject-break' },
                            { activity: 'Snack Time', teacher: 'Teacher Sarah', room: 'Dining Area', class: 'subject-break' },
                            { activity: 'Snack Time', teacher: 'Teacher Sarah', room: 'Dining Area', class: 'subject-break' },
                            { activity: 'Snack Time', teacher: 'Teacher Sarah', room: 'Dining Area', class: 'subject-break' },
                            { activity: 'Snack Time', teacher: 'Teacher Sarah', room: 'Dining Area', class: 'subject-break' }
                        ]
                    },
                    {
                        time: '9:30 - 10:00',
                        days: [
                            { activity: 'Numbers & Counting', teacher: 'Teacher Sarah', room: 'Learning Center', class: 'subject-math' },
                            { activity: 'Phonics & Letters', teacher: 'Teacher Sarah', room: 'Learning Center', class: 'subject-english' },
                            { activity: 'Shapes & Colors', teacher: 'Teacher Sarah', room: 'Learning Center', class: 'subject-art' },
                            { activity: 'Nature Study', teacher: 'Teacher Sarah', room: 'Garden Area', class: 'subject-science' },
                            { activity: 'Water Play', teacher: 'Teacher Sarah', room: 'Outdoor Area', class: 'subject-pe' }
                        ]
                    },
                    {
                        time: '10:00 - 10:30',
                        days: [
                            { activity: 'Outdoor Play', teacher: 'Teacher Sarah', room: 'Playground', class: 'subject-pe' },
                            { activity: 'Dramatic Play', teacher: 'Teacher Sarah', room: 'Role Play Area', class: 'subject-art' },
                            { activity: 'Sensory Activities', teacher: 'Teacher Sarah', room: 'Sensory Table', class: 'subject-sensory' },
                            { activity: 'Group Games', teacher: 'Teacher Sarah', room: 'Activity Area', class: 'subject-pe' },
                            { activity: 'Music & Dance', teacher: 'Teacher Sarah', room: 'Activity Area', class: 'subject-music' }
                        ]
                    }
                ];
            }

            getPrimaryTimetable() {
                return [
                    {
                        time: '8:00 - 8:45',
                        days: [
                            { subject: 'Mathematics', teacher: 'Mr. Johnson', room: 'Room 201', class: 'subject-math' },
                            { subject: 'English', teacher: 'Mr. Yusuf', room: 'Room 105', class: 'subject-english' },
                            { subject: 'Science', teacher: 'Dr. Amina', room: 'Lab 3', class: 'subject-science' },
                            { subject: 'Mathematics', teacher: 'Mr. Johnson', room: 'Room 201', class: 'subject-math' },
                            { subject: 'Social Studies', teacher: 'Mr. Kabir', room: 'Room 112', class: 'subject-history' }
                        ]
                    },
                    {
                        time: '8:45 - 9:30',
                        days: [
                            { subject: 'Science', teacher: 'Dr. Amina', room: 'Lab 2', class: 'subject-science' },
                            { subject: 'Mathematics', teacher: 'Mr. Johnson', room: 'Room 201', class: 'subject-math' },
                            { subject: 'English', teacher: 'Mr. Yusuf', room: 'Room 105', class: 'subject-english' },
                            { subject: 'Biology', teacher: 'Mrs. Fatima', room: 'Lab 1', class: 'subject-science' },
                            { subject: 'Mathematics', teacher: 'Mr. Johnson', room: 'Room 201', class: 'subject-math' }
                        ]
                    },
                    {
                        time: '9:30 - 10:15',
                        days: [
                            { subject: 'Civics', teacher: 'Mr. Kabir', room: 'Room 112', class: 'subject-history' },
                            { subject: 'Physical Education', teacher: 'Coach Ahmed', room: 'Sports Field', class: 'subject-pe' },
                            { subject: 'Art', teacher: 'Mrs. Zainab', room: 'Art Room', class: 'subject-art' },
                            { subject: 'Physical Education', teacher: 'Coach Ahmed', room: 'Sports Field', class: 'subject-pe' },
                            { subject: 'Science', teacher: 'Dr. Amina', room: 'Lab 3', class: 'subject-science' }
                        ]
                    },
                    {
                        time: '10:15 - 11:00',
                        days: [null, null, null, null, null] // Break period
                    },
                    {
                        time: '11:00 - 11:45',
                        days: [
                            { subject: 'Literature', teacher: 'Mr. Yusuf', room: 'Room 105', class: 'subject-english' },
                            { subject: 'Science', teacher: 'Dr. Amina', room: 'Lab 2', class: 'subject-science' },
                            { subject: 'Mathematics', teacher: 'Mr. Johnson', room: 'Room 201', class: 'subject-math' },
                            { subject: 'Geography', teacher: 'Mr. Kabir', room: 'Room 112', class: 'subject-history' },
                            { subject: 'English', teacher: 'Mr. Yusuf', room: 'Room 105', class: 'subject-english' }
                        ]
                    }
                ];
            }

            getSecondaryTimetable() {
                // Similar structure but with secondary school subjects
                return this.getPrimaryTimetable();
            }

            addTimetableCellEvents() {
                document.querySelectorAll('.timetable-cell').forEach(cell => {
                    cell.addEventListener('click', function() {
                        const subject = this.querySelector('.font-semibold').textContent;
                        const teacher = this.querySelectorAll('p')[1]?.textContent || 'N/A';
                        const room = this.querySelectorAll('p')[2]?.textContent || 'N/A';
                        
                        alert(`Subject: ${subject}\nTeacher: ${teacher}\nRoom: ${room}`);
                    });
                });
            }

            loadInitialData() {
                // Initial setup
                console.log('Timetable Manager initialized');
            }

            populateModalOptions() {
                // Populate modal with sample data
                const subjects = {
                    primary: ['Mathematics', 'English', 'Science', 'Social Studies', 'Art', 'Physical Education', 'Religious Studies'],
                    secondary: ['Mathematics', 'English', 'Physics', 'Chemistry', 'Biology', 'History', 'Geography', 'Economics', 'Art', 'Physical Education']
                };
                
                const teachers = {
                    primary: ['Mr. Johnson', 'Mr. Yusuf', 'Dr. Amina', 'Mr. Kabir', 'Mrs. Zainab', 'Coach Ahmed'],
                    secondary: ['Mr. Johnson', 'Mr. Yusuf', 'Dr. Amina', 'Mr. Kabir', 'Mrs. Zainab', 'Coach Ahmed', 'Mrs. Fatima', 'Mr. Bello']
                };
                
                const classrooms = ['Room 201', 'Room 105', 'Room 112', 'Lab 1', 'Lab 2', 'Lab 3', 'Art Room', 'Music Room', 'Sports Field'];
                
                // This would be populated dynamically based on user selection in a real app
            }

            updateModalClasses(level) {
                const classSelect = document.getElementById('class');
                classSelect.innerHTML = '<option value="">Select Class</option>';
                
                const classes = level === 'primary' 
                    ? ['Primary 1', 'Primary 2', 'Primary 3', 'Primary 4', 'Primary 5', 'Primary 6']
                    : ['JSS 1', 'JSS 2', 'JSS 3', 'SS 1', 'SS 2', 'SS 3'];
                
                classes.forEach(cls => {
                    const option = document.createElement('option');
                    option.value = cls.toLowerCase().replace(' ', '');
                    option.textContent = cls;
                    classSelect.appendChild(option);
                });
            }
            
            updateModalSubjects(level) {
                const subjectSelect = document.getElementById('subject');
                subjectSelect.innerHTML = '<option value="">Select Subject</option>';
                
                const subjects = level === 'primary' 
                    ? ['Mathematics', 'English', 'Science', 'Social Studies', 'Art', 'Physical Education', 'Religious Studies']
                    : ['Mathematics', 'English', 'Physics', 'Chemistry', 'Biology', 'History', 'Geography', 'Economics', 'Art', 'Physical Education'];
                
                subjects.forEach(subject => {
                    const option = document.createElement('option');
                    option.value = subject.toLowerCase().replace(' ', '');
                    option.textContent = subject;
                    subjectSelect.appendChild(option);
                });
            }
        }

        // Initialize timetable manager
        const timetableManager = new TimetableManager();

        // Sidebar toggle functionality
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('collapsed');
            document.querySelector('.main-content').classList.toggle('expanded');
            document.querySelectorAll('.sidebar-text').forEach(el => {
                el.classList.toggle('hidden');
            });
        });

        // Mobile menu toggle
        document.getElementById('mobileMenuToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('mobile-show');
        });

        // Modal functionality
        const modal = document.getElementById('addScheduleModal');
        const addScheduleBtn = document.getElementById('addScheduleBtn');
        const closeModal = document.getElementById('closeModal');
        const cancelBtn = document.getElementById('cancelBtn');
        const scheduleForm = document.getElementById('scheduleForm');

        addScheduleBtn.addEventListener('click', function() {
            modal.classList.add('active');
        });

        function closeModalFunc() {
            modal.classList.remove('active');
            scheduleForm.reset();
        }

        closeModal.addEventListener('click', closeModalFunc);
        cancelBtn.addEventListener('click', closeModalFunc);

        // Close modal when clicking outside
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModalFunc();
            }
        });

        // Form submission
        scheduleForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const subject = document.getElementById('subject').value;
            const day = document.getElementById('day').value;
            const startTime = document.getElementById('startTime').value;
            
            // Simulate adding a schedule
            alert(`Schedule added for ${subject} on ${day} at ${startTime}`);
            closeModalFunc();
        });

        // Auto-generate timetable
        document.getElementById('generateTimetableBtn').addEventListener('click', function() {
            if (!timetableManager.currentClass) {
                alert('Please select a class first');
                return;
            }
            
            this.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Generating...';
            this.disabled = true;
            
            setTimeout(() => {
                alert('Timetable successfully generated!');
                this.innerHTML = '<i class="fas fa-magic mr-2"></i> Auto-Generate';
                this.disabled = false;
                
                // Reload the timetable
                timetableManager.loadTimetable(timetableManager.currentClass);
            }, 2000);
        });

        // Template card click events
        document.querySelectorAll('.template-card').forEach(card => {
            card.addEventListener('click', function() {
                const templateName = this.querySelector('h4').textContent;
                alert(`Applying ${templateName} to current class`);
            });
        });

        // Bulk operation buttons
        document.querySelectorAll('.bulk-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const action = this.textContent.trim();
                alert(`Bulk action: ${action}`);
            });
        });

        // Export buttons
        document.querySelectorAll('.export-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const format = this.textContent.trim();
                alert(`Exporting timetable as ${format}`);
            });
        });

        // Daily view day selector
        document.addEventListener('click', function(e) {
            if (e.target && e.target.id === 'dailyDaySelector') {
                if (timetableManager.currentClass && timetableManager.currentView === 'daily') {
                    timetableManager.loadTimetable(timetableManager.currentClass);
                }
            }
        });
    </script>
</body>
</html>