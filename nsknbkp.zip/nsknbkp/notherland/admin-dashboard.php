<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Northland Schools Kano</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        nskblue: '#1e40af',
                        nsklightblue: '#3b82f6',
                        nsknavy: '#1e3a8a',
                        nskgold: '#f59e0b',
                        nsklight: '#f0f9ff',
                        nskgreen: '#10b981',
                        nskred: '#ef4444'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap');
        
        body {
            font-family: 'Montserrat', sans-serif;
            background: #f8fafc;
        }
        
        .logo-container {
            background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%);
        }
        
        .dashboard-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
        }
        
        .nav-item {
            position: relative;
        }
        
        .nav-item::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: -5px;
            left: 0;
            background-color: #f59e0b;
            transition: width 0.3s ease;
        }
        
        .nav-item:hover::after {
            width: 100%;
        }
        
        .sidebar {
            transition: all 0.3s ease;
            width: 250px;
        }
        
        .sidebar.collapsed {
            width: 80px;
        }
        
        .main-content {
            transition: all 0.3s ease;
            margin-left: 250px;
            width: calc(100% - 250px);
        }
        
        .main-content.expanded {
            margin-left: 80px;
            width: calc(100% - 80px);
        }
        
        @media (max-width: 768px) {
            .sidebar {
                margin-left: -250px;
            }
            
            .sidebar.mobile-show {
                margin-left: 0;
            }
            
            .main-content {
                margin-left: 0;
                width: 100%;
            }
        }
        
        .notification-dot {
            position: absolute;
            top: -5px;
            right: -5px;
            width: 12px;
            height: 12px;
            background-color: #ef4444;
            border-radius: 50%;
        }
        
        .progress-bar {
            height: 8px;
            background-color: #e5e7eb;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            border-radius: 4px;
        }

        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
    </style>
</head>
<body class="flex">
    <!-- Sidebar Navigation -->
    <script src="sidebar.js"></script>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <header class="bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="md:hidden text-nsknavy">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <img style="width: 10%;" src="./school logo.jpeg" alt="">
                    <h1 class="text-2xl font-bold text-nsknavy">Admin Dashboard</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <div class="flex items-center space-x-2 bg-nsklight rounded-full py-2 px-4">
                            <i class="fas fa-search text-gray-500"></i>
                            <input type="text" placeholder="Search..." class="bg-transparent outline-none w-32 md:w-64">
                        </div>
                    </div>
                    
                    <div class="relative">
                        <i class="fas fa-bell text-nsknavy text-xl"></i>
                        <div class="notification-dot"></div>
                    </div>
                    
                    <div class="relative">
                        <i class="fas fa-envelope text-nsknavy text-xl"></i>
                        <div class="notification-dot"></div>
                    </div>
                    
                    <div class="hidden md:flex items-center space-x-2">
                        <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center text-white font-bold">
                            A
                        </div>
                        <div>
                            <p class="text-sm font-semibold text-nsknavy">Admin User</p>
                            <p class="text-xs text-gray-600">Administrator</p>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Dashboard Content -->
        <div class="p-6">
            <!-- Stats Overview -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="dashboard-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nsklightblue p-4 rounded-full mr-4">
                        <i class="fas fa-user-graduate text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Total Students</p>
                        <p class="text-2xl font-bold text-nsknavy">1,245</p>
                        <p class="text-xs text-nskgreen"><i class="fas fa-arrow-up"></i> 5% from last month</p>
                    </div>
                </div>
                
                <div class="dashboard-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nskgreen p-4 rounded-full mr-4">
                        <i class="fas fa-baby text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Early Years</p>
                        <p class="text-2xl font-bold text-nsknavy">185</p>
                        <p class="text-xs text-gray-600">Nursery & KG</p>
                    </div>
                </div>
                
                <div class="dashboard-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nskgold p-4 rounded-full mr-4">
                        <i class="fas fa-chalkboard-teacher text-white text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Teaching Staff</p>
                        <p class="text-2xl font-bold text-nsknavy">68</p>
                        <p class="text-xs text-gray-600">5 vacancies</p>
                    </div>
                </div>
                
                <div class="dashboard-card bg-white rounded-xl shadow-md p-5 flex items-center">
                    <div class="bg-nskred p-4 rounded-full mr-4">
                        <i class="fas fa-bullhorn"></i>
                    </div>
                    <div>
                        <p class="text-gray-600">Send Notice</p>
                        <p class="text-2xl font-bold text-nsknavy">12</p>
                        <p class="text-xs text-nskred"><i class="fas fa-exclamation-circle"></i> 3 urgent</p>
                    </div>
                </div>
            </div>

            <!-- Student Distribution Charts -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                <!-- Student Distribution by Section -->
                <div class="dashboard-card bg-white rounded-xl shadow-md p-6">
                    <h2 class="text-xl font-bold text-nsknavy mb-4">Student Distribution by Section</h2>
                    <div class="chart-container">
                        <canvas id="sectionDistributionChart"></canvas>
                    </div>
                </div>
                
                <!-- Students per Grade/Class -->
                <div class="dashboard-card bg-white rounded-xl shadow-md p-6">
                    <h2 class="text-xl font-bold text-nsknavy mb-4">Students per Grade/Class</h2>
                    <div class="chart-container">
                        <canvas id="gradeDistributionChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Detailed Class Breakdown -->
            <div class="dashboard-card bg-white rounded-xl shadow-md p-6 mb-8">
                <h2 class="text-xl font-bold text-nsknavy mb-6">Detailed Class Breakdown</h2>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Early Years -->
                    <div class="bg-blue-50 rounded-lg p-4">
                        <h3 class="text-lg font-semibold text-nskblue mb-4 flex items-center">
                            <i class="fas fa-baby mr-2"></i> Early Years
                        </h3>
                        <div class="space-y-3">
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">Playgroup</span>
                                <span class="font-bold text-nskblue">42</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">Nursery 1</span>
                                <span class="font-bold text-nskblue">48</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">Nursery 2</span>
                                <span class="font-bold text-nskblue">52</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">Kindergarten</span>
                                <span class="font-bold text-nskblue">43</span>
                            </div>
                            <div class="border-t pt-2 mt-2">
                                <div class="flex justify-between items-center font-semibold">
                                    <span>Total</span>
                                    <span class="text-nskblue">185</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Primary School -->
                    <div class="bg-green-50 rounded-lg p-4">
                        <h3 class="text-lg font-semibold text-nskgreen mb-4 flex items-center">
                            <i class="fas fa-child mr-2"></i> Primary School
                        </h3>
                        <div class="space-y-3">
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">Grade 1</span>
                                <span class="font-bold text-nskgreen">68</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">Grade 2</span>
                                <span class="font-bold text-nskgreen">72</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">Grade 3</span>
                                <span class="font-bold text-nskgreen">75</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">Grade 4</span>
                                <span class="font-bold text-nskgreen">70</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">Grade 5</span>
                                <span class="font-bold text-nskgreen">65</span>
                            </div>
                            <div class="border-t pt-2 mt-2">
                                <div class="flex justify-between items-center font-semibold">
                                    <span>Total</span>
                                    <span class="text-nskgreen">350</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Secondary School -->
                    <div class="bg-amber-50 rounded-lg p-4">
                        <h3 class="text-lg font-semibold text-nskgold mb-4 flex items-center">
                            <i class="fas fa-user-graduate mr-2"></i> Secondary School
                        </h3>
                        <div class="space-y-3">
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">Grade 6 (JSS 1)</span>
                                <span class="font-bold text-nskgold">85</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">Grade 7 (JSS 2)</span>
                                <span class="font-bold text-nskgold">82</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">Grade 8 (JSS 3)</span>
                                <span class="font-bold text-nskgold">78</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">Grade 9 (SS 1)</span>
                                <span class="font-bold text-nskgold">125</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">Grade 10 (SS 2)</span>
                                <span class="font-bold text-nskgold">120</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">Grade 11 (SS 3)</span>
                                <span class="font-bold text-nskgold">120</span>
                            </div>
                            <div class="border-t pt-2 mt-2">
                                <div class="flex justify-between items-center font-semibold">
                                    <span>Total</span>
                                    <span class="text-nskgold">710</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Activities and Notifications -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                <div class="dashboard-card bg-white rounded-xl shadow-md p-6">
                    <h2 class="text-xl font-bold text-nsknavy mb-4">Recent Activities</h2>
                    <div class="space-y-4">
                        <div class="flex items-start">
                            <div class="bg-nsklightblue p-2 rounded-full mr-3 mt-1">
                                <i class="fas fa-user-plus text-white text-sm"></i>
                            </div>
                            <div>
                                <p class="font-semibold">New student registered</p>
                                <p class="text-sm text-gray-600">Ahmad Musa was added to Grade 10-B</p>
                                <p class="text-xs text-gray-500">2 hours ago</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <div class="bg-nskgreen p-2 rounded-full mr-3 mt-1">
                                <i class="fas fa-money-bill-wave text-white text-sm"></i>
                            </div>
                            <div>
                                <p class="font-semibold">Fee payment received</p>
                                <p class="text-sm text-gray-600">Yusuf Abdullahi paid Term 2 fees</p>
                                <p class="text-xs text-gray-500">5 hours ago</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <div class="bg-nskgold p-2 rounded-full mr-3 mt-1">
                                <i class="fas fa-clipboard-check text-white text-sm"></i>
                            </div>
                            <div>
                                <p class="font-semibold">Exam results uploaded</p>
                                <p class="text-sm text-gray-600">Mathematics mid-term results added</p>
                                <p class="text-xs text-gray-500">Yesterday</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <div class="bg-nskred p-2 rounded-full mr-3 mt-1">
                                <i class="fas fa-exclamation-triangle text-white text-sm"></i>
                            </div>
                            <div>
                                <p class="font-semibold">Low attendance alert</p>
                                <p class="text-sm text-gray-600">Grade 9-C has low attendance this week</p>
                                <p class="text-xs text-gray-500">2 days ago</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="dashboard-card bg-white rounded-xl shadow-md p-6">
                    <h2 class="text-xl font-bold text-nsknavy mb-4">Upcoming Events</h2>
                    <div class="space-y-4">
                        <div class="flex items-start">
                            <div class="bg-nskblue text-white text-center p-2 rounded mr-3" style="min-width: 45px;">
                                <p class="text-sm font-bold">20</p>
                                <p class="text-xs">NOV</p>
                            </div>
                            <div>
                                <p class="font-semibold">Annual Sports Day</p>
                                <p class="text-sm text-gray-600">School grounds, 9:00 AM</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <div class="bg-nskgreen text-white text-center p-2 rounded mr-3" style="min-width: 45px;">
                                <p class="text-sm font-bold">25</p>
                                <p class="text-xs">NOV</p>
                            </div>
                            <div>
                                <p class="font-semibold">Parent-Teacher Meeting</p>
                                <p class="text-sm text-gray-600">All classrooms, 2:00 PM</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <div class="bg-nskgold text-white text-center p-2 rounded mr-3" style="min-width: 45px;">
                                <p class="text-sm font-bold">30</p>
                                <p class="text-xs">NOV</p>
                            </div>
                            <div>
                                <p class="font-semibold">Science Fair</p>
                                <p class="text-sm text-gray-600">Science block, 10:00 AM</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <div class="bg-nskred text-white text-center p-2 rounded mr-3" style="min-width: 45px;">
                                <p class="text-sm font-bold">5</p>
                                <p class="text-xs">DEC</p>
                            </div>
                            <div>
                                <p class="font-semibold">End of Term Exams</p>
                                <p class="text-sm text-gray-600">All classes</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Include footer -->
        <script src="footer.js"></script>
    </main>

    <script>
        // Wait for everything to load including sidebar
        window.addEventListener('load', function() {
            // Mobile menu toggle
            const mobileMenuToggle = document.getElementById('mobileMenuToggle');
            if (mobileMenuToggle) {
                mobileMenuToggle.addEventListener('click', function() {
                    const sidebar = document.querySelector('.sidebar');
                    if (sidebar) {
                        sidebar.classList.toggle('mobile-show');
                    }
                });
            }

            // Initialize charts after a small delay to ensure canvas is ready
            setTimeout(function() {
                initializeStudentCharts();
            }, 200);

            // Sample data update (simulating real-time updates)
            setInterval(() => {
                const randomStat = Math.floor(Math.random() * 4);
                const statElements = document.querySelectorAll('.grid.grid-cols-1.md\\:grid-cols-2.lg\\:grid-cols-4.gap-6.mb-8 .text-2xl');
                
                if (statElements[randomStat]) {
                    const currentValue = parseInt(statElements[randomStat].textContent.replace(/\D/g, ''));
                    const newValue = randomStat === 3 ? 
                        Math.max(0, currentValue - 1) : 
                        currentValue + (randomStat === 0 ? 1 : (randomStat === 1 ? 50000 : 1));
                    
                    statElements[randomStat].textContent = randomStat === 1 ? 
                        '₦' + (newValue / 1000000).toFixed(1) + 'M' : 
                        newValue.toLocaleString();
                }
            }, 5000);
        });

        function initializeStudentCharts() {
            // Section Distribution Chart (Pie Chart)
            const sectionCanvas = document.getElementById('sectionDistributionChart');
            if (sectionCanvas) {
                const sectionCtx = sectionCanvas.getContext('2d');
                new Chart(sectionCtx, {
                    type: 'doughnut',
                    data: {
                        labels: ['Early Years', 'Primary School', 'Secondary School'],
                        datasets: [{
                            data: [185, 350, 710],
                            backgroundColor: [
                                'rgba(59, 130, 246, 0.8)',
                                'rgba(16, 185, 129, 0.8)',
                                'rgba(245, 158, 11, 0.8)'
                            ],
                            borderColor: [
                                'rgb(59, 130, 246)',
                                'rgb(16, 185, 129)',
                                'rgb(245, 158, 11)'
                            ],
                            borderWidth: 2
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                position: 'bottom',
                                labels: {
                                    padding: 20,
                                    usePointStyle: true,
                                    pointStyle: 'circle'
                                }
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        const label = context.label || '';
                                        const value = context.parsed;
                                        const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                        const percentage = Math.round((value / total) * 100);
                                        return `${label}: ${value} students (${percentage}%)`;
                                    }
                                }
                            }
                        },
                        cutout: '60%'
                    }
                });
            }

            // Grade Distribution Chart (Bar Chart)
            const gradeCanvas = document.getElementById('gradeDistributionChart');
            if (gradeCanvas) {
                const gradeCtx = gradeCanvas.getContext('2d');
                new Chart(gradeCtx, {
                    type: 'bar',
                    data: {
                        labels: ['Playgroup', 'Nursery 1', 'Nursery 2', 'KG', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6', 'Grade 7', 'Grade 8', 'Grade 9', 'Grade 10', 'Grade 11'],
                        datasets: [{
                            label: 'Number of Students',
                            data: [42, 48, 52, 43, 68, 72, 75, 70, 65, 85, 82, 78, 125, 120, 120],
                            backgroundColor: [
                                // Early Years - Blue shades
                                'rgba(59, 130, 246, 0.7)', 'rgba(59, 130, 246, 0.7)', 'rgba(59, 130, 246, 0.7)', 'rgba(59, 130, 246, 0.7)',
                                // Primary - Green shades
                                'rgba(16, 185, 129, 0.7)', 'rgba(16, 185, 129, 0.7)', 'rgba(16, 185, 129, 0.7)', 'rgba(16, 185, 129, 0.7)', 'rgba(16, 185, 129, 0.7)',
                                // Secondary - Gold shades
                                'rgba(245, 158, 11, 0.7)', 'rgba(245, 158, 11, 0.7)', 'rgba(245, 158, 11, 0.7)', 'rgba(245, 158, 11, 0.7)', 'rgba(245, 158, 11, 0.7)', 'rgba(245, 158, 11, 0.7)'
                            ],
                            borderColor: [
                                'rgb(59, 130, 246)', 'rgb(59, 130, 246)', 'rgb(59, 130, 246)', 'rgb(59, 130, 246)',
                                'rgb(16, 185, 129)', 'rgb(16, 185, 129)', 'rgb(16, 185, 129)', 'rgb(16, 185, 129)', 'rgb(16, 185, 129)',
                                'rgb(245, 158, 11)', 'rgb(245, 158, 11)', 'rgb(245, 158, 11)', 'rgb(245, 158, 11)', 'rgb(245, 158, 11)', 'rgb(245, 158, 11)'
                            ],
                            borderWidth: 1,
                            borderRadius: 4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: false
                            },
                            tooltip: {
                                backgroundColor: 'rgba(30, 64, 175, 0.9)',
                                padding: 12,
                                titleFont: {
                                    size: 14
                                },
                                bodyFont: {
                                    size: 13
                                }
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Number of Students'
                                },
                                grid: {
                                    color: 'rgba(0, 0, 0, 0.05)'
                                }
                            },
                            x: {
                                grid: {
                                    display: false
                                },
                                ticks: {
                                    maxRotation: 45,
                                    minRotation: 45
                                }
                            }
                        }
                    }
                });
            }
        }

        // Simulate live notifications
        setInterval(() => {
            const notifications = document.querySelectorAll('.notification-dot');
            notifications.forEach(dot => {
                dot.style.display = Math.random() > 0.3 ? 'block' : 'none';
            });
        }, 3000);
    </script>
</body>
</html>