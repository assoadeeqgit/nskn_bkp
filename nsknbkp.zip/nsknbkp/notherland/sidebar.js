// sidebar.js - Reusable sidebar component
class SidebarManager {
    constructor() {
        this.sidebarHTML = `
            <!-- Sidebar Navigation -->
            <aside class="sidebar bg-nsknavy text-white h-screen fixed top-0 left-0 z-10">
                <div class="p-6 h-full flex flex-col">
                    <div class="logo-container rounded-lg p-4 mb-8">
                        <div class="flex items-center">
                            <div class="w-10 h-10 rounded-full bg-white flex items-center justify-center mr-3">
                               <img src="./school_logo.png" alt="logo">
                            </div>
                            <div>
                                <h2 class="text-lg font-bold">Northland Schools</h2>
                                <p class="text-xs opacity-75">Kano, Nigeria</p>
                            </div>
                        </div>
                    </div>
                    
                    <nav class="space-y-2 flex-1 overflow-y-auto" id="sidebar-nav">
                        <!-- Navigation items will be populated dynamically -->
                    </nav>
                </div>
                
                <div class="absolute bottom-0 left-0 right-0 p-6">
                    <div class="bg-nskblue rounded-lg p-4">
                        <div class="flex items-center mb-2">
                            <div class="w-8 h-8 rounded-full bg-white flex items-center justify-center mr-3">
                                <span class="text-nskblue font-bold text-sm">AD</span>
                            </div>
                            <div>
                                <p class="font-semibold text-sm">Admin User</p>
                                <p class="text-xs opacity-75">Super Administrator</p>
                            </div>
                        </div>
                        <button class="w-full bg-white text-nskblue py-2 px-4 rounded-lg text-sm font-semibold hover:bg-gray-100 transition logout-btn">
                            <i class="fas fa-sign-out-alt mr-2"></i>Logout
                        </button>
                    </div>
                </div>
            </aside>
        `;

        this.navigationItems = [
            { href: 'admin-dashboard.html', icon: 'fas fa-tachometer-alt', text: 'Dashboard' },
            { href: 'students-management.html', icon: 'fas fa-user-graduate', text: 'Students' },
            { href: 'teachers-management.html', icon: 'fas fa-chalkboard-teacher', text: 'Teachers' },
            { href: 'academics-management.html', icon: 'fas fa-book', text: 'Academics' },
            // { href: 'attendance-management.html', icon: 'fas fa-calendar-check', text: 'Attendance' },
            // { href: 'finance-management.html', icon: 'fas fa-dollar-sign', text: 'Finance' },
            { href: 'timetable-management.html', icon: 'fas fa-clock', text: 'Timetable' },
            { href: 'report.html', icon: 'fas fa-chart-bar', text: 'Reports' },
            { href: 'user-management.html', icon: 'fas fa-users', text: 'Users' },
            { href: 'settings.html', icon: 'fas fa-cog', text: 'Settings' }
        ];

        // Bind methods to maintain 'this' context
        this.toggleSidebar = this.toggleSidebar.bind(this);
        this.hideSidebar = this.hideSidebar.bind(this);
        this.handleLogout = this.handleLogout.bind(this);
        this.handleOutsideClick = this.handleOutsideClick.bind(this);
    }

    // Initialize sidebar
    init(currentPage = '') {
        this.injectSidebar();
        this.populateNavigation(currentPage);
        this.setupEventListeners();
    }

    // Inject sidebar into the page
    injectSidebar() {
        const body = document.querySelector('body');
        if (body && !document.querySelector('.sidebar')) {
            body.insertAdjacentHTML('afterbegin', this.sidebarHTML);
        }
    }

    // Populate navigation items
    populateNavigation(currentPage) {
        const navContainer = document.getElementById('sidebar-nav');
        if (!navContainer) return;

        navContainer.innerHTML = this.navigationItems.map(item => {
            const isActive = currentPage === item.href;
            const activeClass = isActive ? 'bg-nskblue' : 'hover:bg-nskblue';
            return `
                <a href="${item.href}" class="flex items-center p-3 rounded-lg ${activeClass} transition nav-item">
                    <i class="${item.icon} mr-3"></i>
                    <span>${item.text}</span>
                </a>
            `;
        }).join('');
    }

    // Setup event listeners
    setupEventListeners() {
        document.addEventListener('DOMContentLoaded', () => {
            // Sidebar toggle for mobile
            const sidebarToggle = document.querySelector('.sidebar-toggle');
            if (sidebarToggle) {
                sidebarToggle.addEventListener('click', this.toggleSidebar);
            }

            // Logout button
            const logoutBtn = document.querySelector('.logout-btn');
            if (logoutBtn) {
                logoutBtn.addEventListener('click', this.handleLogout);
            }

            // Close sidebar on mobile when clicking links
            const sidebarLinks = document.querySelectorAll('.sidebar a');
            sidebarLinks.forEach(link => {
                link.addEventListener('click', () => {
                    if (window.innerWidth < 768) {
                        this.hideSidebar();
                    }
                });
            });

            // Close sidebar when clicking outside on mobile
            document.addEventListener('click', this.handleOutsideClick);
        });
    }

    // Handle outside clicks to close sidebar
    handleOutsideClick(event) {
        const sidebar = document.querySelector('.sidebar');
        const sidebarToggle = document.querySelector('.sidebar-toggle');
        
        if (window.innerWidth < 768 && 
            sidebar && 
            sidebar.classList.contains('mobile-show') &&
            !sidebar.contains(event.target) && 
            (!sidebarToggle || !sidebarToggle.contains(event.target))) {
            this.hideSidebar();
        }
    }

    // Toggle sidebar visibility (mobile)
    toggleSidebar() {
        const sidebar = document.querySelector('.sidebar');
        if (sidebar) {
            sidebar.classList.toggle('mobile-show');
        }
    }

    // Hide sidebar (mobile)
    hideSidebar() {
        const sidebar = document.querySelector('.sidebar');
        if (sidebar) {
            sidebar.classList.remove('mobile-show');
        }
    }

    // Handle logout
    handleLogout(event) {
        event.preventDefault();
        if (confirm('Are you sure you want to logout?')) {
            // Add your logout logic here
            console.log('Logging out...');
            // window.location.href = 'login.html';
        }
    }
}

// Create global instance
window.sidebarManager = new SidebarManager();

// Auto-initialize if script is loaded
document.addEventListener('DOMContentLoaded', () => {
    const currentPage = window.location.pathname.split('/').pop();
    window.sidebarManager.init(currentPage);
});