<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Classes - Northland Schools Kano</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        nskblue: '#1e40af',
                        nsklightblue: '#3b82f6',
                        nsknavy: '#1e3a8a',
                        nskgold: '#f59e0b',
                        nsklight: '#f0f9ff',
                        nskgreen: '#10b981',
                        nskred: '#ef4444'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap');
        
        :root {
            --sidebar-width: 250px;
            --sidebar-collapsed-width: 80px;
            --transition-speed: 0.3s;
        }
        
        body {
            font-family: 'Montserrat', sans-serif;
            background: #f8fafc;
        }
        
        .logo-container {
            background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%);
        }
        
        .dashboard-card {
            transition: transform var(--transition-speed) ease, box-shadow var(--transition-speed) ease;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }
        
        .sidebar {
            transition: all var(--transition-speed) ease;
            width: var(--sidebar-width);
        }
        
        .sidebar.collapsed {
            width: var(--sidebar-collapsed-width);
        }
        
        .main-content {
            transition: all var(--transition-speed) ease;
            margin-left: var(--sidebar-width);
            width: calc(100% - var(--sidebar-width));
        }
        
        .main-content.expanded {
            margin-left: var(--sidebar-collapsed-width);
            width: calc(100% - var(--sidebar-collapsed-width));
        }
        
        @media (max-width: 768px) {
            .sidebar {
                margin-left: calc(-1 * var(--sidebar-width));
                z-index: 20;
            }
            
            .sidebar.mobile-show {
                margin-left: 0;
            }
            
            .main-content {
                margin-left: 0;
                width: 100%;
            }
            
            .mobile-overlay {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                z-index: 15;
            }
            
            .mobile-overlay.active {
                display: block;
            }
        }
        
        .notification-dot {
            position: absolute;
            top: -5px;
            right: -5px;
            width: 12px;
            height: 12px;
            background-color: #ef4444;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        .floating-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
            transition: transform 0.3s ease;
        }
        
        .floating-btn:hover {
            transform: scale(1.1);
        }
        
        .sidebar-link.active {
            background-color: #1e40af !important;
        }
        
        .mobile-header {
            display: none;
        }
        
        @media (max-width: 768px) {
            .mobile-header {
                display: flex;
            }
            
            .desktop-header {
                display: none;
            }
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            backdrop-filter: blur(5px);
        }
        
        .modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s ease;
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            max-width: 90%;
            max-height: 90%;
            overflow-y: auto;
            transform: scale(0.9);
            transition: transform 0.3s ease;
        }
        
        .modal.active .modal-content {
            transform: scale(1);
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    </style>
</head>
<body class="flex">
    <!-- Mobile Overlay -->
    <div class="mobile-overlay" id="mobileOverlay"></div>

    <!-- Sidebar Navigation -->
    <aside class="sidebar bg-nsknavy text-white h-screen fixed top-0 left-0 z-10">
        <div class="p-5">
            <div class="flex items-center justify-between mb-10">
                <div class="flex items-center space-x-2">
                    <div class="logo-container w-10 h-10 rounded-full flex items-center justify-center text-white font-bold">
                        NSK
                    </div>
                    <h1 class="text-xl font-bold sidebar-text">NORTHLAND SCHOOLS</h1>
                </div>
                <button id="sidebarToggle" class="text-white">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            
            <nav class="space-y-2">
                <a href="teacher dashboard.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-tachometer-alt mr-3"></i> <span class="sidebar-text">Dashboard</span>
                </a>
                <a href="my-classes.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg bg-nskblue transition active">
                    <i class="fas fa-chalkboard mr-3"></i> <span class="sidebar-text">My Classes</span>
                </a>
                <a href="my-students.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-user-graduate mr-3"></i> <span class="sidebar-text">Students</span>
                </a>
                <!-- <a href="gradebook.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-book-open mr-3"></i> <span class="sidebar-text">Gradebook</span>
                </a> -->
                <a href="assignments.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-tasks mr-3"></i> <span class="sidebar-text">Assignments</span>
                </a>
                <a href="attendance.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-clipboard-check mr-3"></i> <span class="sidebar-text">Attendance</span>
                </a>
                <a href="results.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-chart-bar mr-3"></i> <span class="sidebar-text">Results</span>
                </a>
                <!-- <a href="messages.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-comments mr-3"></i> <span class="sidebar-text">Messages</span>
                </a> -->
            </nav>
        </div>
        
        <div class="absolute bottom-0 w-full p-5">
            <div class="flex items-center space-x-3 bg-nskblue p-3 rounded-lg">
                <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center">
                    <span class="font-bold">JA</span>
                </div>
                <div class="sidebar-text">
                    <p class="text-sm font-semibold">Mr. Johnson Adeyemi</p>
                    <p class="text-xs opacity-80">Mathematics Teacher</p>
                </div>
            </div>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Desktop Header -->
        <header class="desktop-header bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="md:hidden text-nsknavy">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold text-nsknavy">My Classes</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <div class="flex items-center space-x-2 bg-nsklight rounded-full py-2 px-4">
                            <i class="fas fa-search text-gray-500"></i>
                            <input type="text" id="globalSearch" placeholder="Search classes..." class="bg-transparent outline-none w-32 md:w-64">
                        </div>
                    </div>
                    
                    <div class="relative">
                        <button id="notificationButton" class="relative">
                            <i class="fas fa-bell text-nsknavy text-xl"></i>
                            <div class="notification-dot"></div>
                        </button>
                    </div>
                    
                    <div class="hidden md:flex items-center space-x-2">
                        <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center text-white font-bold">
                            JA
                        </div>
                        <div>
                            <p class="text-sm font-semibold text-nsknavy">Mr. Johnson Adeyemi</p>
                            <p class="text-xs text-gray-600">Mathematics Teacher</p>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Mobile Header -->
        <header class="mobile-header bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="text-nsknavy">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-xl font-bold text-nsknavy">My Classes</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <button id="notificationButton" class="relative">
                            <i class="fas fa-bell text-nsknavy text-xl"></i>
                            <div class="notification-dot"></div>
                        </button>
                    </div>
                    
                    <div class="flex items-center space-x-2">
                        <div class="w-8 h-8 rounded-full bg-nskgold flex items-center justify-center text-white font-bold text-sm">
                            JA
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Classes Content -->
        <div class="p-4 md:p-6">
            <div class="bg-white rounded-xl shadow-md p-4 md:p-6 mb-4 md:mb-6">
                <div class="flex flex-col md:flex-row md:justify-between md:items-center mb-4 md:mb-6 space-y-3 md:space-y-0">
                    <h2 class="text-lg md:text-xl font-bold text-nsknavy">My Classes</h2>
                    <div class="flex space-x-3">
                        <button class="bg-nskblue text-white px-3 py-2 rounded-lg hover:bg-nsknavy transition text-sm">
                            <i class="fas fa-filter mr-2"></i>Filter
                        </button>
                        <button class="bg-nskgreen text-white px-3 py-2 rounded-lg hover:bg-green-600 transition text-sm">
                            <i class="fas fa-plus mr-2"></i>New Class
                        </button>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
                    <!-- Class Card 1 -->
                    <div class="dashboard-card border border-gray-200 rounded-lg p-4 hover:shadow-lg">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <h3 class="font-bold text-nsknavy text-sm md:text-base">Grade 10A - Mathematics</h3>
                                <p class="text-xs md:text-sm text-gray-600">Room 201 • Mon, Wed, Fri</p>
                            </div>
                            <span class="bg-green-100 text-nskgreen px-2 py-1 rounded-full text-xs font-semibold">Active</span>
                        </div>
                        <div class="space-y-2 mb-4">
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Students:</span>
                                <span class="font-semibold">30</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Average Grade:</span>
                                <span class="font-semibold text-nskgreen">85%</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Attendance:</span>
                                <span class="font-semibold text-nskblue">93%</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Next Class:</span>
                                <span class="font-semibold text-nskgold">Tomorrow, 8:00 AM</span>
                            </div>
                        </div>
                        <div class="flex space-x-2">
                            <button class="view-class-btn flex-1 bg-nskblue text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-nsknavy transition" data-class="10A">
                                View Details
                            </button>
                            <button class="take-attendance-btn bg-nskgreen text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-green-600 transition" data-class="10A">
                                <i class="fas fa-clipboard-check"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Class Card 2 -->
                    <div class="dashboard-card border border-gray-200 rounded-lg p-4 hover:shadow-lg">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <h3 class="font-bold text-nsknavy text-sm md:text-base">Grade 10B - Mathematics</h3>
                                <p class="text-xs md:text-sm text-gray-600">Room 201 • Tue, Thu</p>
                            </div>
                            <span class="bg-green-100 text-nskgreen px-2 py-1 rounded-full text-xs font-semibold">Active</span>
                        </div>
                        <div class="space-y-2 mb-4">
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Students:</span>
                                <span class="font-semibold">28</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Average Grade:</span>
                                <span class="font-semibold text-nskgold">78%</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Attendance:</span>
                                <span class="font-semibold text-nskblue">89%</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Next Class:</span>
                                <span class="font-semibold text-nskgold">Today, 2:00 PM</span>
                            </div>
                        </div>
                        <div class="flex space-x-2">
                            <button class="view-class-btn flex-1 bg-nskblue text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-nsknavy transition" data-class="10B">
                                View Details
                            </button>
                            <button class="take-attendance-btn bg-nskgreen text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-green-600 transition" data-class="10B">
                                <i class="fas fa-clipboard-check"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Class Card 3 -->
                    <div class="dashboard-card border border-gray-200 rounded-lg p-4 hover:shadow-lg">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <h3 class="font-bold text-nsknavy text-sm md:text-base">Grade 11A - Further Math</h3>
                                <p class="text-xs md:text-sm text-gray-600">Room 201 • Mon, Wed, Fri</p>
                            </div>
                            <span class="bg-green-100 text-nskgreen px-2 py-1 rounded-full text-xs font-semibold">Active</span>
                        </div>
                        <div class="space-y-2 mb-4">
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Students:</span>
                                <span class="font-semibold">25</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Average Grade:</span>
                                <span class="font-semibold text-nskgreen">91%</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Attendance:</span>
                                <span class="font-semibold text-nskblue">96%</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Next Class:</span>
                                <span class="font-semibold text-nskgold">Today, 10:30 AM</span>
                            </div>
                        </div>
                        <div class="flex space-x-2">
                            <button class="view-class-btn flex-1 bg-nskblue text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-nsknavy transition" data-class="11A">
                                View Details
                            </button>
                            <button class="take-attendance-btn bg-nskgreen text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-green-600 transition" data-class="11A">
                                <i class="fas fa-clipboard-check"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Class Card 4 -->
                    <div class="dashboard-card border border-gray-200 rounded-lg p-4 hover:shadow-lg">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <h3 class="font-bold text-nsknavy text-sm md:text-base">Grade 9A - Mathematics</h3>
                                <p class="text-xs md:text-sm text-gray-600">Room 105 • Mon, Tue, Thu</p>
                            </div>
                            <span class="bg-green-100 text-nskgreen px-2 py-1 rounded-full text-xs font-semibold">Active</span>
                        </div>
                        <div class="space-y-2 mb-4">
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Students:</span>
                                <span class="font-semibold">32</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Average Grade:</span>
                                <span class="font-semibold text-nskgreen">82%</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Attendance:</span>
                                <span class="font-semibold text-nskblue">91%</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Next Class:</span>
                                <span class="font-semibold text-nskgold">Tomorrow, 9:15 AM</span>
                            </div>
                        </div>
                        <div class="flex space-x-2">
                            <button class="view-class-btn flex-1 bg-nskblue text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-nsknavy transition" data-class="9A">
                                View Details
                            </button>
                            <button class="take-attendance-btn bg-nskgreen text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-green-600 transition" data-class="9A">
                                <i class="fas fa-clipboard-check"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Class Card 5 -->
                    <div class="dashboard-card border border-gray-200 rounded-lg p-4 hover:shadow-lg">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <h3 class="font-bold text-nsknavy text-sm md:text-base">Grade 12A - Advanced Math</h3>
                                <p class="text-xs md:text-sm text-gray-600">Room 301 • Tue, Thu, Fri</p>
                            </div>
                            <span class="bg-blue-100 text-nskblue px-2 py-1 rounded-full text-xs font-semibold">Upcoming</span>
                        </div>
                        <div class="space-y-2 mb-4">
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Students:</span>
                                <span class="font-semibold">18</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Average Grade:</span>
                                <span class="font-semibold text-gray-500">-</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Attendance:</span>
                                <span class="font-semibold text-gray-500">-</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Starts:</span>
                                <span class="font-semibold text-nskblue">Next Semester</span>
                            </div>
                        </div>
                        <div class="flex space-x-2">
                            <button class="view-class-btn flex-1 bg-nskblue text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-nsknavy transition" data-class="12A">
                                View Details
                            </button>
                            <button class="bg-gray-400 text-white py-2 px-3 rounded text-xs md:text-sm cursor-not-allowed" disabled>
                                <i class="fas fa-clipboard-check"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Class Statistics -->
            <div class="bg-white rounded-xl shadow-md p-4 md:p-6">
                <h3 class="text-lg md:text-xl font-bold text-nsknavy mb-4">Class Statistics</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
                    <div class="text-center p-4 bg-blue-50 rounded-lg">
                        <div class="text-2xl md:text-3xl font-bold text-nskblue mb-2">5</div>
                        <p class="text-sm text-gray-600">Total Classes</p>
                    </div>
                    <div class="text-center p-4 bg-green-50 rounded-lg">
                        <div class="text-2xl md:text-3xl font-bold text-nskgreen mb-2">133</div>
                        <p class="text-sm text-gray-600">Active Students</p>
                    </div>
                    <div class="text-center p-4 bg-amber-50 rounded-lg">
                        <div class="text-2xl md:text-3xl font-bold text-nskgold mb-2">89%</div>
                        <p class="text-sm text-gray-600">Average Attendance</p>
                    </div>
                    <div class="text-center p-4 bg-purple-50 rounded-lg">
                        <div class="text-2xl md:text-3xl font-bold text-purple-600 mb-2">84%</div>
                        <p class="text-sm text-gray-600">Overall Average</p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Floating Action Button for Mobile -->
    <button class="floating-btn md:hidden bg-nskblue text-white w-14 h-14 rounded-full shadow-lg flex items-center justify-center">
        <i class="fas fa-plus text-xl"></i>
    </button>

    <!-- Class Details Modal -->
    <div id="classModal" class="modal">
        <div class="modal-content w-full max-w-4xl">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg md:text-xl font-bold text-nsknavy" id="modalClassTitle">Class Details</h3>
                <button id="closeClassModal" class="text-gray-500 hover:text-gray-700">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div class="bg-blue-50 p-4 rounded-lg">
                        <h4 class="font-semibold text-nskblue mb-2">Class Information</h4>
                        <p class="text-sm"><strong>Subject:</strong> Mathematics</p>
                        <p class="text-sm"><strong>Room:</strong> 201</p>
                        <p class="text-sm"><strong>Schedule:</strong> Mon, Wed, Fri</p>
                    </div>
                    <div class="bg-green-50 p-4 rounded-lg">
                        <h4 class="font-semibold text-nskgreen mb-2">Performance</h4>
                        <p class="text-sm"><strong>Average Grade:</strong> 85%</p>
                        <p class="text-sm"><strong>Attendance Rate:</strong> 93%</p>
                        <p class="text-sm"><strong>Assignments:</strong> 8 completed</p>
                    </div>
                    <div class="bg-amber-50 p-4 rounded-lg">
                        <h4 class="font-semibold text-nskgold mb-2">Students</h4>
                        <p class="text-sm"><strong>Total:</strong> 30 students</p>
                        <p class="text-sm"><strong>Boys:</strong> 16</p>
                        <p class="text-sm"><strong>Girls:</strong> 14</p>
                    </div>
                </div>
                
                <div>
                    <h4 class="font-semibold text-nsknavy mb-3">Recent Activities</h4>
                    <div class="space-y-2">
                        <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <span class="text-sm">Algebra Quiz graded</span>
                            <span class="text-xs text-gray-500">2 hours ago</span>
                        </div>
                        <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <span class="text-sm">Attendance taken</span>
                            <span class="text-xs text-gray-500">Yesterday</span>
                        </div>
                        <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <span class="text-sm">New assignment created</span>
                            <span class="text-xs text-gray-500">2 days ago</span>
                        </div>
                    </div>
                </div>
                
                <div class="flex justify-end space-x-3 pt-4">
                    <button id="closeModal" class="px-4 py-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-100 transition">Close</button>
                    <button class="px-4 py-2 bg-nskblue text-white rounded-lg text-sm hover:bg-nsknavy transition">View Full Details</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        // DOM Elements
        const sidebar = document.querySelector('.sidebar');
        const mainContent = document.querySelector('.main-content');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const mobileOverlay = document.getElementById('mobileOverlay');
        const viewClassBtns = document.querySelectorAll('.view-class-btn');
        const takeAttendanceBtns = document.querySelectorAll('.take-attendance-btn');
        const classModal = document.getElementById('classModal');
        const closeClassModal = document.getElementById('closeClassModal');
        const closeModal = document.getElementById('closeModal');
        const modalClassTitle = document.getElementById('modalClassTitle');

        // Sidebar Toggle Functionality
        function toggleSidebar() {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
            
            const sidebarTexts = document.querySelectorAll('.sidebar-text');
            sidebarTexts.forEach(text => {
                text.classList.toggle('hidden');
            });
        }

        // Mobile Menu Toggle
        function toggleMobileMenu() {
            sidebar.classList.toggle('mobile-show');
            mobileOverlay.classList.toggle('active');
        }

        // Modal Functions
        function openModal(modal) {
            modal.classList.add('active');
        }

        function closeModalFunc(modal) {
            modal.classList.remove('active');
        }

        // View Class Details
        function handleViewClass(e) {
            const classId = e.target.getAttribute('data-class');
            modalClassTitle.textContent = `Grade ${classId} - Mathematics`;
            openModal(classModal);
        }

        // Take Attendance
        function handleTakeAttendance(e) {
            const classId = e.target.getAttribute('data-class');
            window.location.href = `attendance.html?class=${classId}`;
        }

        // Event Listeners
        sidebarToggle.addEventListener('click', toggleSidebar);
        mobileMenuToggle.addEventListener('click', toggleMobileMenu);
        mobileOverlay.addEventListener('click', toggleMobileMenu);

        // Class buttons
        viewClassBtns.forEach(btn => {
            btn.addEventListener('click', handleViewClass);
        });

        takeAttendanceBtns.forEach(btn => {
            btn.addEventListener('click', handleTakeAttendance);
        });

        // Modal close buttons
        closeClassModal.addEventListener('click', () => closeModalFunc(classModal));
        closeModal.addEventListener('click', () => closeModalFunc(classModal));

        // Close modal when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === classModal) {
                closeModalFunc(classModal);
            }
        });

        // Responsive adjustments
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) {
                sidebar.classList.remove('mobile-show');
                mobileOverlay.classList.remove('active');
            }
        });

        // Initialize the page
        document.addEventListener('DOMContentLoaded', () => {
            console.log('My Classes page loaded successfully');
        });
    </script>
</body>
</html>