<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance - Northland Schools Kano</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        nskblue: '#1e40af',
                        nsklightblue: '#3b82f6',
                        nsknavy: '#1e3a8a',
                        nskgold: '#f59e0b',
                        nsklight: '#f0f9ff',
                        nskgreen: '#10b981',
                        nskred: '#ef4444'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap');
        
        :root {
            --sidebar-width: 250px;
            --sidebar-collapsed-width: 80px;
            --transition-speed: 0.3s;
        }
        
        body {
            font-family: 'Montserrat', sans-serif;
            background: #f8fafc;
        }
        
        .logo-container {
            background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%);
        }
        
        .dashboard-card {
            transition: transform var(--transition-speed) ease, box-shadow var(--transition-speed) ease;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }
        
        .sidebar {
            transition: all var(--transition-speed) ease;
            width: var(--sidebar-width);
        }
        
        .sidebar.collapsed {
            width: var(--sidebar-collapsed-width);
        }
        
        .main-content {
            transition: all var(--transition-speed) ease;
            margin-left: var(--sidebar-width);
            width: calc(100% - var(--sidebar-width));
        }
        
        .main-content.expanded {
            margin-left: var(--sidebar-collapsed-width);
            width: calc(100% - var(--sidebar-collapsed-width));
        }
        
        @media (max-width: 768px) {
            .sidebar {
                margin-left: calc(-1 * var(--sidebar-width));
                z-index: 20;
            }
            
            .sidebar.mobile-show {
                margin-left: 0;
            }
            
            .main-content {
                margin-left: 0;
                width: 100%;
            }
            
            .mobile-overlay {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                z-index: 15;
            }
            
            .mobile-overlay.active {
                display: block;
            }
        }
        
        .notification-dot {
            position: absolute;
            top: -5px;
            right: -5px;
            width: 12px;
            height: 12px;
            background-color: #ef4444;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        .floating-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
            transition: transform 0.3s ease;
        }
        
        .floating-btn:hover {
            transform: scale(1.1);
        }
        
        .sidebar-link.active {
            background-color: #1e40af !important;
        }
        
        .mobile-header {
            display: none;
        }
        
        @media (max-width: 768px) {
            .mobile-header {
                display: flex;
            }
            
            .desktop-header {
                display: none;
            }
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            backdrop-filter: blur(5px);
        }
        
        .modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s ease;
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            max-width: 90%;
            max-height: 90%;
            overflow-y: auto;
            transform: scale(0.9);
            transition: transform 0.3s ease;
        }
        
        .modal.active .modal-content {
            transform: scale(1);
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .student-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 14px;
        }
        
        .attendance-btn {
            transition: all 0.3s ease;
            border: 2px solid;
            border-radius: 8px;
            padding: 6px 12px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
        }
        
        .attendance-btn.active {
            color: white;
        }
        
        .attendance-btn.present {
            border-color: #10b981;
            color: #10b981;
        }
        
        .attendance-btn.present.active {
            background-color: #10b981;
            border-color: #10b981;
            color: white;
        }
        
        .attendance-btn.absent {
            border-color: #ef4444;
            color: #ef4444;
        }
        
        .attendance-btn.absent.active {
            background-color: #ef4444;
            border-color: #ef4444;
            color: white;
        }
        
        .attendance-btn.late {
            border-color: #f59e0b;
            color: #f59e0b;
        }
        
        .attendance-btn.late.active {
            background-color: #f59e0b;
            border-color: #f59e0b;
            color: white;
        }
        
        .attendance-btn.excused {
            border-color: #6b7280;
            color: #6b7280;
        }
        
        .attendance-btn.excused.active {
            background-color: #6b7280;
            border-color: #6b7280;
            color: white;
        }
        
        .calendar-day {
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .calendar-day:hover {
            background-color: #f3f4f6;
        }
        
        .calendar-day.active {
            background-color: #3b82f6;
            color: white;
        }
        
        .calendar-day.has-attendance {
            position: relative;
        }
        
        .calendar-day.has-attendance::after {
            content: '';
            position: absolute;
            bottom: 2px;
            left: 50%;
            transform: translateX(-50%);
            width: 4px;
            height: 4px;
            border-radius: 50%;
            background-color: #10b981;
        }
        
        .attendance-summary-card {
            border-left: 4px solid;
        }
        
        .summary-present { border-left-color: #10b981; }
        .summary-absent { border-left-color: #ef4444; }
        .summary-late { border-left-color: #f59e0b; }
        .summary-excused { border-left-color: #6b7280; }
    </style>
</head>
<body class="flex">
    <!-- Mobile Overlay -->
    <div class="mobile-overlay" id="mobileOverlay"></div>

    <!-- Sidebar Navigation -->
    <aside class="sidebar bg-nsknavy text-white h-screen fixed top-0 left-0 z-10">
        <div class="p-5">
            <div class="flex items-center justify-between mb-10">
                <div class="flex items-center space-x-2">
                    <div class="logo-container w-10 h-10 rounded-full flex items-center justify-center text-white font-bold">
                        NSK
                    </div>
                    <h1 class="text-xl font-bold sidebar-text">NORTHLAND SCHOOLS</h1>
                </div>
                <button id="sidebarToggle" class="text-white">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            
            <nav class="space-y-2">
                <a href="index.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-tachometer-alt mr-3"></i> <span class="sidebar-text">Dashboard</span>
                </a>
                <a href="my-classes.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-chalkboard mr-3"></i> <span class="sidebar-text">My Classes</span>
                </a>
                <a href="my-students.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-user-graduate mr-3"></i> <span class="sidebar-text">Students</span>
                </a>
                <!-- <a href="gradebook.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-book-open mr-3"></i> <span class="sidebar-text">Gradebook</span>
                </a> -->
                <a href="assignments.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-tasks mr-3"></i> <span class="sidebar-text">Assignments</span>
                </a>
                <a href="attendance.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg bg-nskblue transition active">
                    <i class="fas fa-clipboard-check mr-3"></i> <span class="sidebar-text">Attendance</span>
                </a>
                <a href="results.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-chart-bar mr-3"></i> <span class="sidebar-text">Results</span>
                </a>
                <!-- <a href="messages.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-comments mr-3"></i> <span class="sidebar-text">Messages</span>
                </a> -->
            </nav>
        </div>
        
        <div class="absolute bottom-0 w-full p-5">
            <div class="flex items-center space-x-3 bg-nskblue p-3 rounded-lg">
                <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center">
                    <span class="font-bold">JA</span>
                </div>
                <div class="sidebar-text">
                    <p class="text-sm font-semibold">Mr. Johnson Adeyemi</p>
                    <p class="text-xs opacity-80">Mathematics Teacher</p>
                </div>
            </div>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Desktop Header -->
        <header class="desktop-header bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="md:hidden text-nsknavy">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold text-nsknavy">Attendance</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <div class="flex items-center space-x-2 bg-nsklight rounded-full py-2 px-4">
                            <i class="fas fa-search text-gray-500"></i>
                            <input type="text" id="globalSearch" placeholder="Search students..." class="bg-transparent outline-none w-32 md:w-64">
                        </div>
                    </div>
                    
                    <div class="relative">
                        <button id="notificationButton" class="relative">
                            <i class="fas fa-bell text-nsknavy text-xl"></i>
                            <div class="notification-dot"></div>
                        </button>
                    </div>
                    
                    <div class="hidden md:flex items-center space-x-2">
                        <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center text-white font-bold">
                            JA
                        </div>
                        <div>
                            <p class="text-sm font-semibold text-nsknavy">Mr. Johnson Adeyemi</p>
                            <p class="text-xs text-gray-600">Mathematics Teacher</p>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Mobile Header -->
        <header class="mobile-header bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="text-nsknavy">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-xl font-bold text-nsknavy">Attendance</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <button id="notificationButton" class="relative">
                            <i class="fas fa-bell text-nsknavy text-xl"></i>
                            <div class="notification-dot"></div>
                        </button>
                    </div>
                    
                    <div class="flex items-center space-x-2">
                        <div class="w-8 h-8 rounded-full bg-nskgold flex items-center justify-center text-white font-bold text-sm">
                            JA
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Attendance Content -->
        <div class="p-4 md:p-6">
            <div class="bg-white rounded-xl shadow-md p-4 md:p-6">
                <div class="flex flex-col md:flex-row md:justify-between md:items-center mb-4 md:mb-6 space-y-3 md:space-y-0">
                    <h2 class="text-lg md:text-xl font-bold text-nsknavy">Take Attendance</h2>
                    <div class="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
                        <select id="attendanceClassFilter" class="px-3 py-2 border rounded-lg text-sm">
                            <option value="10A">Grade 10A</option>
                            <option value="10B">Grade 10B</option>
                            <option value="11A">Grade 11A</option>
                            <option value="9A">Grade 9A</option>
                        </select>
                        <input type="date" id="attendanceDate" class="px-3 py-2 border rounded-lg text-sm" value="2023-10-10">
                        <button id="saveAttendanceBtn" class="bg-nskgreen text-white px-3 py-2 rounded-lg hover:bg-green-600 transition text-sm">
                            <i class="fas fa-save mr-2"></i>Save Attendance
                        </button>
                        <button id="quickAttendanceBtn" class="bg-nskblue text-white px-3 py-2 rounded-lg hover:bg-nsknavy transition text-sm">
                            <i class="fas fa-bolt mr-2"></i>Quick Mark
                        </button>
                    </div>
                </div>

                <!-- Attendance Summary -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div class="attendance-summary-card summary-present bg-green-50 p-4 rounded-lg">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-2xl font-bold text-nskgreen">28</p>
                                <p class="text-sm text-gray-600">Present</p>
                            </div>
                            <i class="fas fa-check-circle text-nskgreen text-xl"></i>
                        </div>
                    </div>
                    <div class="attendance-summary-card summary-absent bg-red-50 p-4 rounded-lg">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-2xl font-bold text-nskred">2</p>
                                <p class="text-sm text-gray-600">Absent</p>
                            </div>
                            <i class="fas fa-times-circle text-nskred text-xl"></i>
                        </div>
                    </div>
                    <div class="attendance-summary-card summary-late bg-amber-50 p-4 rounded-lg">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-2xl font-bold text-nskgold">1</p>
                                <p class="text-sm text-gray-600">Late</p>
                            </div>
                            <i class="fas fa-clock text-nskgold text-xl"></i>
                        </div>
                    </div>
                    <div class="attendance-summary-card summary-excused bg-gray-100 p-4 rounded-lg">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-2xl font-bold text-gray-600">0</p>
                                <p class="text-sm text-gray-600">Excused</p>
                            </div>
                            <i class="fas fa-user-clock text-gray-600 text-xl"></i>
                        </div>
                    </div>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="min-w-full text-sm md:text-base">
                        <thead>
                            <tr class="bg-gray-50">
                                <th class="py-3 px-3 md:px-6 text-left text-nsknavy font-semibold">Student</th>
                                <th class="py-3 px-3 md:px-6 text-center text-nsknavy font-semibold">Status</th>
                                <th class="py-3 px-3 md:px-6 text-center text-nsknavy font-semibold hidden md:table-cell">Last Attendance</th>
                                <th class="py-3 px-3 md:px-6 text-center text-nsknavy font-semibold">Attendance Rate</th>
                                <th class="py-3 px-3 md:px-6 text-center text-nsknavy font-semibold">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <!-- Student 1 -->
                            <tr class="hover:bg-gray-50">
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex items-center">
                                        <div class="student-avatar bg-nskblue">AI</div>
                                        <div class="ml-3">
                                            <p class="font-semibold text-sm md:text-base">Ahmed Ibrahim</p>
                                            <p class="text-xs text-gray-600">ID: STU-2023-001</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex justify-center space-x-2">
                                        <button class="attendance-btn present active">Present</button>
                                        <button class="attendance-btn absent">Absent</button>
                                        <button class="attendance-btn late">Late</button>
                                        <button class="attendance-btn excused">Excused</button>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6 text-center hidden md:table-cell">
                                    <span class="text-nskgreen font-semibold">Present</span>
                                    <p class="text-xs text-gray-600">Oct 9, 2023</p>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex items-center justify-center">
                                        <div class="w-16 md:w-24 bg-gray-200 rounded-full h-2 mr-2">
                                            <div class="bg-nskgreen h-2 rounded-full" style="width: 95%"></div>
                                        </div>
                                        <span class="text-xs font-semibold">95%</span>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <button class="text-nskblue hover:text-nsknavy">
                                        <i class="fas fa-notes-medical"></i>
                                    </button>
                                </td>
                            </tr>
                            
                            <!-- Student 2 -->
                            <tr class="hover:bg-gray-50">
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex items-center">
                                        <div class="student-avatar bg-nskgreen">FO</div>
                                        <div class="ml-3">
                                            <p class="font-semibold text-sm md:text-base">Fatima Okafor</p>
                                            <p class="text-xs text-gray-600">ID: STU-2023-002</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex justify-center space-x-2">
                                        <button class="attendance-btn present">Present</button>
                                        <button class="attendance-btn absent active">Absent</button>
                                        <button class="attendance-btn late">Late</button>
                                        <button class="attendance-btn excused">Excused</button>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6 text-center hidden md:table-cell">
                                    <span class="text-nskgreen font-semibold">Present</span>
                                    <p class="text-xs text-gray-600">Oct 9, 2023</p>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex items-center justify-center">
                                        <div class="w-16 md:w-24 bg-gray-200 rounded-full h-2 mr-2">
                                            <div class="bg-nskgreen h-2 rounded-full" style="width: 98%"></div>
                                        </div>
                                        <span class="text-xs font-semibold">98%</span>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <button class="text-nskblue hover:text-nsknavy">
                                        <i class="fas fa-notes-medical"></i>
                                    </button>
                                </td>
                            </tr>

                            <!-- Student 3 -->
                            <tr class="hover:bg-gray-50">
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex items-center">
                                        <div class="student-avatar bg-nskgold">CY</div>
                                        <div class="ml-3">
                                            <p class="font-semibold text-sm md:text-base">Chinedu Yusuf</p>
                                            <p class="text-xs text-gray-600">ID: STU-2023-003</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex justify-center space-x-2">
                                        <button class="attendance-btn present">Present</button>
                                        <button class="attendance-btn absent">Absent</button>
                                        <button class="attendance-btn late active">Late</button>
                                        <button class="attendance-btn excused">Excused</button>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6 text-center hidden md:table-cell">
                                    <span class="text-nskgold font-semibold">Late</span>
                                    <p class="text-xs text-gray-600">Oct 9, 2023</p>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex items-center justify-center">
                                        <div class="w-16 md:w-24 bg-gray-200 rounded-full h-2 mr-2">
                                            <div class="bg-nskgold h-2 rounded-full" style="width: 82%"></div>
                                        </div>
                                        <span class="text-xs font-semibold">82%</span>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <button class="text-nskblue hover:text-nsknavy">
                                        <i class="fas fa-notes-medical"></i>
                                    </button>
                                </td>
                            </tr>

                            <!-- Student 4 -->
                            <tr class="hover:bg-gray-50">
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex items-center">
                                        <div class="student-avatar bg-nskred">AA</div>
                                        <div class="ml-3">
                                            <p class="font-semibold text-sm md:text-base">Amina Abdullahi</p>
                                            <p class="text-xs text-gray-600">ID: STU-2023-004</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex justify-center space-x-2">
                                        <button class="attendance-btn present active">Present</button>
                                        <button class="attendance-btn absent">Absent</button>
                                        <button class="attendance-btn late">Late</button>
                                        <button class="attendance-btn excused">Excused</button>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6 text-center hidden md:table-cell">
                                    <span class="text-nskred font-semibold">Absent</span>
                                    <p class="text-xs text-gray-600">Oct 9, 2023</p>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex items-center justify-center">
                                        <div class="w-16 md:w-24 bg-gray-200 rounded-full h-2 mr-2">
                                            <div class="bg-nskred h-2 rounded-full" style="width: 65%"></div>
                                        </div>
                                        <span class="text-xs font-semibold">65%</span>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <button class="text-nskblue hover:text-nsknavy">
                                        <i class="fas fa-notes-medical"></i>
                                    </button>
                                </td>
                            </tr>

                            <!-- Student 5 -->
                            <tr class="hover:bg-gray-50">
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex items-center">
                                        <div class="student-avatar bg-purple-500">SE</div>
                                        <div class="ml-3">
                                            <p class="font-semibold text-sm md:text-base">Samuel Eze</p>
                                            <p class="text-xs text-gray-600">ID: STU-2023-005</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex justify-center space-x-2">
                                        <button class="attendance-btn present active">Present</button>
                                        <button class="attendance-btn absent">Absent</button>
                                        <button class="attendance-btn late">Late</button>
                                        <button class="attendance-btn excused">Excused</button>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6 text-center hidden md:table-cell">
                                    <span class="text-nskgreen font-semibold">Present</span>
                                    <p class="text-xs text-gray-600">Oct 9, 2023</p>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex items-center justify-center">
                                        <div class="w-16 md:w-24 bg-gray-200 rounded-full h-2 mr-2">
                                            <div class="bg-nskgreen h-2 rounded-full" style="width: 96%"></div>
                                        </div>
                                        <span class="text-xs font-semibold">96%</span>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <button class="text-nskblue hover:text-nsknavy">
                                        <i class="fas fa-notes-medical"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="mt-4 md:mt-6 bg-blue-50 p-4 rounded-lg">
                    <div class="flex items-center">
                        <i class="fas fa-info-circle text-nskblue mr-2"></i>
                        <p class="text-sm text-nskblue">Attendance summary: <span class="font-semibold">28 present</span>, <span class="font-semibold">2 absent</span>, <span class="font-semibold">1 late</span>, <span class="font-semibold">0 excused</span> out of 31 students</p>
                    </div>
                </div>
            </div>

            <!-- Attendance Calendar & Reports -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
                <!-- Monthly Calendar -->
                <div class="bg-white rounded-xl shadow-md p-4 md:p-6">
                    <h3 class="text-lg md:text-xl font-bold text-nsknavy mb-4">October 2023</h3>
                    <div class="grid grid-cols-7 gap-1 mb-2">
                        <div class="text-center text-xs font-semibold text-gray-500 py-2">Sun</div>
                        <div class="text-center text-xs font-semibold text-gray-500 py-2">Mon</div>
                        <div class="text-center text-xs font-semibold text-gray-500 py-2">Tue</div>
                        <div class="text-center text-xs font-semibold text-gray-500 py-2">Wed</div>
                        <div class="text-center text-xs font-semibold text-gray-500 py-2">Thu</div>
                        <div class="text-center text-xs font-semibold text-gray-500 py-2">Fri</div>
                        <div class="text-center text-xs font-semibold text-gray-500 py-2">Sat</div>
                    </div>
                    <div class="grid grid-cols-7 gap-1">
                        <!-- Calendar days would be generated dynamically in a real app -->
                        <div class="calendar-day">1</div>
                        <div class="calendar-day">2</div>
                        <div class="calendar-day">3</div>
                        <div class="calendar-day">4</div>
                        <div class="calendar-day">5</div>
                        <div class="calendar-day">6</div>
                        <div class="calendar-day">7</div>
                        <div class="calendar-day">8</div>
                        <div class="calendar-day has-attendance">9</div>
                        <div class="calendar-day active has-attendance">10</div>
                        <div class="calendar-day">11</div>
                        <div class="calendar-day">12</div>
                        <div class="calendar-day">13</div>
                        <div class="calendar-day">14</div>
                        <!-- More days... -->
                    </div>
                    <div class="mt-4 flex items-center space-x-4 text-xs">
                        <div class="flex items-center space-x-1">
                            <div class="w-3 h-3 bg-nskgreen rounded-full"></div>
                            <span>Attendance Taken</span>
                        </div>
                        <div class="flex items-center space-x-1">
                            <div class="w-3 h-3 bg-nskblue rounded-full border-2 border-nskblue"></div>
                            <span>Today</span>
                        </div>
                    </div>
                </div>

                <!-- Attendance Reports -->
                <div class="bg-white rounded-xl shadow-md p-4 md:p-6">
                    <h3 class="text-lg md:text-xl font-bold text-nsknavy mb-4">Attendance Reports</h3>
                    <div class="space-y-4">
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div>
                                <p class="font-semibold text-sm">Weekly Report</p>
                                <p class="text-xs text-gray-600">Oct 2 - Oct 6, 2023</p>
                            </div>
                            <button class="bg-nskblue text-white px-3 py-1 rounded text-xs hover:bg-nsknavy transition">
                                <i class="fas fa-download mr-1"></i>Download
                            </button>
                        </div>
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div>
                                <p class="font-semibold text-sm">Monthly Summary</p>
                                <p class="text-xs text-gray-600">October 2023</p>
                            </div>
                            <button class="bg-nskblue text-white px-3 py-1 rounded text-xs hover:bg-nsknavy transition">
                                <i class="fas fa-download mr-1"></i>Download
                            </button>
                        </div>
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div>
                                <p class="font-semibold text-sm">Student Attendance</p>
                                <p class="text-xs text-gray-600">Individual reports</p>
                            </div>
                            <button class="bg-nskblue text-white px-3 py-1 rounded text-xs hover:bg-nsknavy transition">
                                <i class="fas fa-download mr-1"></i>Generate
                            </button>
                        </div>
                    </div>
                    
                    <div class="mt-6">
                        <h4 class="font-semibold text-nsknavy mb-3">Quick Actions</h4>
                        <div class="grid grid-cols-2 gap-3">
                            <button class="p-3 bg-green-50 rounded-lg hover:bg-green-100 transition text-center">
                                <i class="fas fa-bolt text-nskgreen text-lg mb-1"></i>
                                <p class="text-xs font-semibold text-nskgreen">Mark All Present</p>
                            </button>
                            <button class="p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition text-center">
                                <i class="fas fa-history text-nskblue text-lg mb-1"></i>
                                <p class="text-xs font-semibold text-nskblue">View History</p>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Floating Action Button for Mobile -->
    <button class="floating-btn md:hidden bg-nskblue text-white w-14 h-14 rounded-full shadow-lg flex items-center justify-center">
        <i class="fas fa-plus text-xl"></i>
    </button>

    <!-- Add Note Modal -->
    <div id="noteModal" class="modal">
        <div class="modal-content w-full max-w-md">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg md:text-xl font-bold text-nsknavy">Add Attendance Note</h3>
                <button id="closeNoteModal" class="text-gray-500 hover:text-gray-700">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Student</label>
                    <p class="text-sm font-semibold" id="noteStudentName">Ahmed Ibrahim</p>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Date</label>
                    <p class="text-sm" id="noteDate">October 10, 2023</p>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                    <select class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:border-nskblue">
                        <option>Present</option>
                        <option>Absent</option>
                        <option>Late</option>
                        <option>Excused</option>
                    </select>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Note</label>
                    <textarea rows="4" class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:border-nskblue" placeholder="Add note about this attendance record..."></textarea>
                </div>
                
                <div class="flex justify-end space-x-3 pt-4">
                    <button type="button" id="cancelNote" class="px-4 py-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-100 transition">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-nskgreen text-white rounded-lg text-sm hover:bg-green-600 transition">Save Note</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // DOM Elements
        const sidebar = document.querySelector('.sidebar');
        const mainContent = document.querySelector('.main-content');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const mobileOverlay = document.getElementById('mobileOverlay');
        const attendanceBtns = document.querySelectorAll('.attendance-btn');
        const saveAttendanceBtn = document.getElementById('saveAttendanceBtn');
        const quickAttendanceBtn = document.getElementById('quickAttendanceBtn');
        const noteButtons = document.querySelectorAll('.fa-notes-medical');
        const noteModal = document.getElementById('noteModal');
        const closeNoteModal = document.getElementById('closeNoteModal');
        const cancelNote = document.getElementById('cancelNote');
        const noteStudentName = document.getElementById('noteStudentName');
        const noteDate = document.getElementById('noteDate');
        const attendanceClassFilter = document.getElementById('attendanceClassFilter');
        const attendanceDate = document.getElementById('attendanceDate');

        // Sidebar Toggle Functionality
        function toggleSidebar() {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
            
            const sidebarTexts = document.querySelectorAll('.sidebar-text');
            sidebarTexts.forEach(text => {
                text.classList.toggle('hidden');
            });
        }

        // Mobile Menu Toggle
        function toggleMobileMenu() {
            sidebar.classList.toggle('mobile-show');
            mobileOverlay.classList.toggle('active');
        }

        // Modal Functions
        function openModal(modal) {
            modal.classList.add('active');
        }

        function closeModalFunc(modal) {
            modal.classList.remove('active');
        }

        // Attendance Button Functionality
        function handleAttendanceClick(e) {
            const parent = e.target.closest('td');
            const buttons = parent.querySelectorAll('.attendance-btn');
            
            // Remove active class from all buttons in the group
            buttons.forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Add active class to clicked button
            e.target.classList.add('active');
            
            updateAttendanceSummary();
        }

        // Update attendance summary
        function updateAttendanceSummary() {
            let present = 0, absent = 0, late = 0, excused = 0;
            
            document.querySelectorAll('tbody tr').forEach(row => {
                const activeBtn = row.querySelector('.attendance-btn.active');
                if (activeBtn) {
                    if (activeBtn.classList.contains('present')) present++;
                    else if (activeBtn.classList.contains('absent')) absent++;
                    else if (activeBtn.classList.contains('late')) late++;
                    else if (activeBtn.classList.contains('excused')) excused++;
                }
            });
            
            // Update summary cards (in a real app, this would update the DOM)
            console.log(`Present: ${present}, Absent: ${absent}, Late: ${late}, Excused: ${excused}`);
        }

        // Save attendance
        function handleSaveAttendance() {
            const classValue = attendanceClassFilter.value;
            const dateValue = attendanceDate.value;
            const attendanceData = [];
            
            document.querySelectorAll('tbody tr').forEach(row => {
                const studentName = row.querySelector('td:first-child p.font-semibold').textContent;
                const studentId = row.querySelector('td:first-child p.text-gray-600').textContent.split(': ')[1];
                const status = row.querySelector('.attendance-btn.active').textContent;
                
                attendanceData.push({
                    studentId: studentId,
                    studentName: studentName,
                    status: status,
                    date: dateValue,
                    class: classValue
                });
            });
            
            // In a real app, this would send data to the server
            console.log('Saving attendance:', attendanceData);
            showNotification('Attendance saved successfully!', 'success');
        }

        // Quick mark all present
        function handleQuickMark() {
            document.querySelectorAll('.attendance-btn.present').forEach(btn => {
                const parent = btn.closest('td');
                const buttons = parent.querySelectorAll('.attendance-btn');
                
                buttons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
            });
            
            updateAttendanceSummary();
            showNotification('All students marked as present', 'success');
        }

        // Add note
        function handleAddNote(e) {
            const row = e.target.closest('tr');
            const studentName = row.querySelector('td:first-child p.font-semibold').textContent;
            const date = new Date(attendanceDate.value).toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
            
            noteStudentName.textContent = studentName;
            noteDate.textContent = date;
            openModal(noteModal);
        }

        // Show notification
        function showNotification(message, type) {
            // Create notification element
            const notification = document.createElement('div');
            notification.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
                type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
            }`;
            notification.textContent = message;
            
            document.body.appendChild(notification);
            
            // Remove notification after 3 seconds
            setTimeout(() => {
                notification.remove();
            }, 3000);
        }

        // Event Listeners
        sidebarToggle.addEventListener('click', toggleSidebar);
        mobileMenuToggle.addEventListener('click', toggleMobileMenu);
        mobileOverlay.addEventListener('click', toggleMobileMenu);

        // Attendance buttons
        attendanceBtns.forEach(btn => {
            btn.addEventListener('click', handleAttendanceClick);
        });

        // Action buttons
        saveAttendanceBtn.addEventListener('click', handleSaveAttendance);
        quickAttendanceBtn.addEventListener('click', handleQuickMark);

        // Note buttons
        noteButtons.forEach(btn => {
            btn.addEventListener('click', handleAddNote);
        });

        // Note modal
        closeNoteModal.addEventListener('click', () => closeModalFunc(noteModal));
        cancelNote.addEventListener('click', () => closeModalFunc(noteModal));

        // Close modal when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === noteModal) {
                closeModalFunc(noteModal);
            }
        });

        // Set current date
        document.addEventListener('DOMContentLoaded', () => {
            const today = new Date();
            const formattedDate = today.toISOString().split('T')[0];
            attendanceDate.value = formattedDate;
            
            console.log('Attendance page loaded successfully');
        });

        // Responsive adjustments
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) {
                sidebar.classList.remove('mobile-show');
                mobileOverlay.classList.remove('active');
            }
        });
    </script>
</body>
</html>