<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Northland Schools Kano</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        nskblue: '#1e40af',
                        nsklightblue: '#3b82f6',
                        nsknavy: '#1e3a8a',
                        nskgold: '#f59e0b',
                        nsklight: '#f0f9ff',
                        nskgreen: '#10b981',
                        nskred: '#ef4444'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap');
        
        :root {
            --sidebar-width: 250px;
            --sidebar-collapsed-width: 80px;
            --transition-speed: 0.3s;
        }
        
        body {
            font-family: 'Montserrat', sans-serif;
            background: #f8fafc;
        }
        
        .logo-container {
            background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%);
        }
        
        .dashboard-card {
            transition: transform var(--transition-speed) ease, box-shadow var(--transition-speed) ease;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }
        
        .sidebar {
            transition: all var(--transition-speed) ease;
            width: var(--sidebar-width);
        }
        
        .sidebar.collapsed {
            width: var(--sidebar-collapsed-width);
        }
        
        .main-content {
            transition: all var(--transition-speed) ease;
            margin-left: var(--sidebar-width);
            width: calc(100% - var(--sidebar-width));
        }
        
        .main-content.expanded {
            margin-left: var(--sidebar-collapsed-width);
            width: calc(100% - var(--sidebar-collapsed-width));
        }
        
        @media (max-width: 768px) {
            .sidebar {
                margin-left: calc(-1 * var(--sidebar-width));
                z-index: 20;
            }
            
            .sidebar.mobile-show {
                margin-left: 0;
            }
            
            .main-content {
                margin-left: 0;
                width: 100%;
            }
            
            .mobile-overlay {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                z-index: 15;
            }
            
            .mobile-overlay.active {
                display: block;
            }
        }
        
        .notification-dot {
            position: absolute;
            top: -5px;
            right: -5px;
            width: 12px;
            height: 12px;
            background-color: #ef4444;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        .floating-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
            transition: transform 0.3s ease;
        }
        
        .floating-btn:hover {
            transform: scale(1.1);
        }
        
        .sidebar-link.active {
            background-color: #1e40af !important;
        }
        
        .mobile-header {
            display: none;
        }
        
        @media (max-width: 768px) {
            .mobile-header {
                display: flex;
            }
            
            .desktop-header {
                display: none;
            }
        }
    </style>
</head>
<body class="flex">
    <!-- Mobile Overlay -->
    <div class="mobile-overlay" id="mobileOverlay"></div>

    <!-- Sidebar Navigation -->
    <aside class="sidebar bg-nsknavy text-white h-screen fixed top-0 left-0 z-10">
        <div class="p-5">
            <div class="flex items-center justify-between mb-10">
                <div class="flex items-center space-x-2">
                    <div class="logo-container w-10 h-10 rounded-full flex items-center justify-center text-white font-bold">
                        NSK
                    </div>
                    <h1 class="text-xl font-bold sidebar-text">NORTHLAND SCHOOLS</h1>
                </div>
                <button id="sidebarToggle" class="text-white">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            
            <nav class="space-y-2">
                <a href="index.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg bg-nskblue transition active">
                    <i class="fas fa-tachometer-alt mr-3"></i> <span class="sidebar-text">Dashboard</span>
                </a>
                <a href="my-classes.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-chalkboard mr-3"></i> <span class="sidebar-text">My Classes</span>
                </a>
                <a href="students.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-user-graduate mr-3"></i> <span class="sidebar-text">Students</span>
                </a>
                <!-- <a href="gradebook.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-book-open mr-3"></i> <span class="sidebar-text">Gradebook</span>
                </a> -->
                <a href="assignments.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-tasks mr-3"></i> <span class="sidebar-text">Assignments</span>
                </a>
                <a href="attendance.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-clipboard-check mr-3"></i> <span class="sidebar-text">Attendance</span>
                </a>
                <a href="results.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-chart-bar mr-3"></i> <span class="sidebar-text">Results</span>
                </a>
                <!-- <a href="messages.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-comments mr-3"></i> <span class="sidebar-text">Messages</span>
                </a> -->
            </nav>
        </div>
        
        <div class="absolute bottom-0 w-full p-5">
            <div class="flex items-center space-x-3 bg-nskblue p-3 rounded-lg">
                <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center">
                    <span class="font-bold">JA</span>
                </div>
                <div class="sidebar-text">
                    <p class="text-sm font-semibold">Mr. Johnson Adeyemi</p>
                    <p class="text-xs opacity-80">Mathematics Teacher</p>
                </div>
            </div>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Desktop Header -->
        <header class="desktop-header bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="md:hidden text-nsknavy">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold text-nsknavy">Dashboard</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <div class="flex items-center space-x-2 bg-nsklight rounded-full py-2 px-4">
                            <i class="fas fa-search text-gray-500"></i>
                            <input type="text" id="globalSearch" placeholder="Search students..." class="bg-transparent outline-none w-32 md:w-64">
                        </div>
                    </div>
                    
                    <div class="relative">
                        <button id="notificationButton" class="relative">
                            <i class="fas fa-bell text-nsknavy text-xl"></i>
                            <div class="notification-dot"></div>
                        </button>
                    </div>
                    
                    <div class="hidden md:flex items-center space-x-2">
                        <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center text-white font-bold">
                            JA
                        </div>
                        <div>
                            <p class="text-sm font-semibold text-nsknavy">Mr. Johnson Adeyemi</p>
                            <p class="text-xs text-gray-600">Mathematics Teacher</p>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Mobile Header -->
        <header class="mobile-header bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="text-nsknavy">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-xl font-bold text-nsknavy">Dashboard</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <button id="notificationButton" class="relative">
                            <i class="fas fa-bell text-nsknavy text-xl"></i>
                            <div class="notification-dot"></div>
                        </button>
                    </div>
                    
                    <div class="flex items-center space-x-2">
                        <div class="w-8 h-8 rounded-full bg-nskgold flex items-center justify-center text-white font-bold text-sm">
                            JA
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Dashboard Content -->
        <div class="p-4 md:p-6">
            <!-- Quick Stats -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-6 md:mb-8">
                <div class="dashboard-card bg-white rounded-xl shadow-md p-4 md:p-5 flex items-center">
                    <div class="bg-nsklightblue p-3 md:p-4 rounded-full mr-3 md:mr-4">
                        <i class="fas fa-chalkboard text-white text-lg md:text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600 text-sm md:text-base">My Classes</p>
                        <p class="text-xl md:text-2xl font-bold text-nsknavy">5</p>
                        <p class="text-xs text-nskgreen"><i class="fas fa-arrow-up"></i> Active classes</p>
                    </div>
                </div>
                
                <div class="dashboard-card bg-white rounded-xl shadow-md p-4 md:p-5 flex items-center">
                    <div class="bg-nskgreen p-3 md:p-4 rounded-full mr-3 md:mr-4">
                        <i class="fas fa-user-graduate text-white text-lg md:text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600 text-sm md:text-base">Total Students</p>
                        <p class="text-xl md:text-2xl font-bold text-nsknavy">142</p>
                        <p class="text-xs text-gray-600">Across all classes</p>
                    </div>
                </div>
                
                <div class="dashboard-card bg-white rounded-xl shadow-md p-4 md:p-5 flex items-center">
                    <div class="bg-nskgold p-3 md:p-4 rounded-full mr-3 md:mr-4">
                        <i class="fas fa-tasks text-white text-lg md:text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600 text-sm md:text-base">Assignments</p>
                        <p class="text-xl md:text-2xl font-bold text-nsknavy">8</p>
                        <p class="text-xs text-nskred">3 pending review</p>
                    </div>
                </div>
                
                <div class="dashboard-card bg-white rounded-xl shadow-md p-4 md:p-5 flex items-center">
                    <div class="bg-nskred p-3 md:p-4 rounded-full mr-3 md:mr-4">
                        <i class="fas fa-clock text-white text-lg md:text-xl"></i>
                    </div>
                    <div>
                        <p class="text-gray-600 text-sm md:text-base">Today's Classes</p>
                        <p class="text-xl md:text-2xl font-bold text-nsknavy">4</p>
                        <p class="text-xs text-nskblue">Next: 10:30 AM</p>
                    </div>
                </div>
            </div>

            <!-- Today's Schedule & Quick Actions -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6 mb-6 md:mb-8">
                <!-- Today's Schedule -->
                <div class="bg-white rounded-xl shadow-md p-4 md:p-6">
                    <h3 class="text-lg md:text-xl font-bold text-nsknavy mb-4">Today's Schedule</h3>
                    <div class="space-y-3 md:space-y-4">
                        <div class="flex items-center p-3 bg-blue-50 rounded-lg border-l-4 border-nskblue">
                            <div class="flex-shrink-0 w-14 md:w-16 text-center">
                                <p class="text-sm font-bold text-nskblue">08:00</p>
                                <p class="text-xs text-gray-600">AM</p>
                            </div>
                            <div class="ml-3 md:ml-4 flex-1">
                                <p class="font-semibold text-sm md:text-base">Mathematics - Grade 10A</p>
                                <p class="text-xs md:text-sm text-gray-600">Room 201 • 45 minutes</p>
                            </div>
                            <div class="text-nskgreen">
                                <i class="fas fa-check-circle"></i>
                            </div>
                        </div>
                        
                        <div class="flex items-center p-3 bg-green-50 rounded-lg border-l-4 border-nskgreen">
                            <div class="flex-shrink-0 w-14 md:w-16 text-center">
                                <p class="text-sm font-bold text-nskgreen">10:30</p>
                                <p class="text-xs text-gray-600">AM</p>
                            </div>
                            <div class="ml-3 md:ml-4 flex-1">
                                <p class="font-semibold text-sm md:text-base">Further Mathematics - Grade 11A</p>
                                <p class="text-xs md:text-sm text-gray-600">Room 201 • 45 minutes</p>
                            </div>
                            <div class="text-nskblue">
                                <i class="fas fa-clock"></i>
                            </div>
                        </div>
                        
                        <div class="flex items-center p-3 bg-gray-50 rounded-lg border-l-4 border-gray-300">
                            <div class="flex-shrink-0 w-14 md:w-16 text-center">
                                <p class="text-sm font-bold text-gray-600">02:00</p>
                                <p class="text-xs text-gray-600">PM</p>
                            </div>
                            <div class="ml-3 md:ml-4 flex-1">
                                <p class="font-semibold text-sm md:text-base">Mathematics - Grade 10B</p>
                                <p class="text-xs md:text-sm text-gray-600">Room 201 • 45 minutes</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="bg-white rounded-xl shadow-md p-4 md:p-6">
                    <h3 class="text-lg md:text-xl font-bold text-nsknavy mb-4">Quick Actions</h3>
                    <div class="grid grid-cols-2 gap-3 md:gap-4">
                        <a href="attendance.html" class="p-3 md:p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition text-center">
                            <i class="fas fa-clipboard-check text-nskblue text-xl md:text-2xl mb-2"></i>
                            <p class="font-semibold text-nskblue text-sm md:text-base">Take Attendance</p>
                        </a>
                        
                        <a href="gradebook.html" class="p-3 md:p-4 bg-green-50 rounded-lg hover:bg-green-100 transition text-center">
                            <i class="fas fa-book-open text-nskgreen text-xl md:text-2xl mb-2"></i>
                            <p class="font-semibold text-nskgreen text-sm md:text-base">Grade Book</p>
                        </a>
                        
                        <a href="assignments.html" class="p-3 md:p-4 bg-amber-50 rounded-lg hover:bg-amber-100 transition text-center">
                            <i class="fas fa-tasks text-nskgold text-xl md:text-2xl mb-2"></i>
                            <p class="font-semibold text-nskgold text-sm md:text-base">New Assignment</p>
                        </a>
                        
                        <a href="messages.html" class="p-3 md:p-4 bg-red-50 rounded-lg hover:bg-red-100 transition text-center">
                            <i class="fas fa-comments text-nskred text-xl md:text-2xl mb-2"></i>
                            <p class="font-semibold text-nskred text-sm md:text-base">Send Message</p>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Recent Activity & Class Performance -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
                <!-- Recent Activity -->
                <div class="bg-white rounded-xl shadow-md p-4 md:p-6">
                    <h3 class="text-lg md:text-xl font-bold text-nsknavy mb-4">Recent Activity</h3>
                    <div class="space-y-3 md:space-y-4">
                        <div class="flex items-start space-x-3">
                            <div class="w-7 h-7 md:w-8 md:h-8 bg-nskgreen rounded-full flex items-center justify-center">
                                <i class="fas fa-check text-white text-xs"></i>
                            </div>
                            <div>
                                <p class="text-sm font-semibold">Assignment graded</p>
                                <p class="text-xs text-gray-600">Mathematics Quiz - Grade 10A • 2 hours ago</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start space-x-3">
                            <div class="w-7 h-7 md:w-8 md:h-8 bg-nskblue rounded-full flex items-center justify-center">
                                <i class="fas fa-clipboard-check text-white text-xs"></i>
                            </div>
                            <div>
                                <p class="text-sm font-semibold">Attendance recorded</p>
                                <p class="text-xs text-gray-600">Grade 11A - 28/30 present • 4 hours ago</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start space-x-3">
                            <div class="w-7 h-7 md:w-8 md:h-8 bg-nskgold rounded-full flex items-center justify-center">
                                <i class="fas fa-message text-white text-xs"></i>
                            </div>
                            <div>
                                <p class="text-sm font-semibold">Parent message</p>
                                <p class="text-xs text-gray-600">Mrs. Ibrahim about Ahmed's progress • 1 day ago</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Class Summary Overview -->
                <div class="bg-white rounded-xl shadow-md p-4 md:p-6">
                    <h3 class="text-lg md:text-xl font-bold text-nsknavy mb-4">Class Summary</h3>
                    <div class="space-y-3 md:space-y-4">
                        <div class="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                            <div>
                                <p class="font-semibold text-nskblue text-sm md:text-base">Grade 10A Mathematics</p>
                                <p class="text-xs md:text-sm text-gray-600">30 students • Average: 85%</p>
                            </div>
                            <div class="text-right">
                                <p class="text-sm font-bold text-nskgreen">93% Attendance</p>
                                <p class="text-xs text-gray-600">This week</p>
                            </div>
                        </div>
                        
                        <div class="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                            <div>
                                <p class="font-semibold text-nskgreen text-sm md:text-base">Grade 10B Mathematics</p>
                                <p class="text-xs md:text-sm text-gray-600">28 students • Average: 78%</p>
                            </div>
                            <div class="text-right">
                                <p class="text-sm font-bold text-nskblue">89% Attendance</p>
                                <p class="text-xs text-gray-600">This week</p>
                            </div>
                        </div>
                        
                        <div class="flex items-center justify-between p-3 bg-amber-50 rounded-lg">
                            <div>
                                <p class="font-semibold text-nskgold text-sm md:text-base">Grade 11A Further Math</p>
                                <p class="text-xs md:text-sm text-gray-600">25 students • Average: 91%</p>
                            </div>
                            <div class="text-right">
                                <p class="text-sm font-bold text-nskgreen">96% Attendance</p>
                                <p class="text-xs text-gray-600">This week</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Floating Action Button for Mobile -->
    <button class="floating-btn md:hidden bg-nskblue text-white w-14 h-14 rounded-full shadow-lg flex items-center justify-center">
        <i class="fas fa-plus text-xl"></i>
    </button>

    <script>
        // DOM Elements
        const sidebar = document.querySelector('.sidebar');
        const mainContent = document.querySelector('.main-content');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const mobileOverlay = document.getElementById('mobileOverlay');

        // Sidebar Toggle Functionality
        function toggleSidebar() {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
            
            // Toggle sidebar text visibility
            const sidebarTexts = document.querySelectorAll('.sidebar-text');
            sidebarTexts.forEach(text => {
                text.classList.toggle('hidden');
            });
        }

        // Mobile Menu Toggle
        function toggleMobileMenu() {
            sidebar.classList.toggle('mobile-show');
            mobileOverlay.classList.toggle('active');
        }

        // Event Listeners
        sidebarToggle.addEventListener('click', toggleSidebar);
        mobileMenuToggle.addEventListener('click', toggleMobileMenu);
        mobileOverlay.addEventListener('click', toggleMobileMenu);

        // Responsive adjustments
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) {
                // Ensure sidebar is visible on larger screens
                sidebar.classList.remove('mobile-show');
                mobileOverlay.classList.remove('active');
            }
        });

        // Initialize the dashboard
        document.addEventListener('DOMContentLoaded', () => {
            console.log('Dashboard loaded successfully');
        });
    </script>
</body>
</html>