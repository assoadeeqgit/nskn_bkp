<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terminal Results - Northland Schools Kano</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        nskblue: '#1e40af',
                        nsklightblue: '#3b82f6',
                        nsknavy: '#1e3a8a',
                        nskgold: '#f59e0b',
                        nsklight: '#f0f9ff',
                        nskgreen: '#10b981',
                        nskred: '#ef4444'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap');
        
        :root {
            --sidebar-width: 250px;
            --sidebar-collapsed-width: 80px;
            --transition-speed: 0.3s;
        }
        
        body {
            font-family: 'Montserrat', sans-serif;
            background: #f8fafc;
        }
        
        .logo-container {
            background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%);
        }
        
        .dashboard-card {
            transition: transform var(--transition-speed) ease, box-shadow var(--transition-speed) ease;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }
        
        .sidebar {
            transition: all var(--transition-speed) ease;
            width: var(--sidebar-width);
        }
        
        .sidebar.collapsed {
            width: var(--sidebar-collapsed-width);
        }
        
        .main-content {
            transition: all var(--transition-speed) ease;
            margin-left: var(--sidebar-width);
            width: calc(100% - var(--sidebar-width));
        }
        
        .main-content.expanded {
            margin-left: var(--sidebar-collapsed-width);
            width: calc(100% - var(--sidebar-collapsed-width));
        }
        
        @media (max-width: 768px) {
            .sidebar {
                margin-left: calc(-1 * var(--sidebar-width));
                z-index: 20;
            }
            
            .sidebar.mobile-show {
                margin-left: 0;
            }
            
            .main-content {
                margin-left: 0;
                width: 100%;
            }
            
            .mobile-overlay {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                z-index: 15;
            }
            
            .mobile-overlay.active {
                display: block;
            }
        }
        
        .notification-dot {
            position: absolute;
            top: -5px;
            right: -5px;
            width: 12px;
            height: 12px;
            background-color: #ef4444;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        .floating-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
            transition: transform 0.3s ease;
        }
        
        .floating-btn:hover {
            transform: scale(1.1);
        }
        
        .sidebar-link.active {
            background-color: #1e40af !important;
        }
        
        .mobile-header {
            display: none;
        }
        
        @media (max-width: 768px) {
            .mobile-header {
                display: flex;
            }
            
            .desktop-header {
                display: none;
            }
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            backdrop-filter: blur(5px);
        }
        
        .modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s ease;
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            max-width: 90%;
            max-height: 90%;
            overflow-y: auto;
            transform: scale(0.9);
            transition: transform 0.3s ease;
        }
        
        .modal.active .modal-content {
            transform: scale(1);
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .upload-area {
            border: 2px dashed #d1d5db;
            border-radius: 12px;
            padding: 3rem 2rem;
            text-align: center;
            transition: all 0.3s ease;
            background-color: #f9fafb;
        }
        
        .upload-area:hover {
            border-color: #3b82f6;
            background-color: #eff6ff;
        }
        
        .upload-area.dragover {
            border-color: #3b82f6;
            background-color: #dbeafe;
        }
        
        .file-list-item {
            transition: all 0.3s ease;
        }
        
        .file-list-item:hover {
            background-color: #f8fafc;
        }
        
        .progress-bar {
            height: 8px;
            background-color: #e5e7eb;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            border-radius: 4px;
            transition: width 0.3s ease;
            background: linear-gradient(90deg, #10b981, #3b82f6);
        }
        
        .template-card {
            border-left: 4px solid;
            transition: all 0.3s ease;
        }
        
        .template-card:hover {
            transform: translateX(5px);
        }
        
        .template-early-years { border-left-color: #3b82f6; }
        .template-primary { border-left-color: #10b981; }
        .template-secondary { border-left-color: #8b5cf6; }
    </style>
</head>
<body class="flex">
    <!-- Mobile Overlay -->
    <div class="mobile-overlay" id="mobileOverlay"></div>

    <!-- Sidebar Navigation -->
    <aside class="sidebar bg-nsknavy text-white h-screen fixed top-0 left-0 z-10">
        <div class="p-5">
            <div class="flex items-center justify-between mb-10">
                <div class="flex items-center space-x-2">
                    <div class="logo-container w-10 h-10 rounded-full flex items-center justify-center text-white font-bold">
                        NSK
                    </div>
                    <h1 class="text-xl font-bold sidebar-text">NORTHLAND SCHOOLS</h1>
                </div>
                <button id="sidebarToggle" class="text-white">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            
            <nav class="space-y-2">
                <a href="teacher dashboard.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-tachometer-alt mr-3"></i> <span class="sidebar-text">Dashboard</span>
                </a>
                <a href="my-classes.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-chalkboard mr-3"></i> <span class="sidebar-text">My Classes</span>
                </a>
                <a href="my-students.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-user-graduate mr-3"></i> <span class="sidebar-text">Students</span>
                </a>
                <!-- <a href="gradebook.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-book-open mr-3"></i> <span class="sidebar-text">Gradebook</span>
                </a> -->
                <a href="assignments.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-tasks mr-3"></i> <span class="sidebar-text">Assignments</span>
                </a>
                <a href="attendance.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-clipboard-check mr-3"></i> <span class="sidebar-text">Attendance</span>
                </a>
                <a href="results.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg bg-nskblue transition active">
                    <i class="fas fa-chart-bar mr-3"></i> <span class="sidebar-text">Terminal Results</span>
                </a>
                <!-- <a href="messages.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-comments mr-3"></i> <span class="sidebar-text">Messages</span>
                </a> -->
            </nav>
        </div>
        
        <div class="absolute bottom-0 w-full p-5">
            <div class="flex items-center space-x-3 bg-nskblue p-3 rounded-lg">
                <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center">
                    <span class="font-bold">JA</span>
                </div>
                <div class="sidebar-text">
                    <p class="text-sm font-semibold">Mr. Johnson Adeyemi</p>
                    <p class="text-xs opacity-80">Mathematics Teacher</p>
                </div>
            </div>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Desktop Header -->
        <header class="desktop-header bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="md:hidden text-nsknavy">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold text-nsknavy">Terminal Results - Excel Upload</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <div class="flex items-center space-x-2 bg-nsklight rounded-full py-2 px-4">
                            <i class="fas fa-search text-gray-500"></i>
                            <input type="text" id="globalSearch" placeholder="Search results..." class="bg-transparent outline-none w-32 md:w-64">
                        </div>
                    </div>
                    
                    <div class="relative">
                        <button id="notificationButton" class="relative">
                            <i class="fas fa-bell text-nsknavy text-xl"></i>
                            <div class="notification-dot"></div>
                        </button>
                    </div>
                    
                    <div class="hidden md:flex items-center space-x-2">
                        <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center text-white font-bold">
                            JA
                        </div>
                        <div>
                            <p class="text-sm font-semibold text-nsknavy">Mr. Johnson Adeyemi</p>
                            <p class="text-xs text-gray-600">Mathematics Teacher</p>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Mobile Header -->
        <header class="mobile-header bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="text-nsknavy">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-xl font-bold text-nsknavy">Excel Results Upload</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <button id="notificationButton" class="relative">
                            <i class="fas fa-bell text-nsknavy text-xl"></i>
                            <div class="notification-dot"></div>
                        </button>
                    </div>
                    
                    <div class="flex items-center space-x-2">
                        <div class="w-8 h-8 rounded-full bg-nskgold flex items-center justify-center text-white font-bold text-sm">
                            JA
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Excel Upload Content -->
        <div class="p-4 md:p-6">
            <!-- Upload Process Steps -->
            <div class="bg-white rounded-xl shadow-md p-6 mb-6">
                <h2 class="text-xl font-bold text-nsknavy mb-6">Excel Results Upload Process</h2>
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                    <div class="text-center p-4 bg-blue-50 rounded-lg">
                        <div class="w-10 h-10 bg-nskblue rounded-full flex items-center justify-center text-white font-bold mx-auto mb-2">1</div>
                        <p class="font-semibold text-nskblue">Download Template</p>
                        <p class="text-sm text-gray-600">Get the correct Excel template</p>
                    </div>
                    <div class="text-center p-4 bg-green-50 rounded-lg">
                        <div class="w-10 h-10 bg-nskgreen rounded-full flex items-center justify-center text-white font-bold mx-auto mb-2">2</div>
                        <p class="font-semibold text-nskgreen">Fill Results</p>
                        <p class="text-sm text-gray-600">Enter student scores in Excel</p>
                    </div>
                    <div class="text-center p-4 bg-amber-50 rounded-lg">
                        <div class="w-10 h-10 bg-nskgold rounded-full flex items-center justify-center text-white font-bold mx-auto mb-2">3</div>
                        <p class="font-semibold text-nskgold">Upload File</p>
                        <p class="text-sm text-gray-600">Upload completed Excel file</p>
                    </div>
                    <div class="text-center p-4 bg-purple-50 rounded-lg">
                        <div class="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold mx-auto mb-2">4</div>
                        <p class="font-semibold text-purple-600">Review & Publish</p>
                        <p class="text-sm text-gray-600">Verify and publish results</p>
                    </div>
                </div>

                <!-- Excel Templates Section -->
                <div class="mb-8">
                    <h3 class="text-lg font-bold text-nsknavy mb-4">Download Excel Templates</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="template-card template-early-years bg-white border border-gray-200 rounded-lg p-4 hover:shadow-lg cursor-pointer" data-template="early-years">
                            <div class="flex items-center justify-between mb-3">
                                <h4 class="font-bold text-nsknavy">Early Years Template</h4>
                                <i class="fas fa-download text-nskblue"></i>
                            </div>
                            <p class="text-sm text-gray-600 mb-3">Pre-Nursery to KG 2 with skills assessment grading</p>
                            <div class="flex items-center text-xs text-gray-500">
                                <i class="fas fa-file-excel text-green-500 mr-2"></i>
                                <span>Excel Template • 15KB</span>
                            </div>
                        </div>
                        
                        <div class="template-card template-primary bg-white border border-gray-200 rounded-lg p-4 hover:shadow-lg cursor-pointer" data-template="primary">
                            <div class="flex items-center justify-between mb-3">
                                <h4 class="font-bold text-nsknavy">Primary School Template</h4>
                                <i class="fas fa-download text-nskgreen"></i>
                            </div>
                            <p class="text-sm text-gray-600 mb-3">Grade 1-6 with subject percentage scoring</p>
                            <div class="flex items-center text-xs text-gray-500">
                                <i class="fas fa-file-excel text-green-500 mr-2"></i>
                                <span>Excel Template • 18KB</span>
                            </div>
                        </div>
                        
                        <div class="template-card template-secondary bg-white border border-gray-200 rounded-lg p-4 hover:shadow-lg cursor-pointer" data-template="secondary">
                            <div class="flex items-center justify-between mb-3">
                                <h4 class="font-bold text-nsknavy">Secondary School Template</h4>
                                <i class="fas fa-download text-purple-600"></i>
                            </div>
                            <p class="text-sm text-gray-600 mb-3">Grade 7-12 with detailed subject breakdown</p>
                            <div class="flex items-center text-xs text-gray-500">
                                <i class="fas fa-file-excel text-green-500 mr-2"></i>
                                <span>Excel Template • 22KB</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- File Upload Section -->
                <div class="mb-8">
                    <h3 class="text-lg font-bold text-nsknavy mb-4">Upload Completed Excel File</h3>
                    <div class="upload-area" id="uploadArea">
                        <i class="fas fa-file-excel text-green-500 text-4xl mb-4"></i>
                        <h4 class="text-lg font-semibold text-gray-700 mb-2">Upload Excel Results File</h4>
                        <p class="text-gray-600 mb-4">Drag and drop your Excel file here or click to browse</p>
                        <input type="file" id="excelFile" accept=".xlsx, .xls" class="hidden">
                        <button id="browseFilesBtn" class="bg-nskblue text-white px-6 py-2 rounded-lg hover:bg-nsknavy transition">
                            <i class="fas fa-upload mr-2"></i>Browse Files
                        </button>
                        <p class="text-xs text-gray-500 mt-3">Supported formats: .xlsx, .xls (Max: 10MB)</p>
                    </div>
                    
                    <!-- Uploaded Files List -->
                    <div id="fileList" class="mt-4 space-y-2 hidden">
                        <div class="file-list-item bg-gray-50 p-4 rounded-lg flex items-center justify-between">
                            <div class="flex items-center space-x-3">
                                <i class="fas fa-file-excel text-green-500 text-xl"></i>
                                <div>
                                    <p class="font-semibold" id="fileName">results.xlsx</p>
                                    <p class="text-sm text-gray-600" id="fileSize">245 KB</p>
                                </div>
                            </div>
                            <div class="flex items-center space-x-2">
                                <span class="bg-green-100 text-nskgreen px-2 py-1 rounded-full text-xs font-semibold">Ready to Process</span>
                                <button class="text-nskred hover:text-red-700">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Processing Options -->
                <div class="bg-gray-50 p-4 rounded-lg">
                    <h3 class="text-lg font-bold text-nsknavy mb-4">Processing Options</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Academic Session</label>
                            <select class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:border-nskblue">
                                <option>2023/2024 Academic Session</option>
                                <option>2022/2023 Academic Session</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Term</label>
                            <select class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:border-nskblue">
                                <option>Third Term</option>
                                <option>Second Term</option>
                                <option>First Term</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Class/Section</label>
                            <select class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:border-nskblue">
                                <option>Grade 10A - Mathematics</option>
                                <option>Grade 10B - Mathematics</option>
                                <option>Grade 11A - Further Mathematics</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Action</label>
                            <select class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:border-nskblue">
                                <option>Process and Save Results</option>
                                <option>Process and Preview Only</option>
                                <option>Validate Data Only</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="flex items-center space-x-4 mt-4">
                        <input type="checkbox" id="autoCalculate" class="rounded border-gray-300" checked>
                        <label for="autoCalculate" class="text-sm text-gray-700">Auto-calculate totals and averages</label>
                    </div>
                    
                    <div class="flex items-center space-x-4 mt-2">
                        <input type="checkbox" id="updateGradebook" class="rounded border-gray-300">
                        <label for="updateGradebook" class="text-sm text-gray-700">Update gradebook with these results</label>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="flex justify-end space-x-4 mt-6">
                    <button id="validateDataBtn" class="bg-nskgold text-white px-6 py-2 rounded-lg hover:bg-amber-600 transition">
                        <i class="fas fa-check-circle mr-2"></i>Validate Data
                    </button>
                    <button id="processResultsBtn" class="bg-nskgreen text-white px-6 py-2 rounded-lg hover:bg-green-600 transition">
                        <i class="fas fa-cogs mr-2"></i>Process Results
                    </button>
                </div>
            </div>

            <!-- Processing Progress -->
            <div id="processingSection" class="bg-white rounded-xl shadow-md p-6 mb-6 hidden">
                <h3 class="text-lg font-bold text-nsknavy mb-4">Processing Results</h3>
                <div class="space-y-4">
                    <div>
                        <div class="flex justify-between text-sm mb-1">
                            <span>Reading Excel file...</span>
                            <span>25%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: 25%"></div>
                        </div>
                    </div>
                    
                    <div>
                        <div class="flex justify-between text-sm mb-1">
                            <span>Validating data...</span>
                            <span>0%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: 0%"></div>
                        </div>
                    </div>
                    
                    <div>
                        <div class="flex justify-between text-sm mb-1">
                            <span>Calculating totals...</span>
                            <span>0%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: 0%"></div>
                        </div>
                    </div>
                    
                    <div>
                        <div class="flex justify-between text-sm mb-1">
                            <span>Saving to database...</span>
                            <span>0%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: 0%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Results Preview -->
            <div id="previewSection" class="bg-white rounded-xl shadow-md p-6 hidden">
                <h3 class="text-lg font-bold text-nsknavy mb-4">Results Preview</h3>
                <div class="overflow-x-auto">
                    <table class="min-w-full text-sm">
                        <thead>
                            <tr class="bg-gray-50">
                                <th class="py-3 px-4 text-left text-nsknavy font-semibold">Student ID</th>
                                <th class="py-3 px-4 text-left text-nsknavy font-semibold">Name</th>
                                <th class="py-3 px-4 text-center text-nsknavy font-semibold">Mathematics</th>
                                <th class="py-3 px-4 text-center text-nsknavy font-semibold">English</th>
                                <th class="py-3 px-4 text-center text-nsknavy font-semibold">Science</th>
                                <th class="py-3 px-4 text-center text-nsknavy font-semibold">Total</th>
                                <th class="py-3 px-4 text-center text-nsknavy font-semibold">Average</th>
                                <th class="py-3 px-4 text-center text-nsknavy font-semibold">Grade</th>
                            </tr>
                        </thead>
                        <tbody id="previewTableBody">
                            <!-- Preview data will be inserted here -->
                        </tbody>
                    </table>
                </div>
                
                <div class="flex justify-end space-x-4 mt-6">
                    <button class="border border-gray-300 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-50 transition">
                        <i class="fas fa-edit mr-2"></i>Edit Data
                    </button>
                    <button class="bg-nskblue text-white px-6 py-2 rounded-lg hover:bg-nsknavy transition">
                        <i class="fas fa-save mr-2"></i>Save Results
                    </button>
                </div>
            </div>

            <!-- Upload History -->
            <div class="bg-white rounded-xl shadow-md p-6">
                <h3 class="text-lg font-bold text-nsknavy mb-4">Recent Uploads</h3>
                <div class="space-y-3">
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <i class="fas fa-file-excel text-green-500 text-xl"></i>
                            <div>
                                <p class="font-semibold">Grade 10A - Third Term Results</p>
                                <p class="text-sm text-gray-600">Uploaded: Oct 15, 2023 • 30 students processed</p>
                            </div>
                        </div>
                        <span class="bg-green-100 text-nskgreen px-2 py-1 rounded-full text-xs font-semibold">Completed</span>
                    </div>
                    
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div class="flex items-center space-x-3">
                            <i class="fas fa-file-excel text-green-500 text-xl"></i>
                            <div>
                                <p class="font-semibold">Grade 11A - Second Term Results</p>
                                <p class="text-sm text-gray-600">Uploaded: Jul 20, 2023 • 25 students processed</p>
                            </div>
                        </div>
                        <span class="bg-green-100 text-nskgreen px-2 py-1 rounded-full text-xs font-semibold">Completed</span>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script>
        // DOM Elements
        const sidebar = document.querySelector('.sidebar');
        const mainContent = document.querySelector('.main-content');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const mobileOverlay = document.getElementById('mobileOverlay');
        const uploadArea = document.getElementById('uploadArea');
        const excelFileInput = document.getElementById('excelFile');
        const browseFilesBtn = document.getElementById('browseFilesBtn');
        const fileList = document.getElementById('fileList');
        const validateDataBtn = document.getElementById('validateDataBtn');
        const processResultsBtn = document.getElementById('processResultsBtn');
        const processingSection = document.getElementById('processingSection');
        const previewSection = document.getElementById('previewSection');
        const previewTableBody = document.getElementById('previewTableBody');
        const templateCards = document.querySelectorAll('.template-card');

        // Sidebar Toggle Functionality
        function toggleSidebar() {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
            
            const sidebarTexts = document.querySelectorAll('.sidebar-text');
            sidebarTexts.forEach(text => {
                text.classList.toggle('hidden');
            });
        }

        // Mobile Menu Toggle
        function toggleMobileMenu() {
            sidebar.classList.toggle('mobile-show');
            mobileOverlay.classList.toggle('active');
        }

        // File Upload Handling
        function handleFileSelect(file) {
            if (file) {
                const fileName = file.name;
                const fileSize = (file.size / 1024).toFixed(2) + ' KB';
                
                // Update file list
                document.getElementById('fileName').textContent = fileName;
                document.getElementById('fileSize').textContent = fileSize;
                fileList.classList.remove('hidden');
                
                // Validate file type
                const validTypes = ['.xlsx', '.xls'];
                const fileExtension = fileName.substring(fileName.lastIndexOf('.')).toLowerCase();
                
                if (!validTypes.includes(fileExtension)) {
                    showNotification('Please upload a valid Excel file (.xlsx or .xls)', 'error');
                    return;
                }
                
                showNotification('File uploaded successfully! Ready for processing.', 'success');
                
                // Process the Excel file
                processExcelFile(file);
            }
        }

        // Process Excel File
        function processExcelFile(file) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                
                // Get first worksheet
                const worksheet = workbook.Sheets[workbook.SheetNames[0]];
                const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                
                // Show processing section
                processingSection.classList.remove('hidden');
                
                // Simulate processing
                simulateProcessing(jsonData);
            };
            
            reader.readAsArrayBuffer(file);
        }

        // Simulate processing with progress
        function simulateProcessing(data) {
            let progress = 0;
            const progressBars = document.querySelectorAll('.progress-fill');
            
            const interval = setInterval(() => {
                progress += 5;
                
                // Update progress bars
                progressBars.forEach((bar, index) => {
                    const baseProgress = index * 25;
                    const currentProgress = Math.min(baseProgress + progress, (index + 1) * 25);
                    bar.style.width = currentProgress + '%';
                    
                    // Update percentage text
                    const percentageText = bar.parentElement.previousElementSibling.querySelector('span:last-child');
                    percentageText.textContent = currentProgress + '%';
                });
                
                if (progress >= 100) {
                    clearInterval(interval);
                    showPreview(data);
                }
            }, 100);
        }

        // Show preview of processed data
        function showPreview(data) {
            processingSection.classList.add('hidden');
            previewSection.classList.remove('hidden');
            
            // Clear previous preview
            previewTableBody.innerHTML = '';
            
            // Add sample preview data (in real app, this would come from Excel)
            const sampleData = [
                { id: 'STU-001', name: 'Ahmed Ibrahim', math: 85, english: 78, science: 92, total: 255, average: 85, grade: 'B+' },
                { id: 'STU-002', name: 'Fatima Okafor', math: 92, english: 88, science: 95, total: 275, average: 91.7, grade: 'A' },
                { id: 'STU-003', name: 'Chinedu Yusuf', math: 72, english: 68, science: 75, total: 215, average: 71.7, grade: 'C' }
            ];
            
            sampleData.forEach(student => {
                const row = document.createElement('tr');
                row.className = 'hover:bg-gray-50';
                row.innerHTML = `
                    <td class="py-3 px-4">${student.id}</td>
                    <td class="py-3 px-4 font-semibold">${student.name}</td>
                    <td class="py-3 px-4 text-center">${student.math}</td>
                    <td class="py-3 px-4 text-center">${student.english}</td>
                    <td class="py-3 px-4 text-center">${student.science}</td>
                    <td class="py-3 px-4 text-center font-semibold">${student.total}</td>
                    <td class="py-3 px-4 text-center font-semibold text-nskgreen">${student.average}%</td>
                    <td class="py-3 px-4 text-center">
                        <span class="px-2 py-1 rounded-full text-xs font-semibold ${student.average >= 90 ? 'bg-green-100 text-green-800' : student.average >= 80 ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800'}">${student.grade}</span>
                    </td>
                `;
                previewTableBody.appendChild(row);
            });
            
            showNotification('Results processed successfully! Review and save.', 'success');
        }

        // Download template
        function downloadTemplate(section) {
            const templates = {
                'early-years': 'early_years_template.xlsx',
                'primary': 'primary_school_template.xlsx',
                'secondary': 'secondary_school_template.xlsx'
            };
            
            const filename = templates[section];
            showNotification(`Downloading ${filename} template...`, 'success');
            
            // In a real app, this would trigger a file download
            console.log(`Downloading template: ${filename}`);
        }

        // Show notification
        function showNotification(message, type) {
            // Create notification element
            const notification = document.createElement('div');
            notification.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
                type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
            }`;
            notification.textContent = message;
            
            document.body.appendChild(notification);
            
            // Remove notification after 3 seconds
            setTimeout(() => {
                notification.remove();
            }, 3000);
        }

        // Event Listeners
        sidebarToggle.addEventListener('click', toggleSidebar);
        mobileMenuToggle.addEventListener('click', toggleMobileMenu);
        mobileOverlay.addEventListener('click', toggleMobileMenu);

        // File upload events
        browseFilesBtn.addEventListener('click', () => excelFileInput.click());
        excelFileInput.addEventListener('change', (e) => handleFileSelect(e.target.files[0]));

        // Drag and drop functionality
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });

        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            const file = e.dataTransfer.files[0];
            handleFileSelect(file);
        });

        // Template download events
        templateCards.forEach(card => {
            card.addEventListener('click', () => downloadTemplate(card.dataset.template));
        });

        // Action buttons
        validateDataBtn.addEventListener('click', () => {
            showNotification('Validating Excel data structure...', 'success');
        });

        processResultsBtn.addEventListener('click', () => {
            if (!excelFileInput.files[0]) {
                showNotification('Please upload an Excel file first', 'error');
                return;
            }
            handleFileSelect(excelFileInput.files[0]);
        });

        // Initialize the page
        document.addEventListener('DOMContentLoaded', () => {
            console.log('Excel Results Upload page loaded successfully');
        });

        // Responsive adjustments
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) {
                sidebar.classList.remove('mobile-show');
                mobileOverlay.classList.remove('active');
            }
        });
    </script>
</body>
</html>