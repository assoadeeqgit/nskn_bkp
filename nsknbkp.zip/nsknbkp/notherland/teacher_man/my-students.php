<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students - Northland Schools Kano</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        nskblue: '#1e40af',
                        nsklightblue: '#3b82f6',
                        nsknavy: '#1e3a8a',
                        nskgold: '#f59e0b',
                        nsklight: '#f0f9ff',
                        nskgreen: '#10b981',
                        nskred: '#ef4444'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap');
        
        :root {
            --sidebar-width: 250px;
            --sidebar-collapsed-width: 80px;
            --transition-speed: 0.3s;
        }
        
        body {
            font-family: 'Montserrat', sans-serif;
            background: #f8fafc;
        }
        
        .logo-container {
            background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%);
        }
        
        .dashboard-card {
            transition: transform var(--transition-speed) ease, box-shadow var(--transition-speed) ease;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }
        
        .sidebar {
            transition: all var(--transition-speed) ease;
            width: var(--sidebar-width);
        }
        
        .sidebar.collapsed {
            width: var(--sidebar-collapsed-width);
        }
        
        .main-content {
            transition: all var(--transition-speed) ease;
            margin-left: var(--sidebar-width);
            width: calc(100% - var(--sidebar-width));
        }
        
        .main-content.expanded {
            margin-left: var(--sidebar-collapsed-width);
            width: calc(100% - var(--sidebar-collapsed-width));
        }
        
        @media (max-width: 768px) {
            .sidebar {
                margin-left: calc(-1 * var(--sidebar-width));
                z-index: 20;
            }
            
            .sidebar.mobile-show {
                margin-left: 0;
            }
            
            .main-content {
                margin-left: 0;
                width: 100%;
            }
            
            .mobile-overlay {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                z-index: 15;
            }
            
            .mobile-overlay.active {
                display: block;
            }
        }
        
        .notification-dot {
            position: absolute;
            top: -5px;
            right: -5px;
            width: 12px;
            height: 12px;
            background-color: #ef4444;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        .floating-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
            transition: transform 0.3s ease;
        }
        
        .floating-btn:hover {
            transform: scale(1.1);
        }
        
        .sidebar-link.active {
            background-color: #1e40af !important;
        }
        
        .mobile-header {
            display: none;
        }
        
        @media (max-width: 768px) {
            .mobile-header {
                display: flex;
            }
            
            .desktop-header {
                display: none;
            }
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            backdrop-filter: blur(5px);
        }
        
        .modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s ease;
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            max-width: 90%;
            max-height: 90%;
            overflow-y: auto;
            transform: scale(0.9);
            transition: transform 0.3s ease;
        }
        
        .modal.active .modal-content {
            transform: scale(1);
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .student-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 14px;
        }
    </style>
</head>
<body class="flex">
    <!-- Mobile Overlay -->
    <div class="mobile-overlay" id="mobileOverlay"></div>

    <!-- Sidebar Navigation -->
    <aside class="sidebar bg-nsknavy text-white h-screen fixed top-0 left-0 z-10">
        <div class="p-5">
            <div class="flex items-center justify-between mb-10">
                <div class="flex items-center space-x-2">
                    <div class="logo-container w-10 h-10 rounded-full flex items-center justify-center text-white font-bold">
                        NSK
                    </div>
                    <h1 class="text-xl font-bold sidebar-text">NORTHLAND SCHOOLS</h1>
                </div>
                <button id="sidebarToggle" class="text-white">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            
            <nav class="space-y-2">
                <a href="teacher dashboard.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-tachometer-alt mr-3"></i> <span class="sidebar-text">Dashboard</span>
                </a>
                <a href="my-classes.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-chalkboard mr-3"></i> <span class="sidebar-text">My Classes</span>
                </a>
                <a href="my-students.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg bg-nskblue transition active">
                    <i class="fas fa-user-graduate mr-3"></i> <span class="sidebar-text">Students</span>
                </a>
                <!-- <a href="gradebook.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-book-open mr-3"></i> <span class="sidebar-text">Gradebook</span>
                </a> -->
                <a href="assignments.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-tasks mr-3"></i> <span class="sidebar-text">Assignments</span>
                </a>
                <a href="attendance.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-clipboard-check mr-3"></i> <span class="sidebar-text">Attendance</span>
                </a>
                <a href="results.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-chart-bar mr-3"></i> <span class="sidebar-text">Results</span>
                </a>
                <!-- <a href="messages.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-comments mr-3"></i> <span class="sidebar-text">Messages</span>
                </a> -->
            </nav>
        </div>
        
        <div class="absolute bottom-0 w-full p-5">
            <div class="flex items-center space-x-3 bg-nskblue p-3 rounded-lg">
                <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center">
                    <span class="font-bold">JA</span>
                </div>
                <div class="sidebar-text">
                    <p class="text-sm font-semibold">Mr. Johnson Adeyemi</p>
                    <p class="text-xs opacity-80">Mathematics Teacher</p>
                </div>
            </div>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Desktop Header -->
        <header class="desktop-header bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="md:hidden text-nsknavy">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold text-nsknavy">Students</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <div class="flex items-center space-x-2 bg-nsklight rounded-full py-2 px-4">
                            <i class="fas fa-search text-gray-500"></i>
                            <input type="text" id="globalSearch" placeholder="Search students..." class="bg-transparent outline-none w-32 md:w-64">
                        </div>
                    </div>
                    
                    <div class="relative">
                        <button id="notificationButton" class="relative">
                            <i class="fas fa-bell text-nsknavy text-xl"></i>
                            <div class="notification-dot"></div>
                        </button>
                    </div>
                    
                    <div class="hidden md:flex items-center space-x-2">
                        <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center text-white font-bold">
                            JA
                        </div>
                        <div>
                            <p class="text-sm font-semibold text-nsknavy">Mr. Johnson Adeyemi</p>
                            <p class="text-xs text-gray-600">Mathematics Teacher</p>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Mobile Header -->
        <header class="mobile-header bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="text-nsknavy">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-xl font-bold text-nsknavy">Students</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <button id="notificationButton" class="relative">
                            <i class="fas fa-bell text-nsknavy text-xl"></i>
                            <div class="notification-dot"></div>
                        </button>
                    </div>
                    
                    <div class="flex items-center space-x-2">
                        <div class="w-8 h-8 rounded-full bg-nskgold flex items-center justify-center text-white font-bold text-sm">
                            JA
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Students Content -->
        <div class="p-4 md:p-6">
            <div class="bg-white rounded-xl shadow-md p-4 md:p-6">
                <div class="flex flex-col md:flex-row md:justify-between md:items-center mb-4 md:mb-6 space-y-3 md:space-y-0">
                    <h2 class="text-lg md:text-xl font-bold text-nsknavy">My Students</h2>
                    <div class="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
                        <select id="classFilter" class="px-3 py-2 border rounded-lg text-sm">
                            <option value="">All Classes</option>
                            <option value="10A">Grade 10A</option>
                            <option value="10B">Grade 10B</option>
                            <option value="11A">Grade 11A</option>
                            <option value="9A">Grade 9A</option>
                        </select>
                        <button id="exportStudentBtn" class="bg-nskgold text-white px-3 py-2 rounded-lg hover:bg-amber-600 transition text-sm">
                            <i class="fas fa-download mr-2"></i>Export
                        </button>
                        <button id="addStudentBtn" class="bg-nskgreen text-white px-3 py-2 rounded-lg hover:bg-green-600 transition text-sm">
                            <i class="fas fa-plus mr-2"></i>Add Student
                        </button>
                    </div>
                </div>
                
                <!-- Student Statistics -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
                    <div class="text-center">
                        <div class="text-xl md:text-2xl font-bold text-nskblue">142</div>
                        <p class="text-xs text-gray-600">Total Students</p>
                    </div>
                    <div class="text-center">
                        <div class="text-xl md:text-2xl font-bold text-nskgreen">89%</div>
                        <p class="text-xs text-gray-600">Average Attendance</p>
                    </div>
                    <div class="text-center">
                        <div class="text-xl md:text-2xl font-bold text-nskgold">84%</div>
                        <p class="text-xs text-gray-600">Overall Average</p>
                    </div>
                    <div class="text-center">
                        <div class="text-xl md:text-2xl font-bold text-nskred">8</div>
                        <p class="text-xs text-gray-600">Need Attention</p>
                    </div>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="min-w-full text-sm md:text-base">
                        <thead>
                            <tr class="bg-gray-50">
                                <th class="py-3 px-3 md:px-6 text-left text-nsknavy font-semibold">Student</th>
                                <th class="py-3 px-3 md:px-6 text-left text-nsknavy font-semibold hidden sm:table-cell">Class</th>
                                <th class="py-3 px-3 md:px-6 text-left text-nsknavy font-semibold">Grade</th>
                                <th class="py-3 px-3 md:px-6 text-left text-nsknavy font-semibold hidden md:table-cell">Attendance</th>
                                <th class="py-3 px-3 md:px-6 text-left text-nsknavy font-semibold">Status</th>
                                <th class="py-3 px-3 md:px-6 text-left text-nsknavy font-semibold">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <!-- Student 1 -->
                            <tr class="hover:bg-gray-50">
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex items-center">
                                        <div class="student-avatar bg-nskblue">AI</div>
                                        <div class="ml-3">
                                            <p class="font-semibold text-sm md:text-base">Ahmed Ibrahim</p>
                                            <p class="text-xs text-gray-600">ID: STU-2023-001</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6 hidden sm:table-cell">
                                    <span class="bg-blue-100 text-nskblue px-2 py-1 rounded-full text-xs font-semibold">Grade 10A</span>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <span class="text-nskgreen font-bold">87%</span>
                                    <p class="text-xs text-gray-600 hidden md:block">B+ Average</p>
                                </td>
                                <td class="py-4 px-3 md:px-6 hidden md:table-cell">
                                    <div class="flex items-center">
                                        <div class="w-16 md:w-24 bg-gray-200 rounded-full h-2 mr-2">
                                            <div class="bg-nskgreen h-2 rounded-full" style="width: 95%"></div>
                                        </div>
                                        <span class="text-xs font-semibold">95%</span>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <span class="bg-green-100 text-nskgreen px-2 py-1 rounded-full text-xs font-semibold">Excellent</span>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex space-x-2">
                                        <button class="view-student text-nskblue hover:text-nsknavy" data-student="STU-2023-001">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="text-nskgreen hover:text-green-700">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="text-nskred hover:text-red-700">
                                            <i class="fas fa-comment"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            
                            <!-- Student 2 -->
                            <tr class="hover:bg-gray-50">
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex items-center">
                                        <div class="student-avatar bg-nskgreen">FO</div>
                                        <div class="ml-3">
                                            <p class="font-semibold text-sm md:text-base">Fatima Okafor</p>
                                            <p class="text-xs text-gray-600">ID: STU-2023-002</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6 hidden sm:table-cell">
                                    <span class="bg-green-100 text-nskgreen px-2 py-1 rounded-full text-xs font-semibold">Grade 10B</span>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <span class="text-nskgreen font-bold">92%</span>
                                    <p class="text-xs text-gray-600 hidden md:block">A Average</p>
                                </td>
                                <td class="py-4 px-3 md:px-6 hidden md:table-cell">
                                    <div class="flex items-center">
                                        <div class="w-16 md:w-24 bg-gray-200 rounded-full h-2 mr-2">
                                            <div class="bg-nskgreen h-2 rounded-full" style="width: 98%"></div>
                                        </div>
                                        <span class="text-xs font-semibold">98%</span>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <span class="bg-green-100 text-nskgreen px-2 py-1 rounded-full text-xs font-semibold">Excellent</span>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex space-x-2">
                                        <button class="view-student text-nskblue hover:text-nsknavy" data-student="STU-2023-002">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="text-nskgreen hover:text-green-700">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="text-nskred hover:text-red-700">
                                            <i class="fas fa-comment"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <!-- Student 3 -->
                            <tr class="hover:bg-gray-50">
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex items-center">
                                        <div class="student-avatar bg-nskgold">CY</div>
                                        <div class="ml-3">
                                            <p class="font-semibold text-sm md:text-base">Chinedu Yusuf</p>
                                            <p class="text-xs text-gray-600">ID: STU-2023-003</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6 hidden sm:table-cell">
                                    <span class="bg-blue-100 text-nskblue px-2 py-1 rounded-full text-xs font-semibold">Grade 10A</span>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <span class="text-nskgold font-bold">75%</span>
                                    <p class="text-xs text-gray-600 hidden md:block">C+ Average</p>
                                </td>
                                <td class="py-4 px-3 md:px-6 hidden md:table-cell">
                                    <div class="flex items-center">
                                        <div class="w-16 md:w-24 bg-gray-200 rounded-full h-2 mr-2">
                                            <div class="bg-nskgold h-2 rounded-full" style="width: 82%"></div>
                                        </div>
                                        <span class="text-xs font-semibold">82%</span>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <span class="bg-amber-100 text-nskgold px-2 py-1 rounded-full text-xs font-semibold">Needs Help</span>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex space-x-2">
                                        <button class="view-student text-nskblue hover:text-nsknavy" data-student="STU-2023-003">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="text-nskgreen hover:text-green-700">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="text-nskred hover:text-red-700">
                                            <i class="fas fa-comment"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <!-- Student 4 -->
                            <tr class="hover:bg-gray-50">
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex items-center">
                                        <div class="student-avatar bg-nskred">AA</div>
                                        <div class="ml-3">
                                            <p class="font-semibold text-sm md:text-base">Amina Abdullahi</p>
                                            <p class="text-xs text-gray-600">ID: STU-2023-004</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6 hidden sm:table-cell">
                                    <span class="bg-green-100 text-nskgreen px-2 py-1 rounded-full text-xs font-semibold">Grade 10B</span>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <span class="text-nskred font-bold">68%</span>
                                    <p class="text-xs text-gray-600 hidden md:block">D+ Average</p>
                                </td>
                                <td class="py-4 px-3 md:px-6 hidden md:table-cell">
                                    <div class="flex items-center">
                                        <div class="w-16 md:w-24 bg-gray-200 rounded-full h-2 mr-2">
                                            <div class="bg-nskred h-2 rounded-full" style="width: 65%"></div>
                                        </div>
                                        <span class="text-xs font-semibold">65%</span>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <span class="bg-red-100 text-nskred px-2 py-1 rounded-full text-xs font-semibold">At Risk</span>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex space-x-2">
                                        <button class="view-student text-nskblue hover:text-nsknavy" data-student="STU-2023-004">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="text-nskgreen hover:text-green-700">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="text-nskred hover:text-red-700">
                                            <i class="fas fa-comment"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <!-- Student 5 -->
                            <tr class="hover:bg-gray-50">
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex items-center">
                                        <div class="student-avatar bg-purple-500">SE</div>
                                        <div class="ml-3">
                                            <p class="font-semibold text-sm md:text-base">Samuel Eze</p>
                                            <p class="text-xs text-gray-600">ID: STU-2023-005</p>
                                        </div>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6 hidden sm:table-cell">
                                    <span class="bg-amber-100 text-nskgold px-2 py-1 rounded-full text-xs font-semibold">Grade 11A</span>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <span class="text-nskgreen font-bold">94%</span>
                                    <p class="text-xs text-gray-600 hidden md:block">A Average</p>
                                </td>
                                <td class="py-4 px-3 md:px-6 hidden md:table-cell">
                                    <div class="flex items-center">
                                        <div class="w-16 md:w-24 bg-gray-200 rounded-full h-2 mr-2">
                                            <div class="bg-nskgreen h-2 rounded-full" style="width: 96%"></div>
                                        </div>
                                        <span class="text-xs font-semibold">96%</span>
                                    </div>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <span class="bg-green-100 text-nskgreen px-2 py-1 rounded-full text-xs font-semibold">Excellent</span>
                                </td>
                                <td class="py-4 px-3 md:px-6">
                                    <div class="flex space-x-2">
                                        <button class="view-student text-nskblue hover:text-nsknavy" data-student="STU-2023-005">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="text-nskgreen hover:text-green-700">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="text-nskred hover:text-red-700">
                                            <i class="fas fa-comment"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="flex justify-between items-center mt-4 md:mt-6">
                    <p class="text-sm text-gray-600">Showing 5 of 142 students</p>
                    <div class="flex space-x-2">
                        <button class="px-3 py-1 bg-gray-200 rounded-lg text-sm hover:bg-gray-300 transition">Previous</button>
                        <button class="px-3 py-1 bg-nskblue text-white rounded-lg text-sm hover:bg-nsknavy transition">Next</button>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Floating Action Button for Mobile -->
    <button class="floating-btn md:hidden bg-nskblue text-white w-14 h-14 rounded-full shadow-lg flex items-center justify-center">
        <i class="fas fa-plus text-xl"></i>
    </button>

    <!-- Student Details Modal -->
    <div id="studentModal" class="modal">
        <div class="modal-content w-full max-w-4xl">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg md:text-xl font-bold text-nsknavy" id="modalStudentTitle">Student Details</h3>
                <button id="closeStudentModal" class="text-gray-500 hover:text-gray-700">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="space-y-6">
                <div class="flex items-center space-x-4">
                    <div class="student-avatar bg-nskblue text-2xl w-16 h-16">AI</div>
                    <div>
                        <h4 class="font-bold text-lg" id="modalStudentName">Ahmed Ibrahim</h4>
                        <p class="text-gray-600" id="modalStudentId">ID: STU-2023-001</p>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div class="bg-blue-50 p-4 rounded-lg">
                        <h4 class="font-semibold text-nskblue mb-2">Personal Information</h4>
                        <p class="text-sm"><strong>Class:</strong> Grade 10A</p>
                        <p class="text-sm"><strong>Gender:</strong> Male</p>
                        <p class="text-sm"><strong>Age:</strong> 15</p>
                    </div>
                    <div class="bg-green-50 p-4 rounded-lg">
                        <h4 class="font-semibold text-nskgreen mb-2">Academic Performance</h4>
                        <p class="text-sm"><strong>Average Grade:</strong> 87%</p>
                        <p class="text-sm"><strong>Attendance Rate:</strong> 95%</p>
                        <p class="text-sm"><strong>Assignments:</strong> 8/8 completed</p>
                    </div>
                    <div class="bg-amber-50 p-4 rounded-lg">
                        <h4 class="font-semibold text-nskgold mb-2">Contact Information</h4>
                        <p class="text-sm"><strong>Parent:</strong> Mrs. Ibrahim</p>
                        <p class="text-sm"><strong>Phone:</strong> +234 801 234 5678</p>
                        <p class="text-sm"><strong>Email:</strong> parent@email.com</p>
                    </div>
                </div>
                
                <div>
                    <h4 class="font-semibold text-nsknavy mb-3">Recent Grades</h4>
                    <div class="space-y-2">
                        <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <span class="text-sm">Algebra Quiz</span>
                            <span class="text-sm font-semibold text-nskgreen">85%</span>
                        </div>
                        <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <span class="text-sm">Geometry Worksheet</span>
                            <span class="text-sm font-semibold text-nskgreen">88%</span>
                        </div>
                        <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <span class="text-sm">Midterm Exam</span>
                            <span class="text-sm font-semibold text-nskgreen">90%</span>
                        </div>
                    </div>
                </div>
                
                <div class="flex justify-end space-x-3 pt-4">
                    <button id="closeModal" class="px-4 py-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-100 transition">Close</button>
                    <button class="px-4 py-2 bg-nskblue text-white rounded-lg text-sm hover:bg-nsknavy transition">Send Message</button>
                    <button class="px-4 py-2 bg-nskgreen text-white rounded-lg text-sm hover:bg-green-600 transition">View Full Profile</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        // DOM Elements
        const sidebar = document.querySelector('.sidebar');
        const mainContent = document.querySelector('.main-content');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const mobileOverlay = document.getElementById('mobileOverlay');
        const viewStudentBtns = document.querySelectorAll('.view-student');
        const studentModal = document.getElementById('studentModal');
        const closeStudentModal = document.getElementById('closeStudentModal');
        const closeModal = document.getElementById('closeModal');
        const modalStudentTitle = document.getElementById('modalStudentTitle');
        const modalStudentName = document.getElementById('modalStudentName');
        const modalStudentId = document.getElementById('modalStudentId');
        const classFilter = document.getElementById('classFilter');

        // Sidebar Toggle Functionality
        function toggleSidebar() {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
            
            const sidebarTexts = document.querySelectorAll('.sidebar-text');
            sidebarTexts.forEach(text => {
                text.classList.toggle('hidden');
            });
        }

        // Mobile Menu Toggle
        function toggleMobileMenu() {
            sidebar.classList.toggle('mobile-show');
            mobileOverlay.classList.toggle('active');
        }

        // Modal Functions
        function openModal(modal) {
            modal.classList.add('active');
        }

        function closeModalFunc(modal) {
            modal.classList.remove('active');
        }

        // View Student Details
        function handleViewStudent(e) {
            const studentId = e.target.closest('button').getAttribute('data-student');
            const studentRow = e.target.closest('tr');
            const studentName = studentRow.querySelector('td:first-child p.font-semibold').textContent;
            const studentClass = studentRow.querySelector('td:nth-child(2) span').textContent;
            
            modalStudentTitle.textContent = `Student Details - ${studentName}`;
            modalStudentName.textContent = studentName;
            modalStudentId.textContent = `ID: ${studentId}`;
            
            openModal(studentModal);
        }

        // Filter students by class
        function handleClassFilter() {
            const selectedClass = classFilter.value;
            const rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const rowClass = row.querySelector('td:nth-child(2) span').textContent;
                if (!selectedClass || rowClass.includes(selectedClass)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        // Event Listeners
        sidebarToggle.addEventListener('click', toggleSidebar);
        mobileMenuToggle.addEventListener('click', toggleMobileMenu);
        mobileOverlay.addEventListener('click', toggleMobileMenu);

        // Student buttons
        viewStudentBtns.forEach(btn => {
            btn.addEventListener('click', handleViewStudent);
        });

        // Filter
        classFilter.addEventListener('change', handleClassFilter);

        // Modal close buttons
        closeStudentModal.addEventListener('click', () => closeModalFunc(studentModal));
        closeModal.addEventListener('click', () => closeModalFunc(studentModal));

        // Close modal when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === studentModal) {
                closeModalFunc(studentModal);
            }
        });

        // Responsive adjustments
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) {
                sidebar.classList.remove('mobile-show');
                mobileOverlay.classList.remove('active');
            }
        });

        // Initialize the page
        document.addEventListener('DOMContentLoaded', () => {
            console.log('Students page loaded successfully');
        });
    </script>
</body>
</html>
