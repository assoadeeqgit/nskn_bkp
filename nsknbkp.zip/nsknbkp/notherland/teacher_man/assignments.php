<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignments - Northland Schools Kano</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        nskblue: '#1e40af',
                        nsklightblue: '#3b82f6',
                        nsknavy: '#1e3a8a',
                        nskgold: '#f59e0b',
                        nsklight: '#f0f9ff',
                        nskgreen: '#10b981',
                        nskred: '#ef4444'
                    }
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap');
        
        :root {
            --sidebar-width: 250px;
            --sidebar-collapsed-width: 80px;
            --transition-speed: 0.3s;
        }
        
        body {
            font-family: 'Montserrat', sans-serif;
            background: #f8fafc;
        }
        
        .logo-container {
            background: linear-gradient(135deg, #1e40af 0%, #1e3a8a 100%);
        }
        
        .dashboard-card {
            transition: transform var(--transition-speed) ease, box-shadow var(--transition-speed) ease;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }
        
        .sidebar {
            transition: all var(--transition-speed) ease;
            width: var(--sidebar-width);
        }
        
        .sidebar.collapsed {
            width: var(--sidebar-collapsed-width);
        }
        
        .main-content {
            transition: all var(--transition-speed) ease;
            margin-left: var(--sidebar-width);
            width: calc(100% - var(--sidebar-width));
        }
        
        .main-content.expanded {
            margin-left: var(--sidebar-collapsed-width);
            width: calc(100% - var(--sidebar-collapsed-width));
        }
        
        @media (max-width: 768px) {
            .sidebar {
                margin-left: calc(-1 * var(--sidebar-width));
                z-index: 20;
            }
            
            .sidebar.mobile-show {
                margin-left: 0;
            }
            
            .main-content {
                margin-left: 0;
                width: 100%;
            }
            
            .mobile-overlay {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                z-index: 15;
            }
            
            .mobile-overlay.active {
                display: block;
            }
        }
        
        .notification-dot {
            position: absolute;
            top: -5px;
            right: -5px;
            width: 12px;
            height: 12px;
            background-color: #ef4444;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        .floating-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
            transition: transform 0.3s ease;
        }
        
        .floating-btn:hover {
            transform: scale(1.1);
        }
        
        .sidebar-link.active {
            background-color: #1e40af !important;
        }
        
        .mobile-header {
            display: none;
        }
        
        @media (max-width: 768px) {
            .mobile-header {
                display: flex;
            }
            
            .desktop-header {
                display: none;
            }
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            backdrop-filter: blur(5px);
        }
        
        .modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s ease;
        }
        
        .modal-content {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            max-width: 90%;
            max-height: 90%;
            overflow-y: auto;
            transform: scale(0.9);
            transition: transform 0.3s ease;
        }
        
        .modal.active .modal-content {
            transform: scale(1);
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .progress-bar {
            height: 8px;
            background-color: #e5e7eb;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            border-radius: 4px;
            transition: width 0.3s ease;
        }
        
        .status-active { background-color: #10b981; }
        .status-upcoming { background-color: #3b82f6; }
        .status-overdue { background-color: #ef4444; }
        .status-completed { background-color: #6b7280; }
        
        .assignment-card {
            border-left: 4px solid;
        }
        
        .assignment-active { border-left-color: #10b981; }
        .assignment-upcoming { border-left-color: #3b82f6; }
        .assignment-overdue { border-left-color: #ef4444; }
        .assignment-completed { border-left-color: #6b7280; }
    </style>
</head>
<body class="flex">
    <!-- Mobile Overlay -->
    <div class="mobile-overlay" id="mobileOverlay"></div>

    <!-- Sidebar Navigation -->
    <aside class="sidebar bg-nsknavy text-white h-screen fixed top-0 left-0 z-10">
        <div class="p-5">
            <div class="flex items-center justify-between mb-10">
                <div class="flex items-center space-x-2">
                    <div class="logo-container w-10 h-10 rounded-full flex items-center justify-center text-white font-bold">
                        NSK
                    </div>
                    <h1 class="text-xl font-bold sidebar-text">NORTHLAND SCHOOLS</h1>
                </div>
                <button id="sidebarToggle" class="text-white">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
            
            <nav class="space-y-2">
                <a href="index.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-tachometer-alt mr-3"></i> <span class="sidebar-text">Dashboard</span>
                </a>
                <a href="classes.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-chalkboard mr-3"></i> <span class="sidebar-text">My Classes</span>
                </a>
                <a href="students.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-user-graduate mr-3"></i> <span class="sidebar-text">Students</span>
                </a>
                <!-- <a href="gradebook.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-book-open mr-3"></i> <span class="sidebar-text">Gradebook</span>
                </a> -->
                <a href="assignments.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg bg-nskblue transition active">
                    <i class="fas fa-tasks mr-3"></i> <span class="sidebar-text">Assignments</span>
                </a>
                <a href="attendance.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-clipboard-check mr-3"></i> <span class="sidebar-text">Attendance</span>
                </a>
                <a href="results.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-chart-bar mr-3"></i> <span class="sidebar-text">Results</span>
                </a>
                <!-- <a href="messages.html" class="nav-link sidebar-link block py-3 px-4 rounded-lg hover:bg-nskblue transition">
                    <i class="fas fa-comments mr-3"></i> <span class="sidebar-text">Messages</span>
                </a> -->
            </nav>
        </div>
        
        <div class="absolute bottom-0 w-full p-5">
            <div class="flex items-center space-x-3 bg-nskblue p-3 rounded-lg">
                <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center">
                    <span class="font-bold">JA</span>
                </div>
                <div class="sidebar-text">
                    <p class="text-sm font-semibold">Mr. Johnson Adeyemi</p>
                    <p class="text-xs opacity-80">Mathematics Teacher</p>
                </div>
            </div>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Desktop Header -->
        <header class="desktop-header bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="md:hidden text-nsknavy">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold text-nsknavy">Assignments</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <div class="flex items-center space-x-2 bg-nsklight rounded-full py-2 px-4">
                            <i class="fas fa-search text-gray-500"></i>
                            <input type="text" id="globalSearch" placeholder="Search assignments..." class="bg-transparent outline-none w-32 md:w-64">
                        </div>
                    </div>
                    
                    <div class="relative">
                        <button id="notificationButton" class="relative">
                            <i class="fas fa-bell text-nsknavy text-xl"></i>
                            <div class="notification-dot"></div>
                        </button>
                    </div>
                    
                    <div class="hidden md:flex items-center space-x-2">
                        <div class="w-10 h-10 rounded-full bg-nskgold flex items-center justify-center text-white font-bold">
                            JA
                        </div>
                        <div>
                            <p class="text-sm font-semibold text-nsknavy">Mr. Johnson Adeyemi</p>
                            <p class="text-xs text-gray-600">Mathematics Teacher</p>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Mobile Header -->
        <header class="mobile-header bg-white shadow-md p-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <button id="mobileMenuToggle" class="text-nsknavy">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-xl font-bold text-nsknavy">Assignments</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <button id="notificationButton" class="relative">
                            <i class="fas fa-bell text-nsknavy text-xl"></i>
                            <div class="notification-dot"></div>
                        </button>
                    </div>
                    
                    <div class="flex items-center space-x-2">
                        <div class="w-8 h-8 rounded-full bg-nskgold flex items-center justify-center text-white font-bold text-sm">
                            JA
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Assignments Content -->
        <div class="p-4 md:p-6">
            <div class="bg-white rounded-xl shadow-md p-4 md:p-6">
                <div class="flex flex-col md:flex-row md:justify-between md:items-center mb-4 md:mb-6 space-y-3 md:space-y-0">
                    <h2 class="text-lg md:text-xl font-bold text-nsknavy">All Assignments</h2>
                    <div class="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
                        <select id="assignmentFilter" class="px-3 py-2 border rounded-lg text-sm">
                            <option value="all">All Status</option>
                            <option value="active">Active</option>
                            <option value="upcoming">Upcoming</option>
                            <option value="overdue">Overdue</option>
                            <option value="completed">Completed</option>
                        </select>
                        <select id="classFilter" class="px-3 py-2 border rounded-lg text-sm">
                            <option value="all">All Classes</option>
                            <option value="10A">Grade 10A</option>
                            <option value="10B">Grade 10B</option>
                            <option value="11A">Grade 11A</option>
                            <option value="9A">Grade 9A</option>
                        </select>
                        <button id="createAssignmentBtn" class="bg-nskgreen text-white px-3 py-2 rounded-lg hover:bg-green-600 transition text-sm">
                            <i class="fas fa-plus mr-2"></i>Create Assignment
                        </button>
                    </div>
                </div>

                <!-- Assignment Statistics -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-4 bg-gray-50 rounded-lg">
                    <div class="text-center">
                        <div class="text-xl md:text-2xl font-bold text-nskblue">12</div>
                        <p class="text-xs text-gray-600">Total Assignments</p>
                    </div>
                    <div class="text-center">
                        <div class="text-xl md:text-2xl font-bold text-nskgreen">5</div>
                        <p class="text-xs text-gray-600">Active</p>
                    </div>
                    <div class="text-center">
                        <div class="text-xl md:text-2xl font-bold text-nskgold">3</div>
                        <p class="text-xs text-gray-600">Upcoming</p>
                    </div>
                    <div class="text-center">
                        <div class="text-xl md:text-2xl font-bold text-nskred">2</div>
                        <p class="text-xs text-gray-600">Need Grading</p>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
                    <!-- Assignment Card 1 - Active -->
                    <div class="dashboard-card assignment-card assignment-active border border-gray-200 rounded-lg p-4 hover:shadow-lg">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <h3 class="font-bold text-nsknavy text-sm md:text-base">Algebra Quiz</h3>
                                <p class="text-xs md:text-sm text-gray-600">Grade 10A • Due: Oct 15, 2023</p>
                            </div>
                            <span class="bg-green-100 text-nskgreen px-2 py-1 rounded-full text-xs font-semibold">Active</span>
                        </div>
                        <div class="space-y-2 mb-4">
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Submissions:</span>
                                <span class="font-semibold">28/30</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Average Score:</span>
                                <span class="font-semibold text-nskgreen">85%</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Status:</span>
                                <span class="font-semibold text-nskblue">2 pending</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill status-active" style="width: 93%"></div>
                            </div>
                            <div class="text-xs text-gray-600 text-center">93% submitted</div>
                        </div>
                        <div class="flex space-x-2">
                            <button class="view-assignment flex-1 bg-nskblue text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-nsknavy transition">
                                View Details
                            </button>
                            <button class="grade-assignment bg-nskgreen text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-green-600 transition">
                                <i class="fas fa-check"></i>
                            </button>
                        </div>
                    </div>
                    
                    <!-- Assignment Card 2 - Upcoming -->
                    <div class="dashboard-card assignment-card assignment-upcoming border border-gray-200 rounded-lg p-4 hover:shadow-lg">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <h3 class="font-bold text-nsknavy text-sm md:text-base">Geometry Worksheet</h3>
                                <p class="text-xs md:text-sm text-gray-600">Grade 10B • Due: Oct 18, 2023</p>
                            </div>
                            <span class="bg-blue-100 text-nskblue px-2 py-1 rounded-full text-xs font-semibold">Upcoming</span>
                        </div>
                        <div class="space-y-2 mb-4">
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Submissions:</span>
                                <span class="font-semibold">0/28</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Average Score:</span>
                                <span class="font-semibold text-gray-500">-</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Status:</span>
                                <span class="font-semibold text-nskgold">Not started</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill status-upcoming" style="width: 0%"></div>
                            </div>
                            <div class="text-xs text-gray-600 text-center">0% submitted</div>
                        </div>
                        <div class="flex space-x-2">
                            <button class="view-assignment flex-1 bg-nskblue text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-nsknavy transition">
                                View Details
                            </button>
                            <button class="edit-assignment bg-nskgold text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-amber-600 transition">
                                <i class="fas fa-edit"></i>
                            </button>
                        </div>
                    </div>
                    
                    <!-- Assignment Card 3 - Overdue -->
                    <div class="dashboard-card assignment-card assignment-overdue border border-gray-200 rounded-lg p-4 hover:shadow-lg">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <h3 class="font-bold text-nsknavy text-sm md:text-base">Calculus Problem Set</h3>
                                <p class="text-xs md:text-sm text-gray-600">Grade 11A • Due: Oct 12, 2023</p>
                            </div>
                            <span class="bg-red-100 text-nskred px-2 py-1 rounded-full text-xs font-semibold">Overdue</span>
                        </div>
                        <div class="space-y-2 mb-4">
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Submissions:</span>
                                <span class="font-semibold">22/25</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Average Score:</span>
                                <span class="font-semibold text-nskgreen">91%</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Status:</span>
                                <span class="font-semibold text-nskred">3 overdue</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill status-overdue" style="width: 88%"></div>
                            </div>
                            <div class="text-xs text-gray-600 text-center">88% submitted</div>
                        </div>
                        <div class="flex space-x-2">
                            <button class="view-assignment flex-1 bg-nskblue text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-nsknavy transition">
                                View Details
                            </button>
                            <button class="grade-assignment bg-nskgreen text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-green-600 transition">
                                <i class="fas fa-check"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Assignment Card 4 - Completed -->
                    <div class="dashboard-card assignment-card assignment-completed border border-gray-200 rounded-lg p-4 hover:shadow-lg">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <h3 class="font-bold text-nsknavy text-sm md:text-base">Trigonometry Test</h3>
                                <p class="text-xs md:text-sm text-gray-600">Grade 9A • Due: Oct 5, 2023</p>
                            </div>
                            <span class="bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-xs font-semibold">Completed</span>
                        </div>
                        <div class="space-y-2 mb-4">
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Submissions:</span>
                                <span class="font-semibold">32/32</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Average Score:</span>
                                <span class="font-semibold text-nskgreen">82%</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Status:</span>
                                <span class="font-semibold text-gray-600">All graded</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill status-completed" style="width: 100%"></div>
                            </div>
                            <div class="text-xs text-gray-600 text-center">100% submitted & graded</div>
                        </div>
                        <div class="flex space-x-2">
                            <button class="view-assignment flex-1 bg-nskblue text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-nsknavy transition">
                                View Results
                            </button>
                            <button class="edit-assignment bg-nskgold text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-amber-600 transition">
                                <i class="fas fa-chart-bar"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Assignment Card 5 - Active -->
                    <div class="dashboard-card assignment-card assignment-active border border-gray-200 rounded-lg p-4 hover:shadow-lg">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <h3 class="font-bold text-nsknavy text-sm md:text-base">Statistics Project</h3>
                                <p class="text-xs md:text-sm text-gray-600">Grade 10A • Due: Oct 25, 2023</p>
                            </div>
                            <span class="bg-green-100 text-nskgreen px-2 py-1 rounded-full text-xs font-semibold">Active</span>
                        </div>
                        <div class="space-y-2 mb-4">
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Submissions:</span>
                                <span class="font-semibold">15/30</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Average Score:</span>
                                <span class="font-semibold text-gray-500">-</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Status:</span>
                                <span class="font-semibold text-nskblue">15 pending review</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill status-active" style="width: 50%"></div>
                            </div>
                            <div class="text-xs text-gray-600 text-center">50% submitted</div>
                        </div>
                        <div class="flex space-x-2">
                            <button class="view-assignment flex-1 bg-nskblue text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-nsknavy transition">
                                View Details
                            </button>
                            <button class="grade-assignment bg-nskgreen text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-green-600 transition">
                                <i class="fas fa-check"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Assignment Card 6 - Upcoming -->
                    <div class="dashboard-card assignment-card assignment-upcoming border border-gray-200 rounded-lg p-4 hover:shadow-lg">
                        <div class="flex justify-between items-start mb-3">
                            <div>
                                <h3 class="font-bold text-nsknavy text-sm md:text-base">Final Exam Review</h3>
                                <p class="text-xs md:text-sm text-gray-600">All Classes • Due: Nov 15, 2023</p>
                            </div>
                            <span class="bg-blue-100 text-nskblue px-2 py-1 rounded-full text-xs font-semibold">Upcoming</span>
                        </div>
                        <div class="space-y-2 mb-4">
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Submissions:</span>
                                <span class="font-semibold">0/142</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Average Score:</span>
                                <span class="font-semibold text-gray-500">-</span>
                            </div>
                            <div class="flex justify-between text-xs md:text-sm">
                                <span>Status:</span>
                                <span class="font-semibold text-nskgold">Not available yet</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill status-upcoming" style="width: 0%"></div>
                            </div>
                            <div class="text-xs text-gray-600 text-center">Starts Nov 1</div>
                        </div>
                        <div class="flex space-x-2">
                            <button class="view-assignment flex-1 bg-nskblue text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-nsknavy transition">
                                Preview
                            </button>
                            <button class="edit-assignment bg-nskgold text-white py-2 px-3 rounded text-xs md:text-sm hover:bg-amber-600 transition">
                                <i class="fas fa-edit"></i>
                            </button>
                        </div>
                    </div>
                </div>
                
                <div class="flex justify-between items-center mt-6">
                    <p class="text-sm text-gray-600">Showing 6 of 12 assignments</p>
                    <div class="flex space-x-2">
                        <button class="px-3 py-1 bg-gray-200 rounded-lg text-sm hover:bg-gray-300 transition">Previous</button>
                        <button class="px-3 py-1 bg-nskblue text-white rounded-lg text-sm hover:bg-nsknavy transition">Next</button>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="bg-white rounded-xl shadow-md p-4 md:p-6 mt-6">
                <h3 class="text-lg md:text-xl font-bold text-nsknavy mb-4">Quick Actions</h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <button class="p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition text-center">
                        <i class="fas fa-file-import text-nskblue text-2xl mb-2"></i>
                        <p class="font-semibold text-nskblue">Import Assignment</p>
                    </button>
                    <button class="p-4 bg-green-50 rounded-lg hover:bg-green-100 transition text-center">
                        <i class="fas fa-copy text-nskgreen text-2xl mb-2"></i>
                        <p class="font-semibold text-nskgreen">Duplicate</p>
                    </button>
                    <button class="p-4 bg-amber-50 rounded-lg hover:bg-amber-100 transition text-center">
                        <i class="fas fa-download text-nskgold text-2xl mb-2"></i>
                        <p class="font-semibold text-nskgold">Export Grades</p>
                    </button>
                    <button class="p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition text-center">
                        <i class="fas fa-chart-bar text-purple-600 text-2xl mb-2"></i>
                        <p class="font-semibold text-purple-600">View Analytics</p>
                    </button>
                </div>
            </div>
        </div>
    </main>

    <!-- Floating Action Button for Mobile -->
    <button class="floating-btn md:hidden bg-nskblue text-white w-14 h-14 rounded-full shadow-lg flex items-center justify-center">
        <i class="fas fa-plus text-xl"></i>
    </button>

    <!-- Create Assignment Modal -->
    <div id="assignmentModal" class="modal">
        <div class="modal-content w-full max-w-2xl">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg md:text-xl font-bold text-nsknavy">Create New Assignment</h3>
                <button id="closeAssignmentModal" class="text-gray-500 hover:text-gray-700">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Assignment Title</label>
                    <input type="text" class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:border-nskblue" placeholder="Enter assignment title">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Description</label>
                    <textarea rows="3" class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:border-nskblue" placeholder="Describe the assignment..."></textarea>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Class</label>
                        <select class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:border-nskblue">
                            <option>Grade 10A</option>
                            <option>Grade 10B</option>
                            <option>Grade 11A</option>
                            <option>Grade 9A</option>
                            <option>All Classes</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
                        <input type="date" class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:border-nskblue">
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Total Points</label>
                        <input type="number" class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:border-nskblue" value="100" min="1">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Assignment Type</label>
                        <select class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:border-nskblue">
                            <option>Quiz</option>
                            <option>Homework</option>
                            <option>Project</option>
                            <option>Exam</option>
                            <option>Worksheet</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Instructions (Optional)</label>
                    <textarea rows="4" class="w-full border rounded-lg px-3 py-2 text-sm outline-none focus:border-nskblue" placeholder="Add detailed instructions for students..."></textarea>
                </div>

                <div class="flex items-center space-x-2">
                    <input type="checkbox" id="allowLate" class="rounded border-gray-300">
                    <label for="allowLate" class="text-sm text-gray-700">Allow late submissions</label>
                </div>
                
                <div class="flex justify-end space-x-3 pt-4">
                    <button type="button" id="cancelAssignment" class="px-4 py-2 border border-gray-300 rounded-lg text-sm hover:bg-gray-100 transition">Cancel</button>
                    <button type="submit" class="px-4 py-2 bg-nskgreen text-white rounded-lg text-sm hover:bg-green-600 transition">Create Assignment</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // DOM Elements
        const sidebar = document.querySelector('.sidebar');
        const mainContent = document.querySelector('.main-content');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const mobileOverlay = document.getElementById('mobileOverlay');
        const createAssignmentBtn = document.getElementById('createAssignmentBtn');
        const assignmentModal = document.getElementById('assignmentModal');
        const closeAssignmentModal = document.getElementById('closeAssignmentModal');
        const cancelAssignment = document.getElementById('cancelAssignment');
        const viewAssignmentBtns = document.querySelectorAll('.view-assignment');
        const gradeAssignmentBtns = document.querySelectorAll('.grade-assignment');
        const editAssignmentBtns = document.querySelectorAll('.edit-assignment');
        const assignmentFilter = document.getElementById('assignmentFilter');
        const classFilter = document.getElementById('classFilter');

        // Sidebar Toggle Functionality
        function toggleSidebar() {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
            
            const sidebarTexts = document.querySelectorAll('.sidebar-text');
            sidebarTexts.forEach(text => {
                text.classList.toggle('hidden');
            });
        }

        // Mobile Menu Toggle
        function toggleMobileMenu() {
            sidebar.classList.toggle('mobile-show');
            mobileOverlay.classList.toggle('active');
        }

        // Modal Functions
        function openModal(modal) {
            modal.classList.add('active');
        }

        function closeModalFunc(modal) {
            modal.classList.remove('active');
        }

        // View Assignment Details
        function handleViewAssignment(e) {
            const card = e.target.closest('.dashboard-card');
            const title = card.querySelector('h3').textContent;
            console.log(`Viewing assignment: ${title}`);
            // In a real app, this would navigate to assignment details page
            showNotification(`Opening ${title} details`, 'success');
        }

        // Grade Assignment
        function handleGradeAssignment(e) {
            const card = e.target.closest('.dashboard-card');
            const title = card.querySelector('h3').textContent;
            console.log(`Grading assignment: ${title}`);
            // In a real app, this would navigate to grading interface
            showNotification(`Opening ${title} for grading`, 'success');
        }

        // Edit Assignment
        function handleEditAssignment(e) {
            const card = e.target.closest('.dashboard-card');
            const title = card.querySelector('h3').textContent;
            console.log(`Editing assignment: ${title}`);
            // In a real app, this would open edit modal
            showNotification(`Editing ${title}`, 'success');
        }

        // Filter assignments
        function handleFilterChange() {
            const statusFilter = assignmentFilter.value;
            const classFilterValue = classFilter.value;
            const cards = document.querySelectorAll('.dashboard-card');
            
            cards.forEach(card => {
                const status = card.querySelector('span').textContent.toLowerCase();
                const classText = card.querySelector('p.text-gray-600').textContent;
                let showCard = true;
                
                if (statusFilter !== 'all' && !status.includes(statusFilter)) {
                    showCard = false;
                }
                
                if (classFilterValue !== 'all' && !classText.includes(classFilterValue)) {
                    showCard = false;
                }
                
                card.style.display = showCard ? 'block' : 'none';
            });
        }

        // Show notification
        function showNotification(message, type) {
            // Create notification element
            const notification = document.createElement('div');
            notification.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
                type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
            }`;
            notification.textContent = message;
            
            document.body.appendChild(notification);
            
            // Remove notification after 3 seconds
            setTimeout(() => {
                notification.remove();
            }, 3000);
        }

        // Event Listeners
        sidebarToggle.addEventListener('click', toggleSidebar);
        mobileMenuToggle.addEventListener('click', toggleMobileMenu);
        mobileOverlay.addEventListener('click', toggleMobileMenu);

        // Assignment buttons
        viewAssignmentBtns.forEach(btn => {
            btn.addEventListener('click', handleViewAssignment);
        });

        gradeAssignmentBtns.forEach(btn => {
            btn.addEventListener('click', handleGradeAssignment);
        });

        editAssignmentBtns.forEach(btn => {
            btn.addEventListener('click', handleEditAssignment);
        });

        // Create assignment modal
        createAssignmentBtn.addEventListener('click', () => openModal(assignmentModal));
        closeAssignmentModal.addEventListener('click', () => closeModalFunc(assignmentModal));
        cancelAssignment.addEventListener('click', () => closeModalFunc(assignmentModal));

        // Filters
        assignmentFilter.addEventListener('change', handleFilterChange);
        classFilter.addEventListener('change', handleFilterChange);

        // Close modal when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === assignmentModal) {
                closeModalFunc(assignmentModal);
            }
        });

        // Responsive adjustments
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) {
                sidebar.classList.remove('mobile-show');
                mobileOverlay.classList.remove('active');
            }
        });

        // Initialize the page
        document.addEventListener('DOMContentLoaded', () => {
            console.log('Assignments page loaded successfully');
        });
    </script>
</body>
</html>